<?php
class VueDonnees {

	static function afficherDonnees($stats) {	
		
		foreach ($stats as $value) {
			$nom = $value['nom_information'];
		}
		?>
			<h1 id="labelAccueil"> <?php echo $nom;?></h1>
		
		<?php
		foreach ($stats as $value) {
			echo '<br/>'.$value['texte_information'].'<br/>';
		}		
	}
}
?>
