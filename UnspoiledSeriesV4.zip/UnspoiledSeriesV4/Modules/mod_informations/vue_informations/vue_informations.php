<?php
class VueInformations {

	static function afficherInfos($stats) {	
		
		switch ($_GET['action']) {
			case 1: ?> <h1 id="labelAccueil">P E R S O N N A G E S</h1> <?php break;
			case 2: ?> <h1 id="labelAccueil">L I E U X</h1> <?php break;
			case 3: ?> <h1 id="labelAccueil">E V E N E M E N T S</h1> <?php break;
			case 4: ?> <h1 id="labelAccueil">I N T E R V I E W S</h1> <?php break;
			
		}
		
		?>	
		<div class="container">
			<section id="ligne" class="row">
	
				<?php
				foreach ($stats as $value) {
				?>
					<a href="index.php?module=donnees&action=<?php echo $_GET['action'];?>&idSerie=<?php echo $_GET['idSerie'];?>&idSaison=<?php echo $_GET['idSaison'];?>&nom=<?php echo $value['nom_information'];?>">
						<div class="col-md-2">  
							<figure style="overflow:hidden;position:relative">
								<img src="./images/personnages/<?php echo $value['nom_information'];?>.jpg"  alt="Image de <?php echo $value['nom_information'];?>" width="100%" height="230px">
								<figcaption>
									<p id="nom"> Nom : <?php echo $value['nom_information'];?></p>
								</figcaption>
							</figure>
						</div>
					</a>
				<?php
				}
				?>
			</section>
		</div>
		<?php		
	}
}
?>
