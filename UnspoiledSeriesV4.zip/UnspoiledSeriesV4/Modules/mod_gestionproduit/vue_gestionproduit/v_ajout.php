<?php
class VueAjout {
	public static function afficherAccueil() {
		echo('
				<br>
				<div class="btn-group" role="group" aria-label="...">
					<a href="index.php?module=gestionproduit&action=ajoutproduit" type="button" class="btn btn-default">Ajouter un Produit</a>
					<a href="index.php?module=gestionproduit&action=afficherStock" type="button" class="btn btn-default">Afficher le stock</a>
					<a href="index.php?module=gestionproduit&action=reapproLivre" type="button" class="btn btn-default">R�approvisionner un livre</a>
				</div>
				');
		
		
	}
	public static function afficherFormulaireAjout() {
		echo ('
				<h1 id="labelAccueil">Ajout Produit</h1>

     <div id="formulaire" class="container">
        <div class="row">
            <form  action="index.php?module=gestionproduit&action=ajoutproduit" method="POST">
                <input class="col-md-5" name="titre" type="text" placeholder="TITRE" id="titre" required>
                <input class="col-md-5" name="auteur" type="text" placeholder="AUTEUR" id="auteur" required>
                <input class="col-md-5" name="editeur" type="text" placeholder="EDITEUR" id="editeur" required>
                <input class="col-md-5" name="dateParution" type="text" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01]).(0[1-9]|1[012]).[0-9]{4}" placeholder="DATE DE PARUTION DD/MM/YYYY" id="dateParution" required>
                <input class="col-md-5" name="isbn" type="text" placeholder="ISBN" id="ISBN" required>					
                <input class="col-md-5" name="prix" type="text" placeholder="PRIX" id="prix" required>
				<input class="col-md-5" name="quantiteDispo" type="text" placeholder="QUANTITE DISPONIBLE" id="quantiteDispo" required> 
                <input class="col-md-8" type="submit" value="AJOUT" id="bouton">
            </form>
         </div>
        
        </div>
				');
	}
	public static function afficherAjoutReussie() {
		$titre = $_POST ['titre'];
		echo ("Ajout de $titre reussie. <br>");
	}
	public static function afficherAjoutRatee() {
		echo ("Ajout echouee. <br>");
	}
	public static function afficherLivreDejaExistant($titre) {
		echo ("Le livre $titre est deja dans la base de donn�es, veuillez en choisir un autre <br>");
	}
	public static function afficherStock($stock) {
		echo (' 
				<table  class="col-md-12">
					<thead>
						<tr>
							<th class="col-md-4">R�f�rence Produit</th>
							<th class="col-md-4">idBoutique</th>
							<th class="col-md-4">Quantit� restante</th>
						</tr>
					</thead>
					<tbody>
				');
		foreach($stock as $s){
			echo('
					<tr>
					<td>'. $s['referenceProduit'] .'</td> 
					<td>'. $s['idBoutique'] .'</td>
					<td>'. $s['quantite'] .'</td>
					</tr>
					');
		}
			echo('
						</tbody>
					</table>
					');
		
	}
	
	public static function afficherFormulaireReappro ($livres) {
		echo("<br><form action='index.php?module=gestionproduit&action=reapproLivre' method='post'>
				 R�approvisionner 
				<select name='titreLivre'>
				");
		foreach ($livres as $l){
			echo('<option  value="'. $l['titre'].'">'. $l['titre'].'</option> 
					');
		}
		echo("</select> en <input  name='quantite' type='number' min='1' placeholder='1' required> exemplaires <input type='submit' value='Commander'>
				</form>");
		
	}
	
	public static function afficherRapproOK () {
		echo("Bon de commande pour la r�approvision envoy� ! <br>");
	}
}
?>
