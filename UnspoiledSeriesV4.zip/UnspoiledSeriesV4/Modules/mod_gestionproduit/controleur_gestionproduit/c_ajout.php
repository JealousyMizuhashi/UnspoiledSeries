<?php
require_once ("Modules/mod_gestionproduit/modele_gestionproduit/m_ajout.php");
require_once ("Modules/mod_gestionproduit/vue_gestionproduit/v_ajout.php");
class Controleurajout extends ControleurGenerique {
	public function afficherAccueil() {
		$this->constructView ( "VueAjout", "afficherAccueil", array () );
	}
	public function ajouter() {
		$existeDansLaBase = ModeleAjout::livreExisteDansLaBase ( $_POST ['isbn'] );
		if (! $existeDansLaBase) {
			$ajoutReussie = ModeleAjout::ajouterLivre ( $_POST ['titre'], $_POST ['auteur'], $_POST ['editeur'], $_POST ['dateParution'], $_POST ['isbn'], $_POST ['prix'], $_POST ['quantiteDispo'] );
			if ($ajoutReussie) {
				$this->constructView ( 'VueAjout', 'afficherAjoutReussie', array () );
			} else
				$this->constructView ( 'VueAjout', 'afficherAjoutRatee', array () );
		} else {
			$this->constructView ( 'VueAjout', 'afficherLivreDejaExistant', array (
					$_POST ['titre'] 
			) );
		}
	}
	public function afficherFormulaireAjout() {
		$this->constructView ( 'VueAjout', 'afficherFormulaireAjout', array () );
	}
	public function ajout() {
		if (isset ( $_POST ['titre'] ) && isset ( $_POST ['auteur'] ) && isset ( $_POST ['editeur'] ) && isset ( $_POST ['dateParution'] ) && isset ( $_POST ['isbn'] ) && isset ( $_POST ['prix'] ) && isset ( $_POST ['quantiteDispo'] )) {
			$this->ajouter ();
		} else {
			$this->afficherFormulaireAjout ();
		}
	}
	public function afficherStock() {
		require_once 'apiClass.php';
		$api = new API ( 'http://pageperso.iut.univ-paris8.fr/~jgotin/api/index.php', 1 );
		$data = $api->recupererStock ();
		$this->constructView ( "VueAjout", "afficherStock", array (
				$data 
		) );
	}
	public function reapproLivre() {
		if (isset ( $_POST ['titreLivre'] ) && isset ( $_POST ['quantite'] )) {
			require_once 'apiClass.php';
			$api = new API ( 'http://pageperso.iut.univ-paris8.fr/~jgotin/api/index.php', 1 );
			$data = $api->reaprovisionnementProduit($_POST ['titreLivre'],  $_POST ['quantite']);
			$this->constructView ( "VueAjout", "afficherRapproOK", array ());
		} else {
			$livres = ModeleAjout::getLivres ();
			$this->constructView ( "VueAjout", "afficherFormulaireReappro", array (
					$livres 
			)
			 );
		}
	}
}
?>
