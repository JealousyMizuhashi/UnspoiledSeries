<?php
// if(!defined("TEST_INCLUDE")
// die("Vous ne pouvez pas accéder à cette page du site");
class ModeleAjout extends DBMapper {
	
	public static function ajouterLivre($titre, $auteur, $editeur, $dateParution, $ISBN, $prix, $quantiteDispo) {
		$req = self::$database->prepare ( "INSERT INTO `lemon_livre`(`titre`, `auteur`, `editeur`, `dateParution`, `ISBN`, `prix`, `quantiteDispo`) VALUES (?, ?, ?, ?, ?, ?, ?)" );
		$array [0] = $titre;
		$array [1] = $auteur; 
		$array [2] = $editeur;
		$array [3] = $dateParution;
		$array [4] = $ISBN;
		$array [5] = $prix;
		$array [6] = $quantiteDispo; 
		$count = $req->execute ( $array );

		if ($count === false)
			return false;
		if ($count === 0)
			return false;
		if ($count != 0 && $count != false) {
			return true;
		}
	}
	public static function getLivres (){
		$req = self::$database->prepare ( "select titre from lemon_livre" );
		$req->execute();
		return $req->fetchAll(PDO::FETCH_ASSOC);
		
		
	}
	public static function livreExisteDansLaBase($ISBN) {
		$req = self::$database->prepare ( "select * from lemon_livre where ISBN=?" );
		$array [0] = $ISBN;
		$req->execute ( $array );
		$count = $req->rowCount ();
		if ($count === 0)
			return false;
		if ($count > 0)
			return true;
	}
}

?>
