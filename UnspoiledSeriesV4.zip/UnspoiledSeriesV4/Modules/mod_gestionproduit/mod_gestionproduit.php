<?php
class Modulegestionproduit extends ModuleGenerique {
	public function __construct() {
		if (isset ( $_SESSION ['estAdmin'] ) && $_SESSION ['estAdmin']) {
			$module = "gestionproduit";
			if (isset ( $_GET ['action'] ))
				$action = $_GET ['action'];
			else
				$action = 'ajout';
			require_once ("Modules/mod_$module/controleur_$module/c_ajout.php");
			$this->controleur = new Controleurajout ();
			switch ($action) {
				case 'accueil' :
					$this->controleur->afficherAccueil ();
					break;
				case 'ajoutproduit' :
					$this->controleur->ajout ();
					break;
				case 'afficherStock' :
					
					$this->controleur->afficherStock ();
					break;
				case 'reapproLivre' :
					$this->controleur->reapproLivre();
					break;
				default :
					$this->controleur->afficherAccueil ();
					break;
			}
		} else
			exit ( 'Vous devez �tre administrateur pour acc�der � cette partie du site.' );
	}
}
?>
