<?php
class VueDeconnexion {
	public static function deconnexionReussie() {
		echo("Vous avez ete deconnecte !<br>");
	}	
	public static function deconnexionRatee() {
		echo("Deconnexion ratee <br>");
	}
}
?>