<?php class VueInscription {

	public static function afficherFormulaireInscription() {
		echo('
				<h1 id="labelAccueil">INSCRIPTION</h1>

     <div id="formulaire" class="container">
        <div class="row">
            <form action="index.php?module=connexion&action=inscription" method="POST">
                <h2>Venez rejoindre la communaute pour pouvoir �tre au courant des dernieres nouveautes, ou simplement, venir faire
                vos achats chez nous.</h2><h2>Toute l\'equipe de Lemon vous remercie et vous souhaite la bienvenue.</h2>
                <input name="nom" type="text" placeholder="NOM" id="nom" required>
                <input name="prenom" type="text" placeholder="PRENOM" id="prenom" required>
                <input name="adresse" type="text" placeholder="ADRESSE" id="adresse" required>
                <input name="codePostal" type="text" placeholder="CODE POSTAL" id="codepostal" required>
                <input name="email" type="email" placeholder="EMAIL" id="email" required>
                <input name="pseudo" type="text" placeholder="PSEUDO" id="pseudo" required>
                <input name="password" type="password" placeholder="MOT DE PASSE" id="password" required>
                <input type="submit" value="S\'INSCRIRE" id="bouton">
            </form>
         </div>
        
        </div>
				');
	}
	public static function afficherInscriptionReussie () {
		$log = $_POST['pseudo'];
		echo("Inscription de $log reussie. <br>");
	}
	public static function afficherInscriptionRatee() {
		echo("Inscription echouee. <br>");
	}
	
	public static function afficherPseudoDejaExistant ($pseudo) {
		echo("Le pseudo $pseudo est d�j� utilis�, veuillez en choisir un autre <br>");
	}
	
}
?>
