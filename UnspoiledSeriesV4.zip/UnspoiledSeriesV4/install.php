<?php
	//include_once("./connexion.php");
	$host = 'mysql:host=localhost'; /* L'adresse du serveur */
	$login = 'root'; /* Votre nom d'utilisateur */
	$password = ''; /* Votre mot de passe */
	try
	{
		if($bdd = new PDO($host, $login, $password)) echo 'BDD OK !';
	}
	catch (Exception $e)
	{
		   die('Erreur : ' . $e->getMessage());
	}
	
	$req = "DROP DATABASE `unspoiledseries`";
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE DATABASE IF NOT EXISTS `unspoiledseries`";
	$bdd->prepare($req)->execute();
	
	$req = "USE unspoiledseries";
	$bdd->prepare($req)->execute();
	
	$req = "CREATE TABLE categorie(
    id_categorie INT NOT NULL AUTO_INCREMENT,
    nom_categorie VARCHAR(64) NOT NULL,
    PRIMARY KEY (id_categorie),
    UNIQUE (nom_categorie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE serie(
    id_serie INT NOT NULL AUTO_INCREMENT,
    nb_saison_serie INT UNSIGNED NOT NULL,
	nom_serie VARCHAR(128) NOT NULL,
    PRIMARY KEY (id_serie),
    UNIQUE (nom_serie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE information(
    id_information INT NOT NULL AUTO_INCREMENT,
    nom_information VARCHAR(128) NOT NULL,
	texte_information VARCHAR(512) NOT NULL,
	id_categorie_information INT NOT NULL,
	id_serie_information INT NOT NULL,
	saison_information INT NOT NULL,
    PRIMARY KEY (id_information)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE user(
    idUser BIGINT(20) NOT NULL AUTO_INCREMENT,
    login VARCHAR(256) NOT NULL,
	password VARCHAR(256) NOT NULL,
	nom VARCHAR(256) NOT NULL,
	prenom VARCHAR(256) NOT NULL,
	adresse VARCHAR(256) NOT NULL,
	email VARCHAR(32) NOT NULL,
	codePostal INT(11) NOT NULL,
	estAdmin TINYINT(1) NOT NULL,
    PRIMARY KEY (idUser)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";
	$bdd->prepare($req)->execute(); 
	
	$req = "INSERT INTO categorie VALUES(1,'personnages')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(2,'lieux')";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(3,'evenements')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(4,'interviews')";	$bdd->prepare($req)->execute();
	
	$req = "INSERT INTO serie VALUES(1,6,'Game of Thrones')";	$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(2,6,'The Walking Dead')";	$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(3,5,'Breaking Bad')";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(4,5,'Once Upon a Time')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(5,10,'Stargate SG-1')";	$bdd->prepare($req)->execute();
	
	/* infos personnage */
	$req = "INSERT INTO information VALUES(1,'Tyrion Lannister', 'Tyrion est un nain. Il est le dernier fils de la famille lannister',1,1,0)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(2,'Tyrion Lannister', 'Il tua son père avec une arbalète lors de son évasion des prison du donjon rouge',1,1,4)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(3,'Tyrion Lannister', 'Desormais à Merren, il sert Daeneris en lui offrant ses conseils',1,1,5)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(4,'Cersei Lannister', 'Cersei est la soeur de Tyrion et James Lannister. Elle est marié au roi Robert Barathéon',1,1,0)";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(5,'Cersei Lannister', 'Elle vient d'arriver au donjon rouge après sa marche d\'expiation dans la capitale',1,1,5)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(6,'Rick Grimes', 'Rick était shérif et après avoir reçu une balle dans une fusillade, il se réveille dans un hôpital en ruine',1,2,0)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(7,'Michonne', 'Michonne se déplace avec deux mort-vivants sans bras ni bouche et rencontre Andrea',1,2,3)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(8,'Glenn', 'Glen est un ancien livreur de pizza qui aide les gens dans le besoin autant que possible contre les marcheurs',1,2,0)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(9,'Glenn', 'Il devient le petit ami de Maggie qu\'il rencontre avec le groupe de Rick après la blessure de Carl',1,2,2)";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(10,'Walter White', 'Professeur de chimie dans un lycée, il apprend qu\'il est atteint d\'un cancer',1,3,0)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(11,'Walter White', 'Il produit de la meth (drogue synthétique) en grande quantité pour Gustavo Fring avec l\'aide de Jesse',1,3,3)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(12,'Jesse Pinkman', 'Jesse produit de la drogue illégalement avant de rencontrer Walter White',1,3,0)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(13,'Mike Ehrmantraut', 'Mike est à la fois détective privé et chef de la sécurité de la sécurité de \"Los Pollos Hermanas\"',1,3,3)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(14,'Saul Goodman', 'Avocat avide d\'argent, il fera affaire avec Walter White et Jesse',1,3,0)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(15,'Hank Schrader', 'Hank est agent des stup. Il est également le beau-frère de Walter White',1,3,0)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(16,'Skyler White', 'Skyler est femme au foyer. Elle est marié à Walter White',1,3,0)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(17,'Marie Schrader', 'Marie est l'épouse de Hank Schrader et la soeur de Skyler White',1,3,0)";											$bdd->prepare($req)->execute();
	/* infos lieux */
	$req = "INSERT INTO information VALUES(18,'Winterfell', 'Capitale du nord, elle est dirigé par la famille Stark depuis plusieurs milliers d'années',2,1,0)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(19,'Winterfell', 'Après la chute de Robb Stark, Winterfell appartient désormait à la famille Bolton',2,1,5)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(20,'Dorne', 'Dorne est au Sud de Westeros et est dirigé par la famille Martell',2,1,4)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(21,'Atlanta', 'Atlanta est la ville dans laquelle se rend Rick à cheval, il y rencontre Glenn et beaucoup d'autres',2,2,4)";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(22,'Ferme familiale des Greene', 'Cette exploitation fermière est le refuge du groupe de Rick après que Carl soit blessé',2,2,2)";		$bdd->prepare($req)->execute();
	/* infos evenements */
	$req = "INSERT INTO information VALUES(23,'Les noces pourpre','lien',3,1,3)";																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(24,'La mort de Joffrey','lien',3,1,4)";																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(25,'Duel judiciaire Oberyn contre La Montagne','lien',3,1,4)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(26,'Les noces pourpre','lien',3,1,3)";																									$bdd->prepare($req)->execute();
	/* infos interviews */
	$req = "INSERT INTO information VALUES(27,'Interview','lien',4,1,0)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(28,'Interview','lien',4,1,1)";																											$bdd->prepare($req)->execute();
	
	$req = "INSERT INTO user VALUES(1,'admin','admin','nomAdmin','prenomAdmin','140, rue du Nouvel Admin','admins@admin.fr',93100,1)";	$bdd->prepare($req)->execute();	
	
?>