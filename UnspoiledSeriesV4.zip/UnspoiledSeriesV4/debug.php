<?php
//if (!defined('TEST_INCLUDE'))
//	die("Vous ne pouvez pas accéder directement à ce fichier !");

ini_set("display_errors", 1);
error_reporting(E_ALL);

?>