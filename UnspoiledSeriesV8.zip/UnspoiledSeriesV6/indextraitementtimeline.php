<?php
session_start ();

include_once "./dbmapper.php";
include_once './debug.php';
include_once './params_connexion.php';
require_once ("./include_generique.php");

$connexion = new PDO ( $host, $login, $password );
DBMapper::init ( $connexion );
?>

<!DOCTYPE html>

<html>
	<head>
		<meta charset="ASCII" />
		<title>Unspoiled Series</title>
		<link href="./main.css" rel="stylesheet">
		<link href="./dist/css/bootstrap.css" rel="stylesheet">

		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	</head>

	<body>
		<header>
				<?php 
					$_SESSION['saison_choisi'] = $_POST['saison_choisi'];
					$_SESSION['serie_choisi'] = $_POST['serie_choisi'];
					//$_SESSION['categorie_choisi'] = $_POST['categorie_choisi'];
				?>
		</header>
		
	</body>

</html>
