<?php
	//include_once("./connexion.php");
	$host = 'mysql:host=localhost'; /* L'adresse du serveur */
	$login = 'root'; /* Votre nom d'utilisateur */
	$password = ''; /* Votre mot de passe */
	try
	{
		if($bdd = new PDO($host, $login, $password)) {
			echo 'BDD Ok !
				<div  id="moduleConnexion">
					<li>
						<a href="./index.php"> 
							 <button type="button" class="btn btn-danger btn-lg" id="butConnexion" >Index</button>
						</a>
					</li>
				</div>
				';
		}
	}
	catch (Exception $e)
	{
		   die('Erreur : ' . $e->getMessage());
	}
	
	$req = "DROP DATABASE `unspoiledseries`";
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE DATABASE IF NOT EXISTS `unspoiledseries`";
	$bdd->prepare($req)->execute();
	
	$req = "USE unspoiledseries";
	$bdd->prepare($req)->execute();
	
	$req = "CREATE TABLE categorie(
    id_categorie INT NOT NULL AUTO_INCREMENT,
    nom_categorie VARCHAR(64) NOT NULL,
    PRIMARY KEY (id_categorie),
    UNIQUE (nom_categorie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE serie(
    id_serie INT NOT NULL AUTO_INCREMENT,
    nb_saison_serie INT UNSIGNED NOT NULL,
	nom_serie VARCHAR(128) NOT NULL,
    PRIMARY KEY (id_serie),
    UNIQUE (nom_serie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE information(
    id_information INT NOT NULL AUTO_INCREMENT,
    nom_information VARCHAR(128) NOT NULL,
	texte_information VARCHAR(1024) NOT NULL,
	id_categorie_information INT NOT NULL,
	id_serie_information INT NOT NULL,
	saison_information INT NOT NULL,
	info_valide BOOLEAN NOT NULL,						
    PRIMARY KEY (id_information)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE user(
    idUser BIGINT(20) NOT NULL AUTO_INCREMENT,
    login VARCHAR(256) NOT NULL,
	password VARCHAR(256) NOT NULL,
	email VARCHAR(32) NOT NULL,
	typeCompte TINYINT(1) NOT NULL,
	serieCompte INT,
    PRIMARY KEY (idUser)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";
	$bdd->prepare($req)->execute(); 
	
	/* catégories */
	$req = "INSERT INTO categorie VALUES(1,'personnages')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(2,'lieux')";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(3,'evenements')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(4,'interviews')";	$bdd->prepare($req)->execute();
	
	/* séries */
	$req = "INSERT INTO serie VALUES(1,6,'Game Of Thrones')";			$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(2,6,'The Walking Dead')";			$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(3,5,'Breaking Bad')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(4,5,'Once Upon A Time')";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(5,10,'Stargate SG-1')";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(6,11,'Supernatural')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(7,4,'Orange Is The New Black')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(8,4,'Batman (serie televisee d\'animation, 1992)')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(9,19,'South Park')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(10,9,'The Big Bang Theorie')";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(11,5,'Prison Break')";				$bdd->prepare($req)->execute();
	
	$robertbaratheon="Robert Barathéon";
	$robertbaratheon=utf8_decode($robertbaratheon);
	$penitentierdelitchfield="Pénitentier de Litchfield";
	$penitentierdelitchfield=utf8_decode($penitentierdelitchfield);
	$chateaunoir="Châteaunoir";
	$chateaunoir=utf8_decode($chateaunoir);
	$portreal="Port-Réal";
	$portreal=utf8_decode($portreal);
	$cinemadesouthpark="Cinéma de South Park";
	$cinemadesouthpark=utf8_decode($cinemadesouthpark);
	$laresurrectiondemalefique="La résurrection de Maléfique";
	$laresurrectiondemalefique=utf8_decode($laresurrectiondemalefique);
	$decollagedupromethee="Décollage du Prométhée";
	$decollagedupromethee=utf8_decode($decollagedupromethee);
	$interviewdesacteursetrealisateursavantlasaison2="Interview des acteurs et réalisateur avant la saison 2";
	$interviewdesacteursetrealisateursavantlasaison2=utf8_decode($interviewdesacteursetrealisateursavantlasaison2);
	$laforetenchantee="La forêt enchantée";
	$laforetenchantee=utf8_decode($laforetenchantee);
	$leseyrie="Les Eyrié";
	$leseyrie=utf8_decode($leseyrie);
	$lesilesdefer="Les Îles de fer";
	$lesilesdefer=utf8_decode($lesilesdefer);
	$decapitationdunchevalparlamontagne="La décapitation d\'un cheval par La Montagne";
	$decapitationdunchevalparlamontagne=utf8_decode($decapitationdunchevalparlamontagne);
	$debutdelepisode1="Breaking Bad - Saison 1 - Début de l\'épisode 1";
	$debutdelepisode1=utf8_decode($debutdelepisode1);
	$sheldondrogue="The Big Bang theory - Sheldon drogué";
	$sheldondrogue=utf8_decode($sheldondrogue);
	$joffreybaratheon="Joeffrey Barathéon";
	$joffreybaratheon=utf8_decode($joffreybaratheon);
	$larriveedesmarcheursblancs="L\'arrivée des marcheurs blancs - Game of Thrones"; 
	$larriveedesmarcheursblancs=utf8_decode($larriveedesmarcheursblancs);
	$discoursdericketmortdhershel="Discourt de Rick et mort d\'Hershel";
	$discoursdericketmortdhershel=utf8_decode($discoursdericketmortdhershel);
	$interviewdandrewlincoln="Interview d\'Andrew Lincoln";
	$interviewdandrewlincoln=utf8_decode($interviewdandrewlincoln);
	$leglise="L\'église";
	$leglise=utf8_decode($leglise);
	$southparklevolutionsuivantmmmegarrison="South Park - L\'évolution selon Mme Garrison";
	$southparklevolutionsuivantmmmegarrison=utf8_decode($southparklevolutionsuivantmmmegarrison);
	$chansondhowardpourbernadette="Chanson d\'Howard pour Bernadette";
	$chansondhowardpourbernadette=utf8_decode($chansondhowardpourbernadette);
	$reginamills="Regina Mills - la Méchante Reine";
	$reginamills=utf8_decode($reginamills);
	
	/* infos personnage */ //mettre à jour les numéros
	$req = "INSERT INTO information VALUES(1,'Tyrion Lannister', 'Tyrion est un nain. Il est le dernier fils de la famille Lannister. C\'est quelqu\'un d\'intelligent, mais &eacute;galement 
	friant de prostitu&eacute;.',1,1,0,true)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(2,'Tyrion Lannister', 'Lors des noces de son neuveu Joffrey, il du servir une coupe de vin &agrave; celui-ci qui mouru empoisonn&eacute;. Tyrion fut accus&eacute; &agrave; tortura
	de l\'assassinat. Lors de son proc&ecirc;t, il demenda un duel judiciaire. Oberyne Martell se battit donc contre La Montagne et mourru, scellant ainsi le sort de Tyrion. Il tua Shae en l\'&eacute;tranglant puis son 
	p&egrave;re avec une arbal&egrave;te lors de son &eacute;vasion des prisons du donjon rouge.',1,1,4,true)";																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(3,'Tyrion Lannister', 'Avec l\'aide de Varis, il parvient &agrave; quitt&eacute; Westeros. Celui-ci lui propose de conseiller Daenerys pour l\'aider &agrave; gouvern&eacute; 
	les 7 couronnes. Il se fit enlev&eacute; par Jeor Mormont qui esp&eacute;rais le donn&eacute; comme ran&ccedil;on. D&eacute;sormais &agrave; Merren, il sert Daenerys en lui offrant ses conseils.',1,1,5,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(4,'Tyrion Lannister', 'Tyrion est avec le reste du convoi royal &agrave; Winterfell. Il rejoint le Mur avec John Snow pour pouvoir piss&eacute; d\'en haut. Lors de son retour il 
	est captur&eacute; par Catelyn Stark et ses hommes et emmen&eacute; aux Eyri&eacute;. Ne pouvant prouver son innocense dans la chute de Brann et sa tentative d\'assasina, il demande un duel judiciaire et Bronn lui sert 
	de champion. Bronn gagne le combat et Tyrion est donc lib&eacute;r&eacute;.',1,1,1,true)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(5,'Tyrion Lannister', 'Il rencontre Shae pendant la campagne des Lannister contre les Stark. Pendant une bataille il se fait assom&eacute; de par sa petite taille et ne participe 
	pas au combat. De retour &agrave; Port-R&eacute;al, il devient main du roi &agrave; la place de son p&egrave;re qui est occup&eacute; par la guerre. Tyrion fait de son mieux pour aid&eacute; malgr&eacute; la tyranie 
	de Joeffrey qui le desteste grandement. Ne sachant &agrave; qui se fi&eacute; dans le conseil restreint puisque les main du roi pr&eacute;c&eacute;dente son morte, il met en place un stratag&egrave;me pour savoir qui 
	de Varys, Littlefinger, ou Pycelle racontra une information secr&egrave;te &agrave; Cersei. Le grand mestre Pycelle est alors remarqu&eacute; et Tyrion lui fait coup&eacute; la barbe avant de le jet&eacute; aux cachots. 
	Pycelle sera rapidement lib&eacute;r&eacute; sous la demande de Cersei. Pendant la bataille de la N&eacute;ra, Tyrion supervise la contre offensive et fait un discour pour remont&eacute; le moral des soldats. Il est 
	gri&egrave;vement bl&eacute;ss&eacute; 	par un garde royal sous les ordres de Cersei mais survit gr&acirc;ce &agrave; l\'intervention de Podrick.',1,1,2,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(6,'Cersei Lannister', 'Cersei est la soeur de Tyrion et James Lannister. Elle est mari&eacute; au roi Robert Barath&eacute;on.',1,1,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(7,'Cersei Lannister', 'Elle arrive &agrave; Winterfell avec le Robert, venu pour demend&eacute; &agrave; Ned Stark de devenir main du roi. Elle fut surprit par Bran en train de 
	couch&eacute; avec son propre fr&ecirc; Jaime Lannister. Jaime fit alors tomb&eacute; Bran de la tour pour qu\'il ne d&eacute;voile pas leur amour secret et incestueu. Ce secret avait &eacute;t&eacute; d&eacute;couverte 
	par John Arryn, puis par Ned Stark lorsqu\'il devint main du roi. Lorsque Robert mourru, Ned apporta une lettre &agrave; Cersei donnant la r&eacute;gence &agrave; Ned jusqu\'&agrave; la maturit&eacute; de Joeffrey. 
	Cersei prit &ccedil;&agrave; comme un outrage et d&eacute;chira la feuille et fit emprisonn&eacute; Ned Stark. Celui-ci fut d&eacute;capit&eacute; sous l\'ordre de Joeffrey malgr&eacute; la demande de Cersei de le 
	gard&eacute; prisonni&eacute;.',1,1,1,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(8,'Cersei Lannister', 'Elle demende &agrave; son fils, le roi, de r&eacute;armer la foi militante pour pi&eacute;ger Loras et Margaery Tyrell. Ce plan se retourne contre elle 
	lorsque le grand moineau la fait prisonni&egrave;re pour sa faute de fornication avec Lancel Lannister. Elle arrive finalement au donjon rouge apr&egrave;s sa marche d\'expiation dans la capitale.',1,1,5,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(9,'Eddard Stark', 'Surnommer Ned Stark, il est le gouverneur du Nord de Westeros et p&egrave;re d\'une grande famille. Il est le fr&ecirc;re de Benjen Stark, mari&eacute; &agrave; Catelyn Stark
	 et p&egrave;re de John Snow, Robb, Sansa, Bran, Arya et Rickon Stark. Il a particip&eacute; &agrave; la rebellion avec Robert Barath&eacute;on contre les Targaryen il y a 15 ans.',1,1,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(10,'John Snow', 'John est le fils batard de Ned Stark, il n\'a pas de droits d\'h&eacute;ritage sur Winterfell de par son droit de naissance.',1,1,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(11,'John Snow', 'Apr&eacute; l\'execution d\'un deserteur de la Garde de Nuit, La famille Stark trouve une louve g&eacute;ante morte et des louvetaux. John propose de les donn&eacute; 
	au fils Stark. Il trouve un dernier louveteau albinos qui devient le sien. Il demende par la suite de devenir membre de la Garde de Nuit &agrave; Ned. Avant de partir, il donne une &eacute;p&eacute;e &agrave; Arya. 
	Il rejoint quelque temps apr&egrave;s la Garde de Nuit et fait ses voeux.',1,1,1,true)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(12,'John Snow', 'Lors d\'une patrouille au nord du Mur, il arrive avec les autres membres de la Garde de Nuit &agrave; la maison de Craster. Il espionne celui-ci transportant un 
	enfant et l\'offrant &agrave; un Marcheur Blanc. Craster le voit et ordonne &agrave; toute la patrouille de partir. Il rejoint le groupe de Qhorin Mimain une fois arriv&eacute; au Point des Premiers Hommes. Pendant 
	le voyage il est s&eacute;par&eacute; du groupe lorsqu\'il &eacute;choue dans l\'execution d\'une sauvageonne : Ygritte. Celle-ci le fait tomb&eacute; dans un pi&egrave;ge et il se retrouve alors prisonnier des 
	sauvageons.',1,1,2,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(13,'John Snow', 'Il arrive finalement au camp du Peuple Libre o&ugrave; il voit un g&eacute;ant. John fait alors la rencontre de Mance Rayder qu\'il parvient &agrave; convaincre 
	qu\'il veut les rejoindre. Il accompagne alors un groupe de sauvageons dirig&eacute; par Tormund en direction du Mur. Les sentiments de John pour Ygritte grandisse et ils finissent par coucher ensemble dans une source 
	d\'eau chaude souterraine. Il escalade le Mur avec le groupe, non sans difficult&eacute;. Lorsque John doit tu&eacute; un &eacute;leveur de chevaux, il refuse et s\'enfui apr&egrave;s avoir tu&eacute; Orell. Ygritte 
	le rattrape et lui tire 3 fl&ecirc;ches pour l\'avoir trahis, mais non mortel car elle &agrave; toujours des sentiments pour lui. John parvient &agrave; Ch&acirc;teaunoir tr&egrave;s bless&eacute;',1,1,3,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(14,'Arya Stark', 'Arya est la plus jeune fille des Stark. Contrairement &agrave; sa soeur Sansa, est un gar&ccedil;on manqu&eacute;.',1,1,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(15,'Arya Stark', 'Lors de la d&eacute;couverte des louveteau, elle re&ccedil;ois le sien qu\'elle nomme Nim&eacute;ria. Elle re&ccedil;ois une &eacute;p&eacute;e adapt&eacute; &agrave 
	sa taille de la part de John Snow, avec qui elle s\'entend bien. Lorsqu\'elle va &agrave; Port-R&eacute;al avec son p&egrave;re et sa soeur, Ned lui permet d\'avoir des cours d\'escrime avec Syrio Forel. Elle assiste 
	&agrave; la mort de son p&egrave;re et s\'enfui avec un recruteur de la Garde de Nuit amis de Ned.',1,1,1,true)";																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(16,'Arya Stark', 'Yoren, le recruteur de la Garde de Nuit qui l\'aide &agrave; partir de Port-R&eacute;al lui coupe les cheveux pour qu\'elle passe pour un simple gar&ccedil;on 
	et ne se fasse pas arr&ecirc;ter par les garde de Cersei. Dans le groupe de Yoren il y a les futurs recrus pour la Garde de nuit et des prisonniers dont un homme qui se nomme Jaqen H'Ghar. Lorsque le groupe de recru 
	de la Garde de Nuit se fait attaquer par des gardes &agrave; la recherche du b&acirc;tard de Robert, Arya est fait capturer et emmener &agrave; Harrenhal. Elle parvient &agrave; s\'enfuir avec Gendry le b&acirc;tard 
	de Robert et Tourte-Chaude, un enfant grassouillet gr&acirc;ce &agrave; Jaqen qui semble pouvoir tu&eacute; n\'importe qui pour remerci&eacute; Arya de l\'avoir lib&eacute;r&eacute;. Ce derni&eacute; la retrouve un 
	peu plus loin et lui donne une pi&egrave;ce lui permettant de le rejoindre &agrave; Braavos avec la phrase \"Valar Morghulis\"',1,1,2,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(17,'Arya Stark', 'Accompagn&eacute; de Gendry et Tourte-Chaude, Arya se fait de nouveau captur&eacute; par des hommes, de la \"fraternit&eacute; sans banni&egrave;\" cette fois. 
	Lorsque Sandor Clegan est &eacute;galement ammen&eacute; dans le rep&egrave;re de la fraternit&eacute;, Arya veut qu\'il soit tu&eacute; pour avoir tu&eacute; un ami &grave; Winterfell. Le duel judiciaire entre donne 
	raison &agrave; Sandor qui peut alors partir, se qui d&eacute;sole Arya. Plus tard, lorsqu\'elle s\'enfuit du rep&egrave; de la fraternit&eacute;, elle se fait captur&eacute; par Clegane qui veut la revendre &agrave; 
	sa tante au Eyri&eacute;. Arriv&eacute; au Jummeaux, Arya voit avec stup&eacute;faction le massacre de l\'arm&eacute;e et le loup de Robb Stark. Le cadravre de son fr&egrave;re &eacute;tant montr&eacute; comme un 
	troph&eacute; par les gardes des Frey.',1,1,3,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(18,'Arya Stark', 'Arya r&eacute;cup&egrave;re son &eacute;p&eacute;e sur un homme des Lannister que le Limier tue dans une auberge. Lorsqu\'ils arrivent finalement aux Eyri&eacute;, 
	ils apprennent la mort de la tante d\'Arya. Le plan de ran&ccedil;on tombant &agrave; l\'eau, ils vagabondent dans le Conflant lorsqu\'ils tombent sur Brienne de Torth. Un combat s\en suit entre Brienne et le Limier pour 
	la garde d\'Aria. Le Limier gravement blesser, Arya le laisse agonis&eacute; et part pour Braavos &agrave; bord d\'un b&acirc;teau.',1,1,4,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(19,'Arya Stark', 'Elle arrive finalement &agrave; Braavos. Devant le temple du Dieu Multiface, elle s\'attend &agrave; rencontr&eacute; Jaqen mais ne voit qu\'un homme noir. 
	apr&egrave;s un long moment l\'homme noir revient vers elle et change alors de visage pour qu\'Arya puisse le reconna&icirc;tre comme Jaqen. Elle entre enfin dans le temple o&ugrave; elle sert &agrave; nettoyer le sol, 
	puis les corps des morts. Jaqen lui apprend montre la salle des visages et lui demande de d\'espionn&eacute; puis tu&eacute; avec du poison un homme. Arya voit l\'arriv&eacute; de Meryn Trant, un capitaine de la garde 
	royal ayant particip&eacute; &agrave; la d&eacute;capitation de son p&egrave;re. Elle d&eacute;cide donc d\'utiliser un des visages pour pouvoir l\'assasiner. Malheuresement, ce nom n\'&eacute;tait pas \"demend&eacute;\" 
	par le Dieu Multiface, et devient alors aveugle.',1,1,5,true)";																																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(20, '$robertbaratheon', 'Robert Barth&eacute;on est le roi des 7 couronnes de Westeros depuis la rebellion contre le roi fou Targaryen il y a 15 ans. Il est mari&eacute; &agrave; 
	Cersei par alliance, mais aurais d&ugrave; se marier avec la soeur de Ned Stark qui est morte pendant la rebellion',1,1,0,true)";																						$bdd->prepare($req)->execute();	
	$req = "INSERT INTO information VALUES(21,'Eddard Stark', 'Il se fit d&eacute;capit&eacute; pour trahison et conspiration arp&egrave;s avoir apport&eacute; un message du roi Robert r&eacute;cament d&eacute;c&eacute;d&eacute; 
	lui donnant la r&eacute;gence de Westeros jusqu\'&agrave; la majorit&eacute; de l\'h&eacute;riti&eacute;.',1,1,1,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(22,'Melisandre', 'Melisandre est une pr&eacute;tresse de R\'hllor, une religion qui v&eacute;n&egrave;re le feu. Elle est au c&ocirc;t&eacute; de Stannis 
	Barath&eacute;on &agrave; qui elle offre ses pr&eacute;monitions sur les guerres &agrave; venir',1,1,2,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(23,'Vers Gris', 'Vers Gris est le commandant des immacul&eacute;s et l\'un des conseill&eacute;s de Daenerys Targaryen.',1,1,3,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(24,'Lord Varys', 'Lord Varys est le ma&icirc;tre espion du conseil restreint. C\'est un eunuque tr&egrave;s intelligent. Il est aussi surnomm&eacute; l\'araign&eacute;e.',1,1,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(25,'Lord Varys', 'Lorsque Ned Stark deviendra main du roi, il lui demendera de faire attention et de ne faire confiance &agrave; personne car son enqu&ecirc;te sur la mort 
	de John Arryn pourrai le mettre en dang&eacute;.Arya le verra discut&eacute; avec Illiryo discutant du retour des Targaryen. Apr&egrave;s l\'arrestation de Ned, Varys ira le voir en lui demandant de jur&eacute; 
	loyaut&eacute; &agrave; Jeoffrey pour rest&eacute; en vie. M&ecirc;me si Ned suivit finalement se conseil, il finit tout de m&ecirc;me d&eacute;capit&eacute;.',1,1,0,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(26,'Daenerys Targaryen', 'Daenerys est la fille du Roi fou Aerys II Targaryen, vaicu il y a 15 ans par la rebellion de Robert Barath&eacute;on. Elle est son fr&ecirc; ont d&ugrave; 
	se cacher pendant des ann&eacute;es et sont finalement acceuilli depuis 1 an par Illirio, &agrave; Pentos.',1,1,0,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(27,'Daenerys Targaryen', 'Elle est mari&eacute; contre son gr&eacute; au chef Dothraki : Khal Drogo. Lors des noces, elle re&ccedils des oeufs de Dragon de la par d\'Illirio. 
	Elle &eacute;chappe &agrave; des tentatives d\'assassina de Robert Barath&eacute;on qui souhaite toujours la mort des Targaryen. Elle fini par aim&eacute; Drogo qui fit fondre de l\'or sur la t&ecirc;te de son Viserys, 
	son fr&ecirc;re, de plus en plus violent et incontr&ocirc;lable. Malhereusement Drogo mourru peu apr&ecircs; malgr&ecirc; le sortil&egrave;ge d\'une sorci&egrave;re sacrifiant le foetus de Daenerys pour le soign&eacute;. 
	Daenerys fait br&ucirc;ler la sorci&egrave;re sur le b&ucirc;ch&eacute; fun&eacute;raire de Khal Drogo et va dans les flammes avec les oeufs de dragon. Elle en ressort indemne avec 3 petit dragons.',1,1,1,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(28,'Daenerys Targaryen', 'Quelque Dothrakis et Jorah Mormont suivent Daenerys dans le d&eacute;sert depuis la mort de Drogo. Ils atteignent finalement Quarth. L\'entr&eacute;e leur 
	est interdite mais Xaro Xhoan Daxos se porte garant pour eux et leur permet d\'entr&eacute;. Pyat Pree, le Maître des Conjurateurs, et Xaro Xhoan Daxos volent alors les jeunes dragons de Daenerys, tue les autres membres 
	des Treize et invite Daenerys &agrave; all&eacute; &agrave; l\'H&ocirc;tel des Nonmourants pour y retrouv&eacute; ses dragons. Elle rentre dans la tour qui semble magique, puisqu\'elle n\'a pas d\'entr&eacute; physique 
	et qu\'une fois dedans certaines portes mennent &agrave; des illusions de lieux de Westeros o&ugrave; &agrave; une tente avec Khal Drogo. Daenerys trouve finalement la salle avec ses dragons. Elle est alors encha&icirc;n&eacute; 
	par Pyat Pree, dont les pouvoirs de d&eacute;doublement ne se manifeste que gr&acirc;ce &agrave; la pr&eacute;sence de Daenerys et ses dragons. Mais elle ne se laisse pas faire et ordonne &agrave; ses dragons de cracher 
	du feu en Valyrien, tuant ainsi Pyat Pree et lib&eacute;rant Daenerys et ses dragons. Elle va ensuite cherch&eacute; Xaro Xhoan Daxos qu\'elle fait enferm&eacute; dans le coffre fort de celui-ci, qui est vide. Daenerys 
	et les autres r&eacute;cup&egrave;re des objets dans la demeure de Xaro Xhoan Daxos pour s\'achet&eacute; un bateau.',1,1,2,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(29,'Oberyn Martell', 'Oberyn est un Prince de Dornevet cadet de Doran Martell, il est surnommé \"la Vipère Rouge\".Cet un homme bisexuel et libertin. Il arrive &grave; 
	Port-R&eacute;al pour les noces de Joeffrey. Il cherche surtout &agrave; prouv&eacute; que Tywin Lannister &agrave; donn&eacute; l\'ordre &grave; La Montagne de tu&eacute; la soeur d\'Oberyn et ses enfants. Il est l\un 
	des 3 juges lors le proc&egrave;s de Tyrion pour le meurtre de Joeffrey. Lorsque Tyrion demande un duel judiciare, seul Oberyne se propose d\'&ecirc;tre son champion pour combattre La Montagne, et ainsi avoir sa vengance. 
	Le duel est impressionnant et Oberyn r&eacute;ussi &agrave; vaincre La Montagne, mais avant de l\'achev&eacute; il veut qu\'il dise qui lui &agrave; donn&eacute; l\'ordre de tu&eacute; sa soeur et ses enfants. Dans ses 
	derni&egrave;re forces, La Montagne attrape Oberyn et lui explose le cr&acirc;ne &agrave; avec ses mains sous le regard horrifi&eacute; de la concubine d\'Oberyn, Ellaria Sand.',1,1,4,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(30,'Ellaria Sand', 'Ellaria est la concubine d\'Oberyn. Tout comme lui elle est bisexuel et libertine. Elle est avec lui &agrave; Port-R&eacute;al et assiste impuissante &agrave; 
	la mort sanglante d\'Oberyn par Gregor Clegane.',1,1,4,true)";																																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(31,'Ellaria Sand', 'De retour &agrave; Dorne, elle souhaite une vengance contre les Lannister et envoi une lettre de menace &agrave; Cersei avec le collier de Myrcella, actuellement 
	&agrave; Dorne pour &eacute;pous&eacute; Trystane Martell. Avec l\'aide des b&acirc;tardes d\'Oberyn : Tyene, Nymeria, Obara Sand (les deux premi&egrave;res sont &eacute;galement les filles d\'Ellaria), elle tente de 
	faire assassin&eacute; Jaime et Bronn arriv&eacute; &agrave; Dorne pour r&eacute;cup&eacute;r&eacute; Myrcella. Elles &eacute;chouent, mais Doran Martell leur offre une seconde chance. Elle empoisonne Myrcella d\'un 
	bais&eacute; empoisonn&eacute; juste avant son d&eacute;part pour Port-R&eacute;al.',1,1,5,true)";																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(32,'Ellaria Sand', 'Lorsque le message de la mort de Myrcella parvient &agrave; Doran Martell, Ellaria et les b&acirc;tardes d\'Oberyn tu&egrave;rent Doran et le capitaine de la 
	garde Areo Hotah. Apr&egrave;s la destruction du Septuaire &agrave; Port-R&eacute;al, Ellaria discute d\'une alliance avec Olenna Tyrell pour se veng&eacute; des Lannister.',1,1,6,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(33,'Catelyn Stark', 'Catelyn vient de la famille Tully et est mari&eacute; avec Eddard Stark. Elle est la m&egrave; de Robb, Sansa, Arya, Bran et Rickon. Elle n\'aime pas beacoup 
	John Snow, le b&acirc;tard de Ned.',1,1,0,true)";																																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(34,'Catelyn Stark', 'Apr&egrave;s avoir d&eacute;couvert que les Lannister ont provoqu&eacute;s la tentative de meurtre de son fils Bran, elle va jusqu'&agrave; Port-R&eacue;al 
	pr&eacute;venir Ned, et &agrave; son retour, capture Tyrion Lannister dans une auberge. Elle l\'am&egrave; au Ery&eacute; pour qu\'il y soit jug&eacute;. Mais Tyrion demende un duel judiciaire que Bronn gagne pour 
	lui.',1,1,1,true)";																																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(35,'Sansa Stark', 'Sansa est la plus grande fille de la famille Stark.',1,1,0,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(36,'Sansa Stark', 'Elle se marie &agrave; Ramsey Bolton sous la demande de LittleFinger. Sansa se fait alors viol&eacute; par son nouveau mari.',1,1,4,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(37,'$joffreybaratheon', 'Joffrey Barath&eacute;on est le prince des Sept Royaumes, fils a&icirc;n&eacute; des trois enfants que Cersei et Robert Barath&eacute;on. Il est cruel 
	et pense avoir tout les droits de par sa naissance royale. Tyrion ne se g&egrave;ne pas pour le rem&ecirc;tre &agrave; sa place se qui attise sa col&egrave;re.',1,1,0,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(38,'$joffreybaratheon', 'Il est promi en marriage avec Sansa Stark. Lorsqu\'il est &agrave; Winterfell, il agresse le fils du bouch&eacute; qui s\'entrainai avec Aria. Nymeria 
	lui mort le bras pour prot&eacute;g&eacute; Arya. Lorsque Joeffrey demande r&eacute;paration, Arya fait fuir Nymeria dans la for&ecirc;t et se sera Lady, le loup g&eacute;ant de Sansa qui sera execut&eacute; &agrave; 
	la place. On d&eacute;couvre alors avec les recherches de Ned Stark &agrave; Port-R&eacute;al, que Joeffrey et les 2 autres enfants de Cersei sont des b&acirc;tards incestueux avec Jaime Lannister. Lorsque Robert 
	mourru, il devint roi du tr&ocirc;ne de fer et Ned Stark envoy&eacute; en prison pour trahison. Malgr&eacute; la demande de sa m&egrave;re Cersei de l\'&eacute;pargn&eacute; pour &eacute;vit&eacute; une guerre, 
	Joeffrey le fit d&eacute;capit&eacute;.',1,1,1,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(39,'$joffreybaratheon', 'Lorsqu\'il gouverne, il fait preuve d\'une grande cruaut&eacute; et aime tourment&eacute; Sansa avec qui il est toujours pr&eacute;vu qu\'il se mari. Il 
	fait tu&eacute; tout les b&acirc;tards de Robert qui pourrait pr&eacute;tendre au tr&ocirc;ne de fer. Lors d\'une emeute il re&ccedil;ois de la bouze &agrave; la figure et demende &agrave; se qu\'il soit tous 
	execut&eacute;. Lors de la bataille de la N&eacute;ra, Stannis arrive avec une grande flotte. Joeffrey qui se pavanait jusqu\'&agrave; pr&eacute;sent n\'apporte aucune strat&eacute;gie ou soutient au moral des troupes. 
	Il retourne aux Donjon Rouge lorsqu\'il est demend&eacute; par sa m&egrave;, abandonnant ses hommes. Tyrion du se charg&eacute; de tout pour prot&eacute;g&eacute; la ville. Il remet le titre de main du roi &agrave; 
	son grand-p&egrave;re Tywin Lannister pour avoir sauv&eacute; la ville.',1,1,2,true)";																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(40,'Jaime Lannister', 'Jaime est le fr&ecirc;re jumeaux de la r&ecirc;ne Cersei, et fr&ecirc;re de Tyrion. C\'est un des guerriers les plus talentueux de Westeros. Il est 
	&eacute;galement connu sous le nom de r&eacute;gicide pour avoir tu&eacute; le roi fou au pouvoir avant Robert Barath&eacute;on.',1,1,0,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(41,'Jaime Lannister', 'Jaime est d&eacute;couvert par Brann lors d\'une relation incestueuse avec sa soeur Cersei. Il fit donc chut&eacute; Brann du haut de la tour. Il combat en 
	Ned Stark pour le ramen&eacute; au donjon rouge, mais &eacute,galement pour avoir un adversaire &agrave; sa mesure. Le combat se termine pr&eacute;maturement lorsqu'un de ses gardes entailles la jambe de Ned. Jaime 
	est par la suite d&eacute;couvert comme &eacute;tant le p&egrave;re des h&eacute;riti&eacute; Barath&eacute;on de par sa liaison avec Cersei.',1,1,1,true)";															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(42,'Samwell Tarly', 'Samwell, aussi appel&eacute; Sam est le fils d\'une bonne famille qui, par son manque de courage et son ob&eacute;sit&eacute; &agrave; &eacute;t&eacute; 
	envoy&eacute; au Mur par son p&egrave;re qui pr&eacute;f&egrave;rerait le tu&eacute; dans un \"accident\" de chasse, plut&ocirc;t que de le laiss&eacute; h&eacute;rit&eacute; du domaine. Il rencontre John Snow au Mur. 
	Ils deviennent amis car John est le seul qui ne le maltra&icirc;te pas du fait de son surpoids et son manque de courage.',1,1,1,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(43,'Rick Grimes', 'Rick &eacute;tait sh&eacute;rif et apr&egrave;s avoir re&ccirc;u une balle dans une fusillade, il se r&eacute;veille dans un h&ocirc;pital en ruine.',1,2,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(44,'Rick Grimes', 'Apr&egrave;s son r&eacute;veil, il cherche &agrave; retrouv&eacute; sa femme. Il fait la rencontre d\'un p&egrave;re : Morgan, et de son fils Duane. Il les 
	aide &agrave; r&eacute;cup&eacute;rer des armes dans les ses anciens locaux de sh&eacute;rif. Rick par ensuite, seul, vers Atlanta pour y cherch&eacute; sa femme suivant les indications de Morgan. C\'est l&agrave;-bas 
	qu\'il rencontre Glenn et les autres qui &eacute;tait all&eacute; chercher des vivres et du mat&eacute;riel en ville. Il les aide &agrave; &grave; fuir les morts qui sont &agrave; Atlanta en se couvrant de chair en 
	d&eacute;composition pour r&eacute;cup&eacute;rer un v&eacute;hicule. Il parvient finalement &agrave; rejoindre le campement de survivant o&ugrave; il retrouve finalement sa femme et son fils.',1,2,1,true)";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(45,'Rick Grimes', 'Le convoi de survivant qu\'accompagne Rick s\'arr&ecirc;te &agrave; cause de v&eacute;hicule qui bloquent la route. Le passage d\'une horde fait fuir la fille 
	de Carol dans la for&ecirc;t. Rick par &agrave; sa recherche et la sauve en lui demendant de se cach&eacute; pendant qu\'il &eacute;loigne les marcheurs. Lorsqu\'il revient elle n\'est plus l&agrave;. Tous le groupe 
	se met alors &agrave; sa recherche. Lorsque Carl se fait tirer dessus par erreur par un chasseur. Rick l\'emmene dans la ferme des Greene. Il donne son sang pour soign&eacute; son fils. Par la suite, sa rivalit&eacute; 
	avec Shane pour Lori et Carl empire et fini par la mort de Shane.',1,2,2,true)";																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(46,'Shane Walsh', 'Shane &eacute;tait l\'adjoint et l\'ami de Rick. Apr&egrave;s les &eacute;v&egrave;nements r&eacute;cent, Shane est partie avec Lori et Carl en leur disant que 
	Rick est mort(alors qu\'il est juste dans le coma, mais bien vivant).',1,2,0,true)";																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(47,'Michonne', 'Michonne se d&eacute;place avec deux mort-vivants sans bras ni bouche et rencontre Andrea.',1,2,3,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(48,'Glenn', 'Glenn est un ancien livreur de pizza qui aide les gens dans le besoin autant que possible contre les marcheurs.',1,2,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(49,'Glenn', 'Il devient le petit ami de Maggie qu\'il rencontre avec le groupe de Rick apr&egrave;s la blessure de Carl.',1,2,2,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(50,'Daryl Dixon', 'Daryl est le fr&ecirc;re de Merle. C\est une t&ecirc;te br&ucirc;l&eacute; mais un bon chasseur.',1,2,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(51,'Dale Horvath', 'Dale est un homme ag&eacute; plein de sagesse. Il surveille les alentours du campement pr&egrave;s d\'Atlanta du haut de son Camping-car. Il est &eacute;galement 
	assez dou&eacute; en m&eacute;canique.',1,2,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(52,'Hershel Greene', 'Hershel est le p&egrave;re de la famille Grenne. Il est v&eacute;t&eacute;rinaire mais ses capacit&eacute;s en m&eacute;decine permette de sauv&eacute; Carl.',1,2,2,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(53,'Merle Dixon', 'Merle est le fr&ecirc;re de Daryl. Il est violent et raciste se qui lui vaut peut de sympathie des autres membres du groupe de survivant.',1,2,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(54,'Merle Dixon', 'Apr&egrave;s avoir p&eacute;t&eacute; un boulon, il se retrouve menott&eacute; et abandonn&eacute; sur un toit. lorsque Rick et les autres retournes sur le 
	toit pour le lib&eacute;r&eacute;, ils d&eacute;couvre que Merle c\'est coup&eacute; la main pour se lib&eacute;r&eacute;.',1,2,1,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(55,'Carl Grimes', 'Carl est le jeune fils de 12 ans de Rick et Lori Grimes. Apr&egrave;s le d&eacute;but de la catastrophe, il est emmen&eacute; avec sa m&egrave;re et Shane vers Atlanta 
	et se retrouve finalement avec le groupe de survivant dans un campement.',1,2,0,true)";																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(56,'Carl Grimes', 'Il est ami avec Sophia, une autre enfant dans le campement pr&ecirc;t d\'Atlanta. Il retrouve son p&egrave;re qu\'il croyait mort &agrave; cause de Shane. 
	Lorsque le groupe de survivant partira pour le CDC, il y suivra ses parents.',1,2,1,true)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(57,'Carl Grimes', 'Alors qu\'il observait un cerf pendant les recherches pour retrouv&eacute; Sophia, Carl se fait tir&eacute; dessus par Otis qui chassait le cerf. Il est 
	soign&eacute; par Hershel avec le mat&eacute;riel m&eacute;dical r&eacute;cup&eacute;r&eacute; par Shane et des trasnfusions de sang de Rick. Il souhaite alors se battre contre les r&ocirc;deurs apr&egrave;s avoir 
	vu Sophia tranform&eacute;. Il vole un pistolet et essaye de tir&eacute; sur un r&ocirc;deur prit dans la boue. Carl n\'a pas le courage de tir&eacute; et s\'approche. Le r&ocirc;deur fini par se lib&eacute;r&eacute; 
	de la boue et tente de s\'en prendre &agrave; Carl, qui s\'enfuit. Lorsque Dale meurt &agrave; cause du r&ocirc;deur qui &eacute;tait dans la boue, Carl se sent responsable. Au moment o&ugrave; Rick tua Shane, Carl 
	utilisa son pistolet pour abattre Shane qui s\'est transform&eacute; en r&ocirc;deur.',1,2,2,true)";																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(58,'Beth Greene', 'Beth est une jeune femme assez timide. C\'est la demi soeur de Maggie et la fille d\'Hershel. Elle tente de se sucid&eacute; lorsqu\'elle assiste au massacre 
	de sa m&egrave;re et ses voisins tranform&eacute; en r&ocirc;deurs qui &eacute;tait dans la grange. Elle arrive &agrave; fuir avec une partie du groupe de Rick et de sa famille lorsque la ferme est envahie par une 
	horde de r&ocirc;deur.',1,2,2,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(59,'Eugene Porter', 'Eugene est un scientifique qui &eacute;tudie la maladie des r&ocirc;deur, dont il pr&eacute;tant pouvoir gu&eacute;rir le monde sans en donn&eacute; les 
	d&eacute;tails. Il est avec Abraham et Rosita qui lui serve d\'escorte vers Washington. Ils rencontre Glenn et Tara, puis Maggie, Sacha et Bob. Il rencontre les autres membres du groupe de Rick lorsqu\'il est 
	prisonni&eacute; avec les autres dans un des wagons au Terminus.',1,2,4,true)";																																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(60,'Gustavo Fring', 'Gustavo Fring est &agrave; la t&ecirc;te de Los Pollos Hermanos, une companie de fast food. Il est &eacute;galement &agrave; la t&ecirc;te d\'un 
	r&eacute;seau de vente de meth',1,3,3,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(61,'Walter White', 'Professeur de chimie dans un lyc&eacute;e, il apprend qu\'il est atteint d\'un cancer.',1,3,0,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(62,'Walter White', 'Il produit de la meth (drogue synth&eacute;tique) en grande quantit&eacute; pour Gustavo Fring avec l\'aide de Jesse.',1,3,3,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(63,'Jesse Pinkman', 'Jesse produit de la drogue ill&eacute;galement avant de rencontrer Walter White.',1,3,0,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(64,'Mike Ehrmantraut', 'Mike est &agrave; la fois d&eacute;tective priv&eacute; et chef de la s&eacute;curit&eacute; de \"Los Pollos Hermanas\".',1,3,3,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(65,'Saul Goodman', 'Avocat avide d\'argent, il fera affaire avec Walter White et Jesse.',1,3,0,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(66,'Hank Schrader', 'Hank est agent des stup. Il est &eacute;galement le beau-fr&egrave;re de Walter White.',1,3,0,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(67,'Skyler White', 'Skyler est femme au foyer. Elle est mari&eacute;e &agrave; Walter White.',1,3,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(68,'Marie Schrader', 'Marie est l\'&eacute;pouse de Hank Schrader et la soeur de Skyler White.',1,3,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(69,'Tuco Salamanca', 'Tuco est un psychopathe drogu&eacute; d\'origine mexicaine. Il est le chef d\'un groupe de dealer. Walter White devra faire affaire avec lui pour pouvoir 
	vendre sa meth. Lors de l\'&eacute;change un de ses hommes de mains qui parla &agrave; la place de Tuco se fit battre &agrave; mort par celui-ci. Walter White et Jesse Pinkman en furent terrifi&eacute;.',1,3,1,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(70,'Tuco Salamanca', 'Lorsque sa bande se fit embarqu&eacute; par la brigade des stup, Tuco se cacha dans la voiture de Jesse Pinkman. Il le mena&ccedil;a pour qu\il aille cherch&eacute; 
	Walter White. Il les emmena dans une petite maison o&ugrave; habite son oncle Hector Salamanca en attendant l\'arriv&eacute; de ses cousins pour les emmener au Mexique. Il leur explique son plan de voyage, mais Jesse et 
	Walter White n\'ont pas vraiment envie de partie pour le Mexique avec un type capable de les tu&eacute; &agrave; n\'importe quel moment. Lorsqu\'il d&eacte;couvre que Jesse et Walter tente de le tu&eacute; gr&acirc;ce 
	&agrave; son oncle qui les &agrave; vu mettre du poison. Il se met &agrave; les frapp&eacute; et Jesse parvient &agrave; lui tir&eacute; dessus avec le pistolet que Tuco portait dans le dos. Apr&eacute;s que Jesse et 
	Walter se soit cach&eacute;, Hank arrive en voiture. Tuco lui tire dessus, Hank r&eacute;plique et le tue.',1,3,2,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(71,'Don Hector (Tio) Salamanca', 'Hector Salamanca &eacute; l\'un des plus grand membres du Cartel Mexicain. Ce n\'est maintenant qu\'un vieil homme en fauteil roulant qui ne 
	peut plus parl&eacute; et utilise une sonette pour communiqu&eacute;. Il &eacute;tait dans une petite maison avec Tuco, son neuveu, lorsque celui-ci ammena Wlater White et Jesse Pinkman. Lorsqu\'il fut intterog&eacute; 
	par la brigade des stup sur Jesse Pinkman, il pr&eacute;f&eacute;ra se taire et faire ses besoins pour leurs montr&eacute; qu\il ne les aidera pas.',1,3,2,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(72,'Baelfire', 'Il est le fils de Rumplestiltskin.',1,4,1,true)";																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(73,'Emma Swan', 'Emma est la m&eacute;re naturelle de Henry Mills, qu\'elle a fait adopt&eacute; car elle ne pouvait pas s\'en occup&eacute;.',1,4,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(74,'Mary Margaret Blanchard - Blanche-Neige', 'Mary est une institutrice &agrave; Storybrooke. Elle est tr&egrave;s g&eacute;n&eacute;reuse et s\'occupe de donn&eacute; des cours &agrave; Henry',1,4,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(75,'Henry Mills', 'Henry est le fils naturel d\'Emma et adoptif de Regina Mills dont il porte le nom de famille.',1,4,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(76,'Henry Mills', 'Lorsqu\'il re&ccedil;ois le livre de contes \"Once Upon a Tima\" de Mary, il se met en t&ecirc;te que tout les habitans de Storybrooke sont des personnages de 
	contes. Il ne parvient &agrave; leur rendre leur m&eacute;moire qu\'en mangeant une part de g&acirc;teau empoisonn&eacute; &agrave; la place d\'Emma. Le sortil&egrave;ge d\'amn&eacute;sie prend fin lorsque qu\'il est 
	sauv&eacute; par un v&eacute;ritable bais&eacute; d\'amour de sa m&egrave;re biologique.',1,4,1,true)";																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(77,'$reginamills', 'La M&eacute;chante Reine et maire de Storybrooke.',1,4,0,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(78,'Zelena', 'La M&eacute;chante Sorci&egrave;re de l\'Ouest, elle est la demi-soeur de Regina.',1,4,3,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(79,'David Nolan - le prince Charmant', 'David Nolan est un homme mari&eacute; et dans le coma. Dans le monde fantastique c\'est le prince charmant.',1,4,0,true)";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(80,'David Nolan - le prince Charmant', 'Le Prince Charmant se mari &agrave; Blanche-neige et Blanche-neige est enceinte de Charmant avant que la M&eacute;chante Reine lance le 
	sort les envoyants dans le monde r&eacute;el. Il est bless&eacute; par cette derni&egrave;re, le plaçant donc dans le coma dans le monde r&eacute;el. Il y est mari&eacute; &agrave; Kathryn mais &agrave; son r&eacute;veil 
	du coma, il commence &agrave; avoir des sentiments pour Mary Margaret. Il fini par quitt&eacute; sa femme pour retrouv&eacute; Mary Margaret',1,4,1,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(81,'Monsieur Gold - Rumplestiltskin', 'M. Gold est le propri&eacute;taire d\'une boutique d\'antiquit&eacute; de quelque b&acirc;timents dans Storybrooke. Avant que le sort les 
	envoyant dans le monde r&eacute;el ne soit lanc&eacute;, il &eacute;tait Rumplestiltskin, un magicien avec une face d&eacute;compos&eacute; qui fesait sign&eacute; des contrats magiques aux habitants.',1,4,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(82,'Killian Jones - Capitaine Crochet', 'Killian Jones, est le capitaine du Jolly Roger. Son nom de capitaine crochet lui vient de son crochet qu\'il a &agrave; la place de la 
	main.Il est alli&eacute; &agrave; Cora dans le monde o&ugrave; la magie existe. Ses aventures lui feront rencontr&eacute; Emma et Blanche-Neige, qu\'il aidera &agrave; retourn&eacute; &agrave; Storybrooke. Il passe 
	&eacute;galement le portail vers Storybrooke avec Cora. Crochet cherche alors &agrave; se veng&eacute; de Rumplestiltskin et lui tire dessus, mais se sera Belle qui sera bless&eacute;. Plus tard il parvient &agrave; 
	bless&eacute Rumplestiltskin avec son crochet empoisonn&eacute;. Il fini par emmen&eacute Emma, Rumplestiltskin, Regina, Mary Margaret dans le pays imaginaire pour sauv&eacute; Henri.',1,4,2,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(83,'Teal\'c', 'Teal\'c est un jaffa qui sert les faux dieux goa\'uld. Il est \'primat\' de l\'un d\'eux : Apophis.',1,5,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(84,'Teal\'c', 'Il se rebelle contre son ma&icirc;tre et rejoint l\'&eacute;quipe SG-1 qui l\'accueille avec joie.',1,5,1,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(85,'Ba\'al', 'Ba\'al est un grand ma&icirc;tre Goa\'uld. Il captura et tortura O\'Neill pendant un long moment pour obtenir des informations.',1,5,5,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(86,'Samantha Carter', 'Samantha est une officier scientifique qui travaille pour le Pentagone. Elle est recrut&eacute;e pour le projet SG.',1,5,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(87,'Jack O\'Neill', 'Jack est un colonel de l\'US Air Force. Il int&egrave;gre l\'&eacute;quipe SG-1 dont il devient le chef. Il aime bien faire des blagues m&ecirc;me dans 
	les situations critiques',1,5,0,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(88,'Jack O\'Neill', 'Il se retrouve temporairement avec toutes les connaissances des anciens apr&egrave;s s\'&ecirc;tre approch&eacute; d\'un appareil inconnu. Il se retrouve 
	donc &agrave; parler en ancien jusqu\'&agrave; rencontr&eacute; les Asgard sur leur monde natal.',1,5,1,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(89,'Adria', 'Quand ils retrouv&egrave;rent la trace des Anciens, r&eacute;fugi&eacute;s dans la Voie Lact&eacute;e, les Oris mirent enceinte Vala Mal Doran avec  leurs pouvoirs,
	afin que son enfant : Adria, aussi appel&eacute; L\'Oricy, puisse diriger la guerre contre eux.',1,5,10,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(90,'Daniel Jackson', 'Daniel est &eacute;gyptologue. Il a d&eacute;couvert le fonctionnement de la porte des &eacute;toiles. Il aide SG-1 gr&acirc;ce &agrave; ses connaissances des langues 
	et cultures &eacute;trang&egrave;re.',1,5,0,true)";																																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(91,'Vala Mal Doran', 'Vala est une arnaqueuse qui dupe les gens sur diff&eacute;rentes plan&egrave;tes. Elle rencontre Daniel lorsqu\'elle tente de vol&eacute; le 
	Prom&eacute;th&eacute;.',1,5,8,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(92,'George Hammond', 'Georges Hammond est un g&eacute;n&eacute;ral ag&eacute; qui s\'occupe de command&eacute; le SGC. Il demanda de l\'aide &agrave; Jack O\'Neill pour 
	prot&eacute;g&eacute; la Terre contre les extraterrestre. Il cr&eacute;a 9 &eacute;quipe SG qui devront explor&eacute; la galaxie.',1,5,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(93,'Hank Landry', 'Hank Landry est nomm&eacute; g&eacute;n&eacute;ral et s\'occupe de command&eacute; le SGC apr&egrave;s le d&eacute;part de Jack O\'Neill. C\'est &eacute;galement 
	le p&egrave;re de Carolyn Lam, qu\'il met docteur au SGC.',1,5,9,true)";																																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(94,'Apophis', 'Apophis, le dieu de la nuit dans la mythologie, est une grand ma&icirc;tre Goa\'uld. Il captura Sha\'re et Skaara sur Abydos et en fit des h&ocirc;tes pour sa 
	femme et son fils. Il envoya deux vaisseaux pour conqu&eacute;rir la Terre. Cependant Daniel Jackson parvient &agrave; avoir les coordonn&eacute;es de la porte des &eacute;toile pour infiltr&eacute; les vaisseaux et 
	pouvoir les faires explos&eacute;.',1,5,1,true)";																																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(95,'Apophis', 'Apr&egrave;s sa d&eacute;faite sur la Terre, Apophis est faible et Sokar, un autre ma&icirc;tre Goa\'uld lui prend son territoire. Apophis &agrave; un enfant avec 
	Sha're. Lorsqu\'il devient trop faible pour resist&eacute; &agrave; Sokar, il fuit sur Terre et y demande asile. Il meurt peu apr&egrave;s, et lorsqu Sokar demande au SGC de lui donn&eacute; Apophis, ils lui envois 
	le cadavre de celui-ci. Plus tard, sur Netu, Apophis est retrouv&eacute; vivant, ressuscit&eacute; par Seku pour &ecirc;tre tortur&eacute; &agrave; l\'infini. La rebellion sur cette plan&ecirc;te p&eacute;nitentiaire 
	permet &agrave; Apophis de se lib&eacute;r&eacute; et &agrave; reprendre le pouvoir &agrave; Sokar. Plus tard, il fini par mourrir dans l\'explosion d\'une supernova alors que son vaisseau m&egrave;re est infest&eacute; 
	de r&eacute;plicateur.',1,5,2,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(96,'Sokar', 'Sokar est un ma&icirc;tre Goa\'uld compar&eacute; au diable. Il d&eacute;teste les grand ma&icirc;tre Goa\'uld qui l\'on vaincu opparavant. Il profite de la faiblesse
	d\'Apophis pour reprendre du pouvoir. Il fait m&ecirc;ce enferm&eacute; Apophis sur Netu pour le tortur&eacute;. Lors de l\'attaque de SG1 et de la Tok\'ra, Sokar perdit la vie dans l\'explosion de son vaisseau en orbite 
	autour de Netu et Apophis profita de la confusion pour s\'&eacute;chap&eacute;.',1,5,2,true)";																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(97,'Dean Winchester', 'Dean est le fr&egrave;re de Sam Winchester. Il l\'aide a vaincre des d&eacute;mons depuis la mort de leur m&egrave;re et la disparition de 
	leur p&egrave;re.',1,6,0,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(98,'Dean Winchester', 'Il apprend qu\'il doit servir d\'h&ocirc;te &agrave; l\'archange Gabriel pour combattre Lucifer. Dean refuse de donn&eacute; son corp et tente de trouv&eacute; 
	un autre moyen de sauv&eacute; le monde de l\'apocalypse. Avec son fr&ecirc;re Sam, il va cherch&eacute; les anneaux des cavali&eacute;s de l\'apocalypse. Lorsque Sam finira par accept&eacute; de servir d\'h&ocirc;te 
	&agrave; Lucifer, Dean se servira des anneaux pour l\'emprisonn&eacute; de nouveau.',1,6,5,true)";																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(99,'Sam Winchester', 'Sam est le petit fr&egrave;re de Dean Winchester. C\'est son grand fr&egrave;re qui s\'occupe de lui depuis la mort de leur m&egrave;re et la 
	disparition de leur p&egrave;re.',1,6,0,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(100,'Sam Winchester', 'La lib&eacuteration de Lucifer ayant &eacute;t&eacute; produite. Sam doit lui servir de corp sur Terre. Il refuse, jusqu\'&agrave; que Lucifer menace Dean si il ne 
	lui laissait pas utilis&eacute; son corp. Sam accepte, et est donc contr&ocirc;l&eacute; par Lucifer. Dean parvient en l\'enferm&eacute; dans son ancienne prison avec les anneaux des 4 cavaliers de 
	l\apocalypse.',1,6,5,true)";																																															$bdd->prepare($req)->execute();	
	$req = "INSERT INTO information VALUES(101,'Castiel', 'Castiel est un ange dans le corp d\'un humain ayant accept&eacute; de servire de receptacle sur terre. Il aidera Sam et Dean &agrave; combattre les forces 
	d&eacute;moniaque.',1,6,5,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(102,'Bobby Singer', 'Bobby est un chasseur de cr&eacute;atures surnaturelles et un tr&egrave;s bon ami du p&egrave;re de Sam et Dean.',1,6,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(103,'Ruby', 'Ruby est une jeune femme blonde qui aide les fr&ecirc;res Winchester &agrave; combattre les d&eacute;mons',1,6,3,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(104,'Lucifer', 'Lucifer est le diable incarn&eacute;. Il fut lib&eacute;r&eacute; lorsque Sam tua Lilith, brisant ainsi le dernier sceau de sa prison.',1,6,4,true)";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(105,'Lucifer', 'Il parvient &agrave; avoir un h&ocirc;te temporaire, ne pouvant avoir Sam. Grace &agrave; ses grands pouvoirs, il tue les dieux impis. Sous la contraite, Sam fini 
	par accept&eacute; de servir d\'h&ocirc;te pour Lucifer. Dean r&eacute;ussi finalement &agrave; l\'envoyer de nouveau dans la cage avec les 4 anneaux des cavaliers de l\'apocalypse : La Mort, La Famine, La maladie, 
	et La Guerre',1,6,5,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(106,'Alex Vause', 'Alex est une ancienne trafiquante de drogue. Après une p&eacute;riode de d&eacute;pendance &agrave; la drogue, elle s\'arr&ecirc;te pendant son s&eacute;jour en 
	prison.',1,7,0,true)";																																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(107,'Piper Chapman', 'Piper est une femme bisexuelle condamn&eacute;e pour trafic de drogue 10 ans plus t&ocirc;t.',1,7,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(108,'Piper Chapman', 'Elle se retrouve dans la m&ecirc;me chambre que Claudette, avec  qui elle s\'entend mal au d&eacute;but mais elles finissent par &ecirc;tre amis.',1,7,1,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(109,'Sam Healy', 'Sam est un ancien gardien de prison. Il sert d&eacute;sormais de conseiller dans la prison de la s&eacute;rie.',1,7,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(110,'Galina (Red) Reznikov', 'Galina est une co-d&eacute;tenue de Piper. Elle dirige la cuisine et la communaut&eacute; blanche de la prison.',1,7,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(111,'Suzanne (Crazy Eyes) Warren', 'Suzanne prend Piper pour sa m&egrave;re adoptive et la frappe au visage.',1,7,2,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(112,'Batman', 'Batman est le nom donn&eacute; &agrave Bruce Wayne lorsqu\'il porte son costume de chauve-souris. Il combat les criminels de la ville de Gotham',1,8,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(113,'Bruce Wayne', 'Bruce est un homme d\'affaire &agrave; la t&ecirc;te d\'une grande entreprise. La nuit il porte un masque et combat les criminels et est appel&eacute; Batman.',1,8,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(114,'Commissaire James Gordon', 'James Gordon est un polici&eacute; incorruptible contrairement au reste des flics de Gotham. Il est &eacute;galement le p&egrave;re de Barbara',1,8,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(115,'Le Joker', 'Le Joker est un criminel psychopate avec un sourire &eacute;norme. Il adore faire des pi&egrave;ge &agrave; Batman.',1,8,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(116,'Alfred', 'Alfred est le majordome de la famille Wayne. Il s\'occupa de Bruce apr&egrave;s la mort de ses parents. Alfred sais que Bruce est Batman et l\'aide lors de ses 
	enqu&ecirc;tes.',1,8,0,true)";																																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(117,'Robin', 'Robin est un jeune gar&ccedil;on de cirque, qui apr&egrave; la mort de son p&egrave;re, rejoint Batman pour combattre le crime.',1,8,2,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(118,'Double-Face', 'Double-Face &eacute;tait l\'un des alli&eacute; de Batman lorsqu\'il &eacute;tait Harvey Dent. Il devient un criminel qui choisi le sort de ses victimes &agrave; 
	pile ou face.',1,8,1,true)";																																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(119,'Catwoman', 'Selina Kyle devient catwoman, une cambrioleuse experte en costume de chat. Elle n\'est cependant pas aussi mal&eacute;fique que les autres ennemies de Batman car 
	elle se refuse &agrave; tu&eacute; qui que se soit.',1,8,1,true)";																																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(120,'Eric Cartman', 'Eric Cartman est un petit gar&ccedil;on grassouillet d\'une m&eacute;chancet&eacute; sans limites.',1,9,0,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(121,'Kyle Broflovski', 'Kyle est l\'un des 4 personnages principaux. Il fait partie d\'une famille juive, se dont Cartman en profite pour utilis&eacute; les 
	st&eacute;r&eacute;otypes contre lui.',1,9,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(122,'Kyle Broflovski', 'Il est le meilleur joueur de basket de South Park et souhaite rejoindre une grande &eacute; mais il n\'est ni grand, ni noir et est donc recal&eacute;. 
	Il subit donc une opp&eacute;ration esth&eacute;tique pour chang&eacute; &ccedil;&agrave;. Il fait une nouvelle op&eacute;ration pour annul&eacute; lorsqu\'il d&eacute;couvre que cela ne lui donne que l\'apparence 
	mais pas le fonctionnement normal d\'un athl&egrave;te.',1,9,9,true)";																																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(123,'Kenny McCormick', 'Kenny est le fils d\'une famille extremenent pauvre. Ces paroles sont imcompr&eacute;hensible (sauf par les autres personnages) &agrave; cause de la capuche de son 
	menteau qu\'il ne retire jamais',1,9,0,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(124,'Butters Stotch', 'Butters est un enfant na&Iuml;f de l\'&eacut;cole. Il reste cependant optimiste la majorit&eacute; du temps',1,9,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(125,'M. Mackey', 'M. Mackey est le conseiller d\'orientation de l\'&eacute; de South Park. Il ponctue souvent ses phrases du terme \"M\'Voyez...\"',1,9,0,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(126,'Servietsky', 'Servietsky est une serviette vivante grace &agrave; la puce qui lui est int&eacute;gr&eacute;e. Il est le plus souvent dans les nuages car il a trop fum&eacute;.',1,9,5,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(127,'Randy Marsh', 'Randy est le p&egrave; de Stan. Il est g&eacute;ologue et l\'un des seul scientifique de South Park. Il a un probl&egrave;me avec l\'alcool se qui peut le 
	mettre en mauvaise posture.',1,9,0,true)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(128,'Randy Marsh', 'Apr&egrave;s avoir mang&eacute; chinoi, il est constip&eacute; pendant plusieurs jours lui permettant de faire un gros &eacute;tron. Ses amis au bar, lui 
	propose alors d\'essayer de battre le record du monde du plus gros caca. Il fini finalement a gagn&eacute; avec un &eacute;tron plus gros que lui.',1,9,11,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(129,'Stan Marsh', 'Stan est le fils de Randy Marsh. C\'est l\'un des enfants du groupe d\'amis de South Park. Il est assez intelligent et remarque souvent quand une chose est 
	idiote.',1,9,0,true)";																																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(130,'Chef', 'Chef est le cuisto de la cantine de l\'&eacute;cole. Il aide souvent les enfants &agrave; comprendre certaines choses de la vie et souvent avec une petite chanson.',1,9,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(131,'Chef', 'Lors d\'un &eacute;pisode, Chef &agrave; trouv&eacute; une femme avec qui il va se mari&eacute;. Les enfants font alors la rencontre des parents de Chef qui sont 
	&eacute;cossais. Les enfants font tout pour que Chef reviennent &agrave; la cantine de leur &eacute;cole. Ils d&eacute;couvre que la femme avec qui Chef est sur le point de se mari&eacute; est en fait un succube. 
	Les enfants parviennent &agrave; sauv&eacute; Chef en renvoyant la succube en enfer.',1,9,3,true)";																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(132,'Liane Cartman', 'Liane est la m&egrave;re de Cartman. Elle vit seul avec son fils et le g&acirc;te de jouet et de nourriture. Elle n\'a absolument aucun contr&ocirc;le sur Eric.',1,9,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(133,'Herbert Garrison', 'M. Garrison est le professeur du groupe d\'enfants. Les enfants l\'appel M. Garrison. Il a une petite marrionette appel&eacute; M.Toc. C\'est quelqu\'un 
	d\'assez vulgaire et exentrique.',1,9,0,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(134,'Herbert Garrison', 'Il pense &ecirc;tre une femme dans un corp d\'homme et d&eacute;cide de chang&eacute; de sexe avec une op&eacute;ration chirurgicale. Il reste cependant 
	tr&egrave;s ressemblant &agrave; avant car il garde une voix tr&egrave;s masculine et ne cache pas sa calvicie. M. Esclave le quitte du fait qu\'il ne soit plus un homme. Garrison se fait alors appel&eacute; Janet 
	Garrison ou Mme. Garrison',1,9,9,true)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(135,'Token Black', 'Token est le seul &eacute;l&agraveveve noir de la classe du groupe d\'enfants.',1,9,0,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(136,'Sheila Broflovski', 'Sheila est la m&egrave;re de Kyle et de Ike, ce derni&eacute; &agrave; &eacute;t&eacute; adopt&eacute;. Elle est mari&eacute; &agrave; Gerald Broflovski.',1,9,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(137,'Jesus', 'Jesus est le fils de Dieu. Il ne semble pas poss&eacute;d&eacute; de vrai pouvoir mais aide tout de m&ecirc;me les enfants lorsqu\'ils ont besoin d\'aide.',1,9,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(138,'Leonard Hofstadter', 'Leonard vit en colocation avec Sheldon Cooper &agrave Pasadena. C\'est un physicien geek comme lui. Il est ami avec Howard Wolowitz et Rajesh Koothrappali',1,10,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(139,'Sheldon Cooper', 'Sheldon vit en colocation avec Sheldon Cooper &agrave; Pasadena. C\'est un physicien geek comme lui. Il est ami avec  Howard Wolowitz et Rajesh Koothrappali',1,10,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(140,'Penny', 'Penny est une jeune fille blonde qui s\'installe dans l\'appartement en face de celui de Sheldon et Leonard. Elle fait des petits boulo pour pay&eacute; son loy&eacute.',1,10,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(141,'Howard Wolowitz', 'Howard est un homme petit ami de Sheldon, Leonard et Rajesh. Il est ing&eacute;nieur et travail dans le m&ecirc;me institut que ses amis. Malheuresement pour lui, 
	il vit toujours chez sa m&egrave;re qui &agrave; de nombreux d&eacute;faults.',1,10,0,true)";																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(142,'Rajesh Koothrappali', 'Koothrappali est l\'un du groupe d\'amis. Il est astrophysicien d\'origine indienne. Cependant il est mal &agrave; l\'aise devant les filles et ne parvient 
	plus &agrave; parl&eacute; sauf lorsqu\'il est bourr&eacute;.',1,10,0,true)";																																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(143,'Amy Farrah Fowler', 'Amy est docteur en neurobiologie et fait des experience sur les singes. Elle est d&eacute;couverte comme une partenaire possible pour Sheldon sur un site 
	de rencontre.',1,10,3,true)";																																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(144,'Leslie Winkle', 'Leslie est docteur en physique exp&eacute;rimentale. Elle est plut&ocirc;t manipulatrice d\'homme et s\'embrouille souvent avec Sheldon.',1,10,1,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(145,'Leslie Winkle', 'Apr&egrave;s la rupture de Leonard avec Penny, Leslie tente de se mettre en couple avec Leonard. Elle fini par cass&eacute; lorsque Leonard n\'est pas de son 
	avis pour une th&eacute;orie physique.',1,10,2,true)";																																									$bdd->prepare($req)->execute();
	
	/* infos lieux */
	$req = "INSERT INTO information VALUES(146,'$leseyrie', 'Forteresse imprenable de la maison Arryn. Ce ch&acirc;teau est b&acirc;tit dans les montagne et poss&egrave;de un trou dans la salle du tr&ocirc;ne qui donne 
	sur la vall&eacute; des centaines de m&egrave;tres plus bas. Les ennemies et criminels sont jet&eacute; par ce trou.',2,1,0,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(147,'$lesilesdefer', 'Les &Icirc;les de fer constituent un archipel de sept &icirc;les de tailles tr&egrave;s diff&eacute;rentes qui se trouvent à l\'ouest du territoire du Conflans. 
	Cet Archipel est gouvern&eacute; par la maison Greyjoy. Les gens qui y vivent sont principalement des marins qui gagne leur vie gr&acirc;ce au pillage. La capital de cette r&eacute;gion est Pyke.',2,1,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(148,'$lesilesdefer', 'Theon Greyjoy d&eacute;barque sur les &icirc;les de fer pour cherch&eacute; du renfort de la part de son p&egrave;re. Il y rencontre &eacute;galement sa 
	soeur Asha Greyjoy.',2,1,2,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(149,'Le Mur', 'Le Mur est une gigantesque muraille de glace, de pierre et de magie qui s&eacute;pare le royaume des Sept Couronnes des terres glac&eacute;es et sauvages. Il mesure 
	pr&egrave;s de sept cents pieds de haut et de cent lieues de long d\'est en ouest. Il a &eacute;t&eacute; cr&eacute;e il y a 8000 ans pour emp&ecirc;ch&eacute; que les marcheurs blanc reviennent.',2,1,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(150,'$chateaunoir', 'Ch&acirc;teaunoir est le plus grand fort que poss&egrave;de la Garde de Nuit. Il est coll&eacute; au \"Mur\" qui prot&egrave;ge le royaume des hommes 
	de celui des sauvageons.',2,1,0,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(151,'Vivesaigues', 'Maison ancestral de la famille Tully. Robb et Catelyn Stark s\'y rende pour rendre hommage &agrave; la mort d\un parent Tully.',2,1,3,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(152,'$portreal', 'Port-R&eacute;al est la capital des 7 couronnes de Westeros. C\'est l&agrave; que ce trouve le tr&ocirc;ne de fer. Cette grande ville est domin&eacute 
	par le donjon rouge, qui est le si&egrave;ge de la royaut&eacute;.',2,1,0,true)";																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(153,'Qarth', 'Qarth est une ancienne ville portuaire situ&eacute;e sur la c&ocirc;te sud d\'Essos. Deaneris parvient &agrave; cette ville mais ne semble pas y &ecirc;tre 
	appr&eacute;ci&eacute;. La puissante corporation des Treize g&egrave;re le gouvernement et la protection avec d\'autres ordres. C\'est l&agrave;-bas que se trouve l\'autel des non-mourants.',2,1,2,true)";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(154,'Winterfell', 'Capitale du nord, elle est dirig&eacute;e par la famille Stark depuis plusieurs milliers d\'ann&eacute;es.',2,1,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(155,'Winterfell', 'Apr&egrave;s la chute de Robb Stark, Winterfell appartient d&eacute;sormais &agrave; la famille Bolton.',2,1,5,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(156,'Dorne', 'Dorne est au Sud de Westeros et est dirig&eacute; par la famille Martell.',2,1,4,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(157,'Atlanta', 'Atlanta est la ville dans laquelle se rend Rick à cheval, il y rencontre Glenn et beaucoup d\'autres.',2,2,4,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(158,'Ferme familiale des Greene', 'Cette exploitation fermi&egrave;re est le refuge du groupe de Rick apr&egrave;s que Carl soit bless&eacute;.',2,2,2,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(159,'Prison de The Walking Dead', 'Cette prison est d&eacute;couverte par Rick. Apr&egrave;s un nettoyage des r&ocirc;deurs present, le groupe de survivants s\'y installe',2,2,3,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(160,'Terminus', 'Le Terminus est un lieu indiqu&eacute; par de nombreux panneaux comme un lieu de survit. Il s\'av&egrave;re que les gens qui y vivent ne sont pas si acceuillant 
	que les indications le disent.',2,2,4,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(161,'Terminus', 'Le Terminus est en ruine apr&egrave;s l\'attaque de Carol pour sauver ses amis aux mains des cannibales de la prison',2,2,5,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(162,'Eglise de Gabriel', 'Cette petite &eacute;glise appel&eacute &eacute;glise de Sainte Sarah appartient au pr&ecirc;tre Gabriel que rencontre le groupe de Rick. Elle sert 
	&agrave; la collecte de nourriture qui sera donn&eacute; &agrave; la banque alimentaire. On d&eacute;couvre que Gabriel &agrave; laiss&eacute; verrouill&eacute; les portes et fen&ecirc;tres de son &eacute;glise lorsque 
	les gens sont venu y cherch&eacute; refuge contre les r&ocirc;deurs.',2,2,5,true)";																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(163,'Woodburry', 'Woodburry est une petite ville fortifi&eacute; dirig&eacute; par le \"gouverneur\". Glenn et Maggie y sont tortur&eacute; jusqu\'&agrave; que Rick, Daryl et 
	d\'autres viennent les secourir. Des combats y sont organis&eacute; avec des r&ocirc;deurs encha&icirc;n&eacute;s &grave; c&ocirc;t&eacute;. Dans les salles de tortures du gouverneur, Andrea y perdra la vie contre 
	Milton Mamet revenu &agrave; la vie apr&egrave;s avoir &eacute;t&eacute; abattu par le gouverneur.',2,2,3,true)";																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(164,'Superlab', 'Walter White produira de la meth en grande quantit&eacute; pour Gustavo Fring dans se grand laboratoire cach&eacute; sous une blanchisserie &agrave; Albuquerque.',2,3,3,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(165,'Superlab', 'Walter White et Jesse Pinkman font br&ucirc;l&eacute; le Superlab pour &eacute;vit&eacute; de laiss&eacute; des traces apr&egrave;s la mort de Fring.',2,3,4,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(166,'Maison familiale des White', 'Cette maison est celle de la famille de Walter White. La famille y passe beaucoup de leur temps libre.',2,3,0,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(167,'Maison familiale des White', 'Apr&egrave;s la d&eacute;couverte du trafic de Walter White, et la d&eacute;sertion de la maison par la famille, la maison reste abandonn&eacute;e.
	 Walter White y retourne pour r&eacute;cup&eacute;rer le puissant poison qu\'il y avait cach&eacute;.',2,3,5,true)";																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(168,'Car Wash', 'Station de lavage dans lequel Walter White travaille pour compl&eacute;ter ses revenus en tant que caissier.',2,3,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(169,'Los Pollos Hermanos', 'Los Pollos Hermanos est un fast-food dans lequel se rend Walter White pour conclure affaire avec Gustavo Fring : de l\'argent contre une grande 
	quantit&eacute; de meth.',2,3,3,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(170,'Storybrooke', 'Ville dans le Maine. Tous les personnages de contes y ont &eacute;t&eacute; transport&eacute;s.',2,4,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(171,'Le Pays Imaginaire', 'Monde où vivent Peter Pan et les Enfants Perdus.',2,4,3,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(172,'Agrabah', 'Agrabah est un lieu au climat d&eacute;sertique du Royaume enchant&eacute;. On y trouve les personnages des contes des Milles et une nuits, mais principalement 
	ceux d\'Aladin.',2,4,4,true)";																																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(173,'$laforetenchantee', 'Cette immense for&ecirc;t recouvre une grande partie des royaume enchant&eacute;e. Il y a de nombreux animaux et cr&eacute;atures qui y vivent.',2,4,2,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(174,'Stargate Command (SGC)', 'Base militaire sous une montagne. C\'est l&agrave; qu\'est la porte des &eacute;toiles et que les &eacute;quipes SG partent en exploration 
	de mondes aliens.',2,5,0,true)"; 																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(175,'Base d\'Anubis', 'Cette base d\'Anubis poss&egrave;de une arme des anciens utilis&eacute;e pour d&eacute;truire la porte des &eacute;toiles sur la Terre.',2,5,4,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(176,'Tartarus', 'Anubis utilisa cette plan&egrave;te pour y construire un laboratoire servant &agrave; la cr&eacute;ation d\'une arm&eacute;e de super soldat.',2,5,8,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(177,'Abydos', 'Abydos est une plan&ecirc;te d&eacute;sertique, la premi&egrave;re explor&eacute; par le SGC. Daniel y fait la rencontre de Sha\'re et Skaara lorsque cette plan&ecirc;te 
	&eacute;tait g&egrave;rer par R&agrave;.',2,5,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(178,'Abydos', 'Apophis y capture Sha\'re et Skaara lors de sa prise de pouvoir.',2,5,1,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(179,'Abydos', 'Anubis cherche l\'oeil de R&agrave;, un objet au grand pouvoir. Le SGC accepte de lui donn&eacute; en &eacute;change d\'&eacute;pargn&eacute; le peuple d\'Abydos.
	Mais Anubis tua quand m&ecirc;me les habitants. La plan&egrave;te est donc inhabit&eacute;.',2,5,4,true)";																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(180,'Netu', 'Netu est une lune de Delmak. Elle fut prise par Sokar lors de sa mont&eacute; en puissance. Apophis y sera envoy&eacute; par Sokar pour y &ecirc;tre tortur&eacute; 
	ind&eacute;finiment. La lune fut d&eacute;truite par l\'op&eacute;ration du SG1 et de la Tok\'ra, detruisant &eacute;galement le vaisseau de Sokar.',2,5,2,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(181,'$penitentierdelitchfield', 'Prison dans laquelle se d&eacute;roule l\'histoire. Elle est dirig&eacute; par le D&eacute;partement F&eacute;d&eacute;ral de 
	Correction.',2,7,0,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(182,'L\'asile d\'Arkham', 'L\'asile d\'Arkham est un lieu o&ugrave; sont intern&eacute;s les psycopathe de Gotham',2,8,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(183,'Gotham City', 'Gotham est une grande ville dans laquel Batman combat les criminels.',2,8,0,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(184,'Ecole de South Park', 'L\'eacute;cole &eacute;l&eacute;mentaire de South Park est un lieu imporant dans les aventures des personnages car c\'est l&agrave; que vont en cours 
	les 4 amis Cartman, Kyle, Stan et Kenny.',2,9,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(185,'$cinemadesouthpark', 'Ce cinema est celui o&eacute; se retrouve les enfants de South Park pour voir les films du moment. En g&eacute;n&eacute;ral, les films 
	pr&eacute;sent&eacute;s sont des parodies de films r&eacute;els',2,9,0,true)";																																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(186,'City Wok', 'Le City Wok est un restaurant chinoi dirig&eacute; par Tuong Lu Kim. C\'est &eacute;galement un petit a&eacute;roport : City Airlines, avec 1 seul avion.',2,9,6,true)";$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(187,'Armurerie de Jimbo', 'Cette armurerie appartient &agrave; Jimbo Kern.',2,9,0,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(188,'Les Bos', 'Bar pour lesbienne o&ugrave; se rend Mme.Garrison apr&egrave;s avoir chang&eacute; de sexe. Il finira par &ecirc;tre tent&eacute; et deviendra lesbienne. Le 
	groupe de femme qui y sont, et Janet Garrison aussi, le defendront dans une parodie de \"300\" contre les Perse qui ont rachet&eacute; le bar et veulent y mettre des tapisserie color&eacute;es.',2,9,9,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(189,'Les docks', 'Les docks de South Park est le lieux de rassemblement pour la f&ecirc;te d\'Halloween. C\'est l&agrave; que se d&eacute;roule l\'enqu&egrave;te du groupe de 
	rockeurs Korn et des enfants pour stopper les fant&ocirc;mes pirates.',2,9,3,true)";																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(190,'$leglise', 'C\'est une &eacute;glise catholique dirig&eacute; par le p&egrave;re Maxi.',2,9,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(191,'Appartement de Sheldon et Leonard', 'Cet appartement &eacute;tait habit&eacute; par Sheldon et un colocataire qui n\'en pouvait plus de ses habitudes &eacute;tranges. Leonard 
	arrivant dans la ville et ayant besoin d\'un logement pas trop ch&egrave;re, accepte de passer un contrat avec Sheldon pour habiter dans l\'appartement..',2,10,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(192,'Appartement de Penny', 'Cet appartement est lou&eacute; par Penny et est souvent en d&eacute;sordre, car elle est plut&ocirc;t bordelique.',2,10,0,true)";					$bdd->prepare($req)->execute();
	
	
	/* infos evenements */
	$req = "INSERT INTO information VALUES(193,'Game of Thrones - La chute de Bran','https://www.youtube.com/watch?v=VUXBxLlgpa8',3,1,1,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(194,'$decapitationdunchevalparlamontagne','https://www.youtube.com/watch?v=UpQ-tOGXZiU',3,1,1,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(195,'Les noces pourpres','https://www.youtube.com/watch?v=OuD8tjcggjI',3,1,3,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(196,'La mort de Joffrey','https://www.youtube.com/watch?v=V5K7motTFf8',3,1,4,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(197,'Duel judiciaire Oberyn contre La Montagne','https://www.youtube.com/watch?v=Pr9Do6blB4c',3,1,4,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(198,'La mort de John Snow','https://www.youtube.com/watch?v=HVkHpeW8zJo',3,1,5,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(199,'La mort de Ned Stark','https://www.youtube.com/watch?v=PW6wfXPeJTw',3,1,1,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(200,'$larriveedesmarcheursblancs', 'https://www.youtube.com/watch?v=KrqwgPLWSvg.',3,1,2,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(201,'Le Mariage de Khal Drogo et Daenerys', 'https://www.youtube.com/watch?v=I06PwIyr3lk.',3,1,1,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(202,'La naissance des dragons - Game of Thrones', 'https://www.youtube.com/watch?v=Xxja9kea_1w.',3,1,1,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(203,'La mort de Shane','https://www.youtube.com/watch?v=9L510ov05NI',3,2,2,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(204,'$discoursdericketmortdhershel', 'https://www.youtube.com/watch?v=2Ms9vz8xq8Y',3,2,4,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(205,'La mort de Beth', 'https://www.youtube.com/watch?v=uQngDNh1BBg.',3,2,5,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(206,'La mort de Gustavo Fring','https://www.youtube.com/watch?v=R6CjCEyAJ2s',3,3,4,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(207,'Say my name (Dit mon nom)','https://www.youtube.com/watch?v=C9MGU7krXnQ',3,3,5,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(208,'Dealer prudent', 'https://www.youtube.com/watch?v=tVI29CDJKno',3,3,2,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(209,'Jesse Pinkman donne des instructions aux scientifiques de Gus', 'https://www.youtube.com/watch?v=FlUzC89q7UE',3,3,4,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(210,'$debutdelepisode1','https://www.youtube.com/watch?v=Gz0ExmgMGIk',3,3,1,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(211,'La mort de Neal','https://www.youtube.com/watch?v=lMXXCDe7n1U',3,4,3,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(212,'Le mariage de Belle et Rumplestiltskin','https://www.youtube.com/watch?v=UPV90t8afB0',3,4,3,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(213,'$laresurrectiondemalefique','https://www.youtube.com/watch?v=EW9vdjYJBcc',3,4,4,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(214,'Bataille de la super porte','https://www.youtube.com/watch?v=FRIvaO3i5EM',3,5,9,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(215,'$decollagedupromethee','https://www.youtube.com/watch?v=-Xdlr30G6PM',3,5,6,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(216,'Stargate SG1 O\'Neill et l\'ascenceur','https://www.youtube.com/watch?v=BljU3P63MSw',3,5,6,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(217,'Stargate SG1 L\'histoire sans fin','https://www.youtube.com/watch?v=3rJqJDhgHiQ',3,5,4,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(218,'Castiel regarde un film','http://www.dailymotion.com/video/xmolzy_supernatural-scene-en-francais-avec-castiel_tv',3,6,4,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(219,'PUDDING !','https://www.youtube.com/watch?v=gzi7To5ZkSA',3,6,5,true)";																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(220,'Batman contre Le Joker','https://www.youtube.com/watch?v=0l4rukfbwIU',3,8,2,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(221,'Le plus gros caca du monde', 'https://www.youtube.com/watch?v=8WmOFZIMDm0',3,9,11,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(222,'$southparklevolutionsuivantmmmegarrison','https://www.youtube.com/watch?v=F9NPnKZkF-Y',3,9,10,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(223,'Les rouquins!!!','https://www.youtube.com/watch?v=Mpr3n9tkid8',3,9,9,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(224,'Nan le chat!', 'https://www.youtube.com/watch?v=UT5tZkKVPFg&list=PLCLrui1lmkFHOb3LPyBXM5piX40P4j6Hp&index=6',3,9,1,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(225,'Alerte au gogole!', 'https://www.youtube.com/watch?v=NzT2y9S60U0&index=33&list=PLCLrui1lmkFHOb3LPyBXM5piX40P4j6Hp',3,9,4,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(226,'Maman, mes chiottes !', 'https://www.youtube.com/watch?v=jhOZf3p3w5U',3,9,10,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(227,'Cartman chie sur le bureau de Garrison !', 'https://www.youtube.com/watch?v=3G78eKSy0D0&index=4&list=RDaO0fWOMJGEI',3,9,12,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(228,'$sheldondrogue','https://www.youtube.com/watch?v=peyUmtgAfZU',3,10,2,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(229,'The Big Bang Theory - Belles poutres','https://www.youtube.com/watch?v=rYi6jM21S0Y',3,10,3,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(230,'$chansondhowardpourbernadette', 'https://www.youtube.com/watch?v=W8ivdA0ELgw',3,10,7,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(231,'Sheldon souri', 'https://www.youtube.com/watch?v=g1p5lGyf5cQ&list=RDQON5MmkWybU&index=5',3,10,2,true)";																		$bdd->prepare($req)->execute();
	
	/* infos interviews */
	$req = "INSERT INTO information VALUES(232,'$interviewdandrewlincoln', 'https://www.youtube.com/watch?v=w0FQsmOllIA',4,2,0,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(233,'Inside the Walking Dead Documentary vostfr', 'https://www.youtube.com/watch?v=iFk1VmGx8Ow',4,2,5,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(234,'Norman Reedus Interview vostfr', 'https://www.youtube.com/watch?v=eDAL8u7_ZNM',4,2,5,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(235,'$interviewdesacteursetrealisateursavantlasaison2','https://www.youtube.com/watch?v=--jx-ZKmHkE',4,1,2,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(236,'Interview des acteurs avant le lancement de la saison 6','https://www.youtube.com/watch?v=hX-btYt5caY',4,1,6,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(237,'Supernatural Comic Con 2015','https://www.youtube.com/watch?v=nvMTCXOWEkU',4,6,10,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(238,'Interview de Laura Prepon et Laverne Cox','https://www.youtube.com/watch?v=ZZupBPrGefw',4,7,3,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(239,'Reportage sur les voix françaises de South Park', 'https://www.youtube.com/watch?v=y7g1Kp2RY_0',4,9,10,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(240,'Saison 5 Featurette Behind the scenes ChicksNGuns', 'https://www.youtube.com/watch?v=1-Heb9RBiOA',4,3,5,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(241,'Once Upon A Time - Panel Comic Con 2015', 'https://www.youtube.com/watch?v=ABcObT0a6Xo',4,4,5,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(242,'Once Upon A Time - Panel Comic Con 2014', 'https://www.youtube.com/watch?v=52HXMQPJvhI',4,4,4,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(243,'The Big Bang Theory - Access All Areas vostfr', 'https://www.youtube.com/watch?v=I7-x3A9bL0I',4,10,7,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(244,'interview jim parsons craig ferguson vostfr', 'https://www.youtube.com/watch?v=hokiItBU_rE',4,10,7,true)";																	$bdd->prepare($req)->execute();
	
	$req = "INSERT INTO information VALUES(245,'Tyrion Lannister', 'texte 1.',1,1,0,false)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(246,'Tyrion Lannister', 'texte 2.',1,1,0,false)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(247,'Tyrion Lannister', 'texte 3.',1,1,0,false)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(248,'Tyrion Lannister', 'texte 4.',1,1,0,false)";																																$bdd->prepare($req)->execute();
	
	
	/* comptes */
	$req = "INSERT INTO user VALUES(1,'user','user','',0,0)";																																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO user VALUES(2,'modo','modo','modo@modos.fr',1,1)";																																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO user VALUES(3,'admin','admin','admin@admins.fr',2,0)";																																				$bdd->prepare($req)->execute();
	
	////////////////////////////THE WAKING DEAD//////////////////////////////////
	$req = "INSERT INTO information VALUES(530,'Le Gouverneur', 'Le Gouverneur est le surnom donn&eacute; &agrave; Philip Blake. Cet homme dirige la ville fortifi&eacue; de Woodburry. Malgr&eacute; son apparence de 
	protecteur qu\'il se donne devant les habitants, il cache de lourd secrets. Avec ses hommes de mains, il attaque des militaires pour leur vol&eacute; des provisions et il garde sa fille transform&eacute; chez lui. 
	Lui et ses hommes ont trouv&eacute; Merle lorsqu\'il avait la main tranch&eacute; et le fit soign&eacute; pour le recrut&eacute;. Il s\'attaquera &agrave; la prison dans laquelle le groupe de Rick se trouve apr&egrave;s 
	avoir obtenu des informations de Glenn et Maggie qu\'il &agrave; tortur&eacute;. Sa premi&egrave;re attaque &eacute;choue, alors il arrive &agrave; convaincre les habitants de Woodburry qu\'il faut attaqu&eacute; 
	la prison. Les habitants n\'&eacute;tant pas pr&eacute;par&eacute;, ils fuient le combat lorsque le groupe de Rick r&eacute;pliqua. Fou de rage, le gouverneur tira sur les habitants de Woodburry et partit avec ses 
	hommes de mains.',1,2,3,true)";																																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Carol Peletier', 'Carol est mari&eacute; &agrave; Ed avec qui elle &agrave; une fille Sophia. Elle est plut&ocirc;t craintive et soumise &agrave; son mari qui la frappe.',1,2,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Carol Peletier', 'Lorsque le groupe se d&eacute;place, elle perd sa fille pendant le passage de la horde. Elle est alors effondr&eacute; et prend du temps avant de reprendre 
	ses esprit. Se fut de nouveau un choc lors du massacre de la grange et la d&eacute;couverte de sa fille transform&eacute; puis abattu.',1,2,2,true)";																	$bdd->prepare($req)->execute();
	////////////////////////////BREAKING BAD//////////////////////////////////// +3 perso
	$req = "INSERT INTO information VALUES(530,'Walter White Junior', 'Walter Junior est le fils de Walter et Skyler White. Il a 17 ans et est atteind du paralisye c&eacute;r&eacute;brale affectant son language et son 
	d&eacute;placement, l\'obligeant &agrave; utilis&eacute; des b&eacute;quille.',1,2,0,true)";																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Walter White Junior', 'Il est surnomm&eacute; Flynn par ses amis. Lorsque Skyler parlera &agrave; sa soeur de mani&egrave;re d&eacute;tourn&eacute;, celle-ci pensera que 
	Skyler parle de Junior. Hank lui fera alors la moral en lui montrant se que deviennent les junkies. Le refut de son p&egrave;re &agrave; se soign&eacute; ne lui plait pas et il lui fait savoir. Plus tard, lorsqu\'il 
	se fait prendre pour avoir achet&eacute; de l\'alcool avant l\'&agrave;ge l&eacute;gal, il demande &agrave; Hank de venir le cherch&eacute; plut&ocirc;tque son p&egrave;re.',1,3,1,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Bogdan Wolynetz', 'Bogdan Wolynetz est le propri&eacute;taire de Car Wash, la station de lavage de voiture dans laquelle travaille Walter White pour gagn&eacute; un peu 
	plus d\'argent. Ce derni&eacute; le surnomme \"Gros sourcils\".',1,3,0,true)";																																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Lydia Rodarte-Quayle', 'Lydia Rodarte-Quayle est une m&egrave;re qui s\'occupe de sa fille Kiira. Elle travaillai pour Gustavo Fring pour le transport de drogue. Apr&egrave;s 
	sa chute, elle travaille avec l\'&eacute;quipe de Walter White. Sa peur de se retrouv&eacute; en priso, &eacute;loign&eacute; de sa fille l\'angoisse &eacute;norm&eacute;ment et elle en devient limite parano. Mike 
	menacera sa fille pour qu\'elle ne les trahisse pas pour &eacute;vit&eacute; la prison. Todd tomba amoureux d\'elle sans qu\'elle n\'y pr&ecirc;te attention. Sa mort fut caus&eacute; par Walter White qui rempla&ccedil;a 
	le sachet de st&eacute;via qu\'elle prend habituellement par du poison.',1,3,5,true)";																																	$bdd->prepare($req)->execute();
	////////////////////////////////STARGATE SG-1/////////////////////////////// +4 perso +1 ou 2 event
	$req = "INSERT INTO information VALUES(530,'Jacob Carter', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Jacob Carter', 'Malade d\'un cancer, il est dans un h&ocirc;pital. Hammond et Carter viennent le voir pour lui propos&eacute; d\'all&eacute; sur une autre plan&egrave;te pour 
	y &egrave;tre soign&eacute;. Il deviendra alors l\'h&ocirc;te de Selmak, un Tok\'Ra.',1,5,1,true)";																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Janet Fraiser', 'Janet Fraiser est l\'officier m&eacute;dical du SGC. Elle s\'occupe d\'analys&eacute; les &eacute;quipes SG lorsqu\'il rentre de missions ainsi que les 
	sp&eacute;cimens organiques d&eacute;couvert.',1,5,0,true)";																																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Bra\'tac', 'Bra\'tac est un Goa\'uld originaire de Chulak comme Teal\'c. Il est chef de la garde d\'Apophis.',1,5,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Bra\'tac', 'Il fini par trahir ses ma&icirc;tre Goa\'uld qui se font pass&eacute; pour des dieux. Son amiti&eacute; avec Teal\'c lui permet de le r&eacute;sonn&eacute; et 
	le faire &eacute;galement se rebell&eacute;.',1,5,0,true)";																																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Stargate L'arche de la vérité La fin des Oris', 'https://www.youtube.com/watch?v=-Bi-JzDkodk',3,5,10,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Jack O\'Neill et Ba\'al', 'https://www.youtube.com/watch?v=EONuvhg1P7s',3,5,2,true)";																						$bdd->prepare($req)->execute();
	//////////////////////////////THE BIG BANG THEORY/////////////////////////// + 3 lieux (magasin de bd,resto de penny et cantine)
	$req = "INSERT INTO information VALUES(530,'Magasin de BD', 'Magasin de BD dans lequel se retrouve le groupe d\'amis. Ils y ach&eacute;te &eacute;galement des articles divers de l\'univers des Comics. Stuart Bloom en 
	est le propri&eacute;taire.',2,10,1,true)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Cafeteria', 'Cafeteria de l\'universit&eacute; des personnages. Ils s\'y retrouve presque chaque midi et parfois le matin.',2,10,1,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Cheescake Factory', 'Le Cheescake Factory est un restaurant o&ugrave; Penny travaille comme serveurse quand elle n\'a pas trouv&eacute; de travail d\'actrice.',2,10,1,true)";	bdd->prepare($req)->execute();
	
	//RAJOUTER PRISON BREAK
	$req = "INSERT INTO information VALUES(530,'Michael Schofield', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Theodore BagWell', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Alexander Mahone', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Lincoln Burrows', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Sara Tancredi', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Brad Bellick', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Benjamin Miles Franklin', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'John Abruzzi', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Paul Kellerman', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Fernando Sucre', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Gretchen Morgan', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Lincoln Junior Burrows', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Charles Westmoreland', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(530,'Henry Pope', 'Jacob Carter est le p&egravere de Samantha Carte. C\'est un ancien g&eacute;n&eacute;ral &agrave; la retraite.',1,5,0,true)";								$bdd->prepare($req)->execute();
	
?>