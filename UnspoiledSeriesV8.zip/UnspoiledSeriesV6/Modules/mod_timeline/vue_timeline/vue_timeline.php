<meta charset="utf-8" />

<?php
class VueTimeline {

	static function afficherTimeline($serie) {
	
		if (!isset($_POST['saisonChoisi'])) {	//initialise saisonChoisi à 0 si elle n'est pas définie
			$idSaison = "0";
		} else {
			$idSaison = $_POST['saisonChoisi'];
		}
		if (isset($_POST['categorie_choisi']) && isset($_POST['saisonChoisi']) && isset($_POST['serieChoisi'])) { //permet lors du submit du formulaire de renvoyer vers la page correspondante
			switch ($_POST['categorie_choisi']) {	//récupère la bonne valeur plutot que le nom du bouton(pour ne pas avoir des bouton appelé 1, 2, 3, 4)
				case "Personnages":
					$categorie = 1;
				break;
				case "Lieux":
					$categorie = 2;
				break;
				case "Evenements":
					$categorie = 3;
				break;
				case "Interviews":
					$categorie = 4;
				break;
			}
			$saisonchoisi = $_POST['saisonChoisi'];
			$seriechoisi = $_POST['serieChoisi'];
			header('Location: http://localhost/UnspoiledSeriesV6/index.php?module=informations&action='. $categorie .'&idSerie='. $seriechoisi .'&idSaison='. $saisonchoisi .'');
			exit();
		} else {}
		?>
	
		<div class="container">
			<form method="post" action="#" onchange="AfficheRange()" onkeyup="AfficheRange()">
				<div class="col-md-12">
					<h1 id="labelAccueil">INFOS SUR <?php echo $serie["nom_serie"];?>
				</div>
				<div class="imgserie">
					<img src="./images/series/<?php echo $serie["nom_serie"];?>.jpg"  alt="Image de <?php echo $serie['nom_serie'];?>" width="150px" height="230px">
				 </div>
				<?php $idSaison="0"; ?>
				<div class="col-md-12" id="timeline">
					<h2>Jusqu'&agrave; quelle saison avez vous avanc&eacute; dans <?php echo $serie["nom_serie"];?> : </h2><br>
					<fieldset>
						<input id="Range" type="range" step="1" min="0" max=<?php echo $serie["nb_saison_serie"];?> value=<?php echo $idSaison;?>>
						<output id="AfficheValue">Saison 0</script></output>
					</fieldset>
					<input type="hidden" id="saisonChoisi" name="saisonChoisi" value="<?php echo $idSaison;?>"/>
					<input type="hidden" id="serieChoisi" name="serieChoisi" value="<?php echo $serie["id_serie"];?>"/>
					<h3><input type="submit" name="categorie_choisi" value="Personnages" id="personnages" /></h3>	<!-- catégorie -->
					<h3><input type="submit" name="categorie_choisi" value="Lieux" id="lieux" /></h3>
					<h3><input type="submit" name="categorie_choisi" value="Evenements" id="evenements" /></h3>
					<h3><input type="submit" name="categorie_choisi" value="Interviews" id="interviews" /></h3>
				</div>
			</form>
			<script>
			function AfficheRange() {
				var R=document.getElementById("Range").value;
				document.getElementById("AfficheValue").innerHTML="Saison "+R;
				document.getElementById("saisonChoisi").value=document.getElementById("Range").value;
			}
</script>
			
		</div>
		
		<?php 
		
	}
}
?>
