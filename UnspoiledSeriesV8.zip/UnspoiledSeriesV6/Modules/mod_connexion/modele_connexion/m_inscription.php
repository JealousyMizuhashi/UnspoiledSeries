<?php
// if(!defined("TEST_INCLUDE")
// die("Vous ne pouvez pas accéder à cette page du site");
class ModeleInscription extends DBMapper {
	public static function ajouterUser($login, $password, $email, $typeCompte, $serieCompte) {
		$req = self::$database->prepare ( "INSERT INTO `user`(`login`, `password`, `email`, `typeCompte`, `serieCompte`) VALUES (?, ?, ?, ?, ?)" );
		$array [0] = $login;
		$array [1] = $password; // TODO HASHAGE DU MOT DE PASSE !
		$array [2] = $email;
		$array [3] = $typeCompte;
		$array [4] = $serieCompte;
		$count = $req->execute ( $array );

		if ($count === false)
			return false;
		if ($count === 0)
			return false;
		if ($count != 0 && $count != false) {
			return true;
		}
	}
	public static function utilisateurExisteDansLaBase($pseudo) {
		$req = self::$database->prepare ( "select * from user where login=?" );
		$array [0] = $pseudo;
		$req->execute ( $array );
		$count = $req->rowCount ();
		if ($count === 0)
			return false;
		if ($count > 0)
			return true;
	}
	//pour récuperer les series pour ensuite l'utiliser dans un select sur la page vue si l'on veut être modérateur d'une série
	public static function getSeries() {
		$req = self::$database->prepare("SELECT id_serie, nom_serie from serie ORDER BY nom_serie");
		$req->execute();
		$series = $req->fetchAll(PDO::FETCH_ASSOC);
		return $series;
	}
}

?>
