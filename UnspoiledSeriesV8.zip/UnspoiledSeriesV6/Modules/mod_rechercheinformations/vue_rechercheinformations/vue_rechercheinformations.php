
<?php
class VueRechercheInformations {
	public static function afficherRechercheInformations($resultats, $requete) {
		if (empty ( $requete )) {
			echo ("<br> Vous devez saisir un mot cl�");
			echo $resultats;
		} 

		else {
			echo ('
					<h1 id="labelAccueil">R�sultats pour ' . $requete . ' : </h1>
			');
			
			if (empty ( $resultats )) {
				echo ("
					<h1 id=\"labelAccueil\" class='fg-white text-left'>Aucune informations ne correspond a \"$requete\"</h1>
					");
			} else {
			
		switch ($_GET['idCategorie']) {
			case 1:  $categorie = "personnages"; $taille = "230px"; break;
			case 2:  $categorie = "lieux"; $taille = "105px"; break;
			case 3:  $categorie = "evenements"; $taille = "105px"; break;
			case 4:  $categorie = "interviews"; $taille = "105px"; break;		
		}
		?>
		<div class="container">
			<div class="form-group2">
				<input type="button" value="retour &agrave; la liste d'informations" onClick="document.location.href = document.referrer" />
			</div>
			</br>
		<?php
				foreach ( $resultats as $value ) {
					
		 			if ($value['info_valide'] == 1) {
						switch($_GET['idCategorie']) {
							case 1:
								?>
								<a href="index.php?module=donnees&action=<?php echo $_GET['idCategorie'];?>&idSerie=<?php echo $_GET['idSerie'];?>&idSaison=<?php echo $_GET['idSaison'];?>&nom=<?php echo $value['nom_information'];?>">
								<?php
								break;
							case 2:
								?>
								<a href="index.php?module=donnees&action=<?php echo $_GET['idCategorie'];?>&idSerie=<?php echo $_GET['idSerie'];?>&idSaison=<?php echo $_GET['idSaison'];?>&nom=<?php echo $value['nom_information'];?>">
								<?php
								break;
							case 3:
								?>
								<a href=<?php echo $value['texte_information'];?>  target="_blank">
								<?php
								break;
							case 4:
								?>
								<a href=<?php echo $value['texte_information'];?>  target="_blank">
								<?php
								break;
						}
						?>
							<div class="col-md-2">  
								<figure style="overflow:hidden;position:relative">
									<img src="./images/<?php echo $categorie;?>/<?php echo $value['nom_information'];?>.jpg"  alt="Image de <?php echo $value['nom_information'];?>" width="100%" height=<?php echo $taille;?>>
									<figcaption>
										<p id="auteur"><?php echo $value['nom_information'];?></p>
									</figcaption>
								</figure>
							</div>
						</a>
					<?php
					}
					
		 				
				}
				?>
				</div>
				<?php
			}
		}
		
	}
}

?>

