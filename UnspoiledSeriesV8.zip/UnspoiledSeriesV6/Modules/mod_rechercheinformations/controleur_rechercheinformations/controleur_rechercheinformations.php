<?php

$module ="rechercheinformations";
require_once ("./Modules/mod_$module/vue_$module/vue_$module.php");
require_once ("./Modules/mod_$module/modele_$module/modele_$module.php");

class ControleurRechercheInformations extends ControleurGenerique {
	
	public function afficherResultatsRechercheInformations ($requete) {
			$resultats = ModeleRechercheInformations::getResultatsRechercheInformations($requete); 	
			$this->constructView("VueRechercheInformations", "afficherRechercheInformations", array($resultats, $requete));
			unset($_POST['requete']);
		
	}
}
?>
