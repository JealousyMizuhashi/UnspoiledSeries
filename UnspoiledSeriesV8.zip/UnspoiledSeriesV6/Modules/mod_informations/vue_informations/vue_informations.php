<?php
class VueInformations {

	static function afficherInfos($stats) {	
		
		switch ($_GET['action']) {
			case 1: ?> <h1 id="labelAccueil">Personnages</h1> <?php $categorie = "personnages"; $taille = "230px"; break;
			case 2: ?> <h1 id="labelAccueil">Lieux</h1> <?php $categorie = "lieux"; $taille = "105px"; break;
			case 3: ?> <h1 id="labelAccueil">Evenements</h1> <?php $categorie = "evenements"; $taille = "105px"; break;
			case 4: ?> <h1 id="labelAccueil">Interviews</h1> <?php $categorie = "interviews"; $taille = "105px"; break;		
		}
		
		?>	
		<div class="container">
			<!-- rajout d'un recherche poour rechercher une information index.php?module=informations&action=1&idSerie=1&idSaison=0-->
					<div class="form-group3">
					<form class="navbar-form" role="search" method="POST" action="index.php?module=rechercheinformations&action=rechercheParSaisie&idCategorie=<?php echo $_GET['action'];?>&idSerie=<?php echo $_GET['idSerie'];?>&idSaison=<?php echo $_GET['idSaison'];?>">
							<input type="text" name="requete" class="form-control" placeholder="Recherche d'une information" required>
							<button type="submit" class="btn btn-default">Rechercher !</button>
					</form>
					<form class="navbar-form" method="POST" action="index.php?module=timeline&id=<?php echo $_GET['idSerie'];?>">
							<input type="hidden" id="saisonChoisi" name="saisonChoisi" value=""/>
							<button type="submit" class="btn btn-default">Retour</button>
					</form>
					</div>
					</br>
			<section id="ligne" class="row">
					
				
				<?php
				foreach ($stats as $value) {
					if ($value['info_valide'] == 1) {
						switch($_GET['action']) {
							case 1:
								?>
								<a href="index.php?module=donnees&action=<?php echo $_GET['action'];?>&idSerie=<?php echo $_GET['idSerie'];?>&idSaison=<?php echo $_GET['idSaison'];?>&nom=<?php echo $value['nom_information'];?>">
								<?php
								break;
							case 2:
								?>
								<a href="index.php?module=donnees&action=<?php echo $_GET['action'];?>&idSerie=<?php echo $_GET['idSerie'];?>&idSaison=<?php echo $_GET['idSaison'];?>&nom=<?php echo $value['nom_information'];?>">
								<?php
								break;
							case 3:
								?>
								<a href=<?php echo $value['texte_information'];?>  target="_blank">
								<?php
								break;
							case 4:
								?>
								<a href=<?php echo $value['texte_information'];?>  target="_blank">
								<?php
								break;
						}
						?>
							<div class="col-sm-3 col-md-2 col-lg-2">  
								<figure style="overflow:hidden;position:relative">
									<img src="./images/<?php echo $categorie;?>/<?php echo $value['nom_information'];?>.jpg"  alt="Image de <?php echo $value['nom_information'];?>" width="100%" height=<?php echo $taille;?>>
									<figcaption>
										<p id="auteur"><?php echo $value['nom_information'];?></p>
									</figcaption>
								</figure>
							</div>
						</a>
					<?php
					}
				}
				?>
			</section>
		</div>
		<?php		
	}
}
?>
