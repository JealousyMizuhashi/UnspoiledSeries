<?php
require_once ("Modules/mod_moderateur/modele_moderateur/m_moderateur.php");
require_once ("Modules/mod_moderateur/vue_moderateur/v_moderateur.php");
class ControleurModerateur extends ControleurGenerique {
	
	public function ajouter() {
		$existeDansLaBase = ModeleModerateur::informationExistante ($_POST['serie'], $_POST['categorie'], $_POST ['nomInfo'], $_POST['texteInfo'], $_POST['saison']);
		if (! $existeDansLaBase) {
			$ajoutReussie = ModeleModerateur::ajouterInfo ($_POST['serie'], $_POST['categorie'], $_POST['nomInfo'], $_POST['texteInfo'], $_POST['saison']);
			if ($ajoutReussie) {
				$this->constructView ( 'VueModerateur', 'afficherAjoutReussie', array () );
			} else
				$this->constructView ( 'VueModerateur', 'afficherAjoutRatee', array () );
		} else {
			$this->constructView ( 'VueModerateur', 'afficherInfoDejaExistante', array () );
		}
	}
	public function afficherFormulaireAjout() {//pour afficher la page de formulaire d'ajout du moderateur
		$series = ModeleModerateur::getSeries();
		$seriecompte = ModeleModerateur::getSerieCompte();
		$_SESSION['seriecompte'] = $seriecompte;
		$this->constructView ( 'VueModerateur', 'afficherFormulaireAjout', array ($series, $seriecompte) );
	}
	public function afficherFormulaireVoir() {//pour afficher la page de vue des informations proposer par les utilisateurs aux modérateurs
		$series = ModeleModerateur::getSeries();
		$resultcompte = ModeleModerateur::getSerieCompte();
		foreach ($resultcompte as $value3) {
			$_SESSION['seriecompte'] = $value3['serieCompte'];
		}
		$propositions = ModeleModerateur::getPropositions();
		$this->constructView ( 'VueModerateur', 'afficherFormulaireVoir', array ($series, $propositions) );
	}
	public function ajout() {
		if (isset($_POST['serie']) && isset($_POST['categorie']) &&  isset($_POST['nomInfo']) && isset($_POST['texteInfo']) && isset($_POST['saison'])) {
			$this->ajouter ();
		} else {
			$this->afficherFormulaireAjout ();
		}
	}
	public function voir() {
			$this->afficherFormulaireVoir ();
	}
}
?>
