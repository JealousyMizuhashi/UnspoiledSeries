<?php
class VueModerateur {
	
	public static function afficherFormulaireAjout($series, $seriecompte) {
	?>
		<h1 id="labelAccueil">Suggestion d'information</h1>

		<div id="formulaire" class="container">
			<div class="form-group4">
				<form  action="index.php?module=moderateur&action=ajoutInformations" method="POST">
					<?php
					foreach ($seriecompte as $value) {
						foreach ($series as $value2) {
							if($value2['id_serie']==$value['serieCompte']){
								?><h3 class="texteblanc"><?php echo $value2['nom_serie']; ?></h3><?php
							}
						}
						?>
						
						<input type="hidden" id="serie" name="serie" value=<?php echo $value['serieCompte'];?> />
					<?php
					}
					?>
					<input name="nomInfo" type="text" placeholder="NOM" id="nomInfo" required>
					<input name="saison" type="text" placeholder="SAISON" id="saison" required>
					
					<select name="categorie">
						<option value="1"> Personnages </option>
						<option value="2"> Lieux </option>
						<option value="3"> Ev&eacute;nements </option>
						<option value="4"> Interviews </option>					
					</select>
					
					</br>
					<textarea name="texteInfo" type="text" placeholder="TEXTE / LIEN" id="texteInfo" rows="5" cols="50" required></textarea>
				
					<input type="submit" value="AJOUT" id="bouton">
				</form>
			</div>       
		</div>
	<?php
	}
	public static function afficherAjoutReussie() {
		$nomInfo = $_POST ['nomInfo'];
		echo ("Ajout de $nomInfo r&eacute;ussie. <br>");
	}
	public static function afficherAjoutRatee() {
		echo ("Echec de l'ajout. <br>");
	}
	public static function afficherInfoDejaExistante($nomInfo) {
		echo ("L'information $nomInfo est deja dans la base de donn�es, veuillez en choisir un autre <br>");
	}
	public static function afficherFormulaireVoir($series, $propositions){
		foreach ($propositions as $value) {
			if($value['info_valide']==0){
				?><div class="textenoir"><?php echo $value['nom_information'].'/'.$value['texte_information'].'/saison : '.$value['saison_information'];?></div></br><?php
			}
		}
	}
}
?>
