<?php
class ModuleModerateur extends ModuleGenerique {
	public function __construct() {
		if (isset ( $_SESSION ['estModerateur'] ) && $_SESSION ['estModerateur'] == true) {
			$module = "moderateur";
			if (isset ( $_GET ['action'] ))
				$action = $_GET ['action'];
			else
				$action = 'ajoutInformations';
			require_once ("Modules/mod_$module/controleur_$module/c_moderateur.php");
			$this->controleur = new ControleurModerateur ();
			switch ($action) {
				case 'ajoutInformations' :
					$this->controleur->ajout ();
					break;
				case 'voirPropositions' :
					$this->controleur->voir ();
					break;
			}
		} else
			exit ( 'Vous devez �tre administrateur pour acc�der � cette partie du site.' );
	}
}
?>
