<?php
	//include_once("./connexion.php");
	$host = 'mysql:host=localhost'; /* L'adresse du serveur */
	$login = 'root'; /* Votre nom d'utilisateur */
	$password = ''; /* Votre mot de passe */
	try
	{
		if($bdd = new PDO($host, $login, $password)) {
			echo 'BDD Ok !
				<div  id="moduleConnexion">
					<li>
						<a href="./index.php"> 
							 <button type="button" class="btn btn-danger btn-lg" id="butConnexion" >Index</button>
						</a>
					</li>
				</div>
				';
		}
	}
	catch (Exception $e)
	{
		   die('Erreur : ' . $e->getMessage());
	}
	
	$req = "DROP DATABASE `unspoiledseries`";
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE DATABASE IF NOT EXISTS `unspoiledseries`";
	$bdd->prepare($req)->execute();
	
	$req = "USE unspoiledseries";
	$bdd->prepare($req)->execute();
	
	$req = "CREATE TABLE categorie(
    id_categorie INT NOT NULL AUTO_INCREMENT,
    nom_categorie VARCHAR(64) NOT NULL,
    PRIMARY KEY (id_categorie),
    UNIQUE (nom_categorie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE serie(
    id_serie INT NOT NULL AUTO_INCREMENT,
    nb_saison_serie INT UNSIGNED NOT NULL,
	nom_serie VARCHAR(128) NOT NULL,
    PRIMARY KEY (id_serie),
    UNIQUE (nom_serie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE information(
    id_information INT NOT NULL AUTO_INCREMENT,
    nom_information VARCHAR(128) NOT NULL,
	texte_information VARCHAR(512) NOT NULL,
	id_categorie_information INT NOT NULL,
	id_serie_information INT NOT NULL,
	saison_information INT NOT NULL,
	info_valide BOOLEAN NOT NULL,						
    PRIMARY KEY (id_information)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE user(
    idUser BIGINT(20) NOT NULL AUTO_INCREMENT,
    login VARCHAR(256) NOT NULL,
	password VARCHAR(256) NOT NULL,
	email VARCHAR(32) NOT NULL,
	typeCompte TINYINT(1) NOT NULL,
    PRIMARY KEY (idUser)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";
	$bdd->prepare($req)->execute(); 
	
	/* catégories */
	$req = "INSERT INTO categorie VALUES(1,'personnages')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(2,'lieux')";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(3,'evenements')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(4,'interviews')";	$bdd->prepare($req)->execute();
	
	/* séries */
	$req = "INSERT INTO serie VALUES(1,6,'Game Of Thrones')";			$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(2,6,'The Walking Dead')";			$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(3,5,'Breaking Bad')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(4,5,'Once Upon A Time')";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(5,10,'Stargate SG-1')";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(6,11,'Supernatural')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(7,4,'Orange Is The New Black')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(8,4,'Batman (serie televisee d\'animation, 1992)')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(9,19,'South Park')";				$bdd->prepare($req)->execute();
	
	/* infos personnage */ //résoudre pb dans les noms avec caractères spéciaux
	$req = "INSERT INTO information VALUES(1,'Tyrion Lannister', 'Tyrion est un nain. Il est le dernier fils de la famille Lannister. C\'est quelqu\'un d\'intelligent, mais &eacute;galement 
	friant de prostitu&eacute;',1,1,0,true)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(2,'Tyrion Lannister', 'Lors des noces de son neuveu Joffrey, il du servir une coupe de vin &agrave; celui-ci qui mouru empoisonn&eacute;. Tyrion fut accus&eacute; &agrave; tortura
	de l\'assassinat. Lors de son proc&ecirc;t, il demenda un duel judiciaire. Oberyne Martell se battit donc contre La Montagne et mourru, scellant ainsi le sort de Tyrion. Il tua Shae en l\'&eacute;tranglant puis son 
	p&egrave;re avec une arbal&egrave;te lors de son &eacute;vasion des prisons du donjon rouge.',1,1,4,true)";																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(3,'Tyrion Lannister', 'Avec l\'aide de Varis, il parvient &agrave; quitt&eacute; Westeros. Celui-ci lui propose de conseiller Daenerys pour l\'aider &agrave; gouvern&eacute; 
	les 7 couronnes. Il se fit enlev&eacute; par Jeor Mormont qui esp&eacute;rais le donn&eacute; comme ran&ccedil;on. D&eacute;sormais &agrave; Merren, il sert Daenerys en lui offrant ses conseils.',1,1,5,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(4,'Cersei Lannister', 'Cersei est la soeur de Tyrion et James Lannister. Elle est mari&eacute; au roi Robert Barath&eacute;on.',1,1,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(5,'Cersei Lannister', 'Elle demende &agrave; son fils, le roi, de r&eacute;armer la foi militante pour pi&eacute;ger Loras et Margaery Tyrell. Ce plan se retourne contre elle 
	lorsque le grand moineau la fait prisonni&egrave;re pour sa faute de fornication avec Lancel Lannister. Elle arrive finalement au donjon rouge apr&egrave;s sa marche d\'expiation dans la capitale.',1,1,5,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(6,'Eddard Stark', 'Surnommer Ned Stark, il est le gouverneur du Nord de Westeros et p&egrave;re d\'une grande famille. Il est le fr&ecirc;re de Benjen Stark, mari&eacute; &agrave; Catelyn Stark
	 et p&egrave;re de John Snow, Robb, Sansa, Bran, Arya et Rickon Stark. Il a particip&eacute; &agrave; la rebellion avec Robert Barath&eacute;on contre les Targaryen il y a 15 ans.',1,1,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(7,'John Snow', 'John est le fils batard de Ned Stark, il n\'a pas de droits d\'h&eacute;ritage sur Winterfell de par son droit de naissance.',1,1,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(8,'John Snow', 'Apr&eacute; l\'execution d\'un deserteur de la Garde de Nuit, La famille Stark trouve une louve g&eacute;ante morte et des louvetaux. John propose de les donn&eacute; 
	au fils Stark. Il trouve un dernier louveteau albinos qui devient le sien. Il demende par la suite de devenir membre de la Garde de Nuit &agrave; Ned. Avant de partir, il donne une &eacute;p&eacute;e &agrave; Arya. 
	Il rejoint quelque temps apr&egrave;s la Garde de Nuit et fait ses voeux.',1,1,1,true)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(9,'John Snow', 'Lors d\'une patrouille au nord du Mur, il arrive avec les autres membres de la Garde de Nuit &agrave; la maison de Craster. Il espionne celui-ci transportant un 
	enfant et l\'offrant &agrave; un Marcheur Blanc. Craster le voit et ordonne &agrave; toute la patrouille de partir. Il rejoint le groupe de Qhorin Mimain une fois arriv&eacute; au Point des Premiers Hommes. Pendant 
	le voyage il est s&eacute;par&eacute; du groupe lorsqu\'il &eacute;choue dans l\'execution d\'une sauvageonne : Ygritte. Celle-ci le fait tomb&eacute; dans un pi&egrave;ge et il se retrouve alors prisonnier des 
	sauvageons.',1,1,2,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(10,'John Snow', 'Il arrive finalement au camp du Peuple Libre o&ugrave; il voit un g&eacute;ant. John fait alors la rencontre de Mance Rayder qu\'il parvient &agrave; convaincre 
	qu\'il veut les rejoindre. Il accompagne alors un groupe de sauvageons dirig&eacute; par Tormund en direction du Mur. Les sentiments de John pour Ygritte grandisse et ils finissent par coucher ensemble dans une source 
	d\'eau chaude souterraine. Il escalade le Mur avec le groupe, non sans difficult&eacute;. Lorsque John doit tu&eacute; un &eacute;leveur de chevaux, il refuse et s\'enfui apr&egrave;s avoir tu&eacute; Orell. Ygritte 
	le rattrape et lui tire 3 fl&ecirc;ches pour l\'avoir trahis, mais non mortel car elle &agrave; toujours des sentiments pour lui. John parvient &agrave; Ch&acirc;teaunoir tr&egrave; bless&eacute;',1,1,3,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(11,'Arya Stark', 'Arya est la plus jeune fille des Stark. Contrairement &agrave; sa soeur Sansa, est un gra&ccedil;on manqu&eacute;.',1,1,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(12,'Arya Stark', 'Lors de la d&eacute;couverte des louveteau, elle re&ccedil;ois le sien qu\'elle nomme Nim&eacute;ria. Elle re&ccedil;ois une &eacute;p&eacute;e adapt&eacute; &agrave 
	sa taille de la part de John Snow, avec qui elle s\'entend bien. Lorsqu\'elle va &agrave; Port-R&eacute;al avec son p&egrave;re et sa soeur, Ned lui permet d\'avoir des cours d\'escrime avec Syrio Forel. Elle assiste 
	&agrave; la mort de son p&egrave;re et s\'enfui avec un recruteur de la Garde de Nuit amis de Ned.',1,1,1,true)";																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(13,'Robert Baratheon', 'Robert Barth&eacute;onon est le roi des 7 couronnes de Westeros depuis la rebellion contre le roi fou Targaryen il y a 15 ans. Il est mari&eacute; &agrave; 
	Cersei par alliance, mais aurais d&ugrave; se marier avec la soeur de Ned Stark qui est morte pendant la rebellion',1,1,0,true)";																						$bdd->prepare($req)->execute();	
	$req = "INSERT INTO information VALUES(14,'Eddard Stark', 'Il se fit d&eacute;capit&eacute; pour trahison et conspiration arp&egrave;s avoir apport&eacute; un message du roi Robert r&eacute;cament d&eacute;c&eacute;d&eacute; 
	lui donnant la r&eacute;gence de Westeros jusqu\'&agrave; la majorit&eacute; de l\'h&eacute;riti&eacute;.',1,1,1,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(15,'Melisandre', 'Melisandre est une pr&eacute;tresse de R\'hllor, une religion qui v&eacute;n&egrave;re le feu. Elle est au c&ocirc;t&eacute; de Stannis 
	Barath&eacute;on &agrave; qui elle offre ses pr&eacute;monitions sur les guerres &agrave; venir',1,1,2,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(16,'Vers Gris', 'Vers Gris est le commandant des immacul&eacute;s et l\'un des conseill&eacute;s de Daenerys Targaryen.',1,1,3,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(17,'Sansa Stark', 'Sansa est la plus grande fille de la famille Stark.',1,1,0,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(18,'Sansa Stark', 'Elle se marie &agrave; Ramsey Bolton sous la demande de LittleFinger. Sansa se fait alors viol&eacute; par son nouveau mari.',1,1,4,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(19,'Rick Grimes', 'Rick &eacute;tait sh&eacute;rif et apr&egrave;s avoir re&ccirc;u une balle dans une fusillade, il se r&eacute;veille dans un h&ocirc;pital en ruine.',1,2,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(20,'Michonne', 'Michonne se d&eacute;place avec deux mort-vivants sans bras ni bouche et rencontre Andrea.',1,2,3,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(21,'Glenn', 'Glenn est un ancien livreur de pizza qui aide les gens dans le besoin autant que possible contre les marcheurs.',1,2,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(22,'Glenn', 'Il devient le petit ami de Maggie qu\'il rencontre avec le groupe de Rick apr&egrave;s la blessure de Carl.',1,2,2,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(23,'Daryl Dixon', 'Daryl est le fr&ecirc;re de Merle. C\est une t&ecirc;te br&ucirc;l&eacute; mais un bon chasseur.',1,2,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(24,'Dale Horvath', 'Dale est un homme ag&eacute; plein de sagesse. Il surveille les alentours du campement pr&egrave;s d\'Atlanta du haut de son Camping-car. Il est &eacute;galement 
	assez dou&eacute; en m&eacute;canique.',1,2,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(25,'Hershel Greene', 'Hershel est le p&egrave;re de la famille Grenne. Il est v&eacute;t&eacute;rinaire mais ses capacit&eacute;s en m&eacute;decine permette de sauv&eacute; Carl.',1,2,2,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(26,'Merle Dixon', 'Merle est le fr&ecirc;re de Daryl. Il est violent et raciste se qui lui vaut peut de sympathie des autres membres du groupe de survivant.',1,2,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(27,'Merle Dixon', 'Apr&egrave;s avoir p&eacute;t&eacute; un boulon, il se retrouve menott&eacute; et abandonn&eacute; sur un toit. lorsque Rick et les autres retournes sur le 
	toit pour le lib&eacute;r&eacute;, ils d&eacute;couvre que Merle c\'est coup&eacute; la main pour se lib&eacute;r&eacute;.',1,2,1,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(28,'Gustavo Fring', 'Gustavo Fring est &agrave; la t&ecirc;te de Los Pollos Hermanos, une companie de fast food. Il est &eacute;galement &agrave; la t&ecirc;te d\'un 
	r&eacute;seau de vente de meth',1,3,3,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(29,'Walter White', 'Professeur de chimie dans un lyc&eacute;e, il apprend qu\'il est atteint d\'un cancer.',1,3,0,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(30,'Walter White', 'Il produit de la meth (drogue synth&eacute;tique) en grande quantit&eacute; pour Gustavo Fring avec l\'aide de Jesse.',1,3,3,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(31,'Jesse Pinkman', 'Jesse produit de la drogue ill&eacute;galement avant de rencontrer Walter White.',1,3,0,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(32,'Mike Ehrmantraut', 'Mike est &agrave; la fois d&eacute;tective priv&eacute; et chef de la s&eacute;curit&eacute; de \"Los Pollos Hermanas\".',1,3,3,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(33,'Saul Goodman', 'Avocat avide d\'argent, il fera affaire avec Walter White et Jesse.',1,3,0,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(34,'Hank Schrader', 'Hank est agent des stup. Il est &eacute;galement le beau-fr&egrave;re de Walter White.',1,3,0,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(35,'Skyler White', 'Skyler est femme au foyer. Elle est mari&eacute;e &agrave; Walter White.',1,3,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(36,'Marie Schrader', 'Marie est l'&eacute;pouse de Hank Schrader et la soeur de Skyler White.',1,3,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(37,'Baelfire', 'Il est le fils de Rumplestiltskin.',1,4,1,true)";																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(38,'Emma Swan', 'Emma est la m&eacute;re naturelle de Henry Mills, qu\'elle a fait adopt&eacute; car elle ne pouvait pas s\'en occup&eacute;.',1,4,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(39,'Mary Margaret Blanchard', 'Mary est une institutrice &agrave; Storybrooke. Elle est tr&egrave;s g&eacute;n&eacute;reuse et s\'occupe de donn&eacute; des cours &agrave; Henry',1,4,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(40,'Henry Mills', 'Henry est le fils naturel d\'Emma et adoptif de Regina Mills dont il porte le nom de famille.',1,4,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(41,'Henry Mills', 'Lorsqu\'il re&ccedil;ois le livre de contes \"Once Upon a Tima\" de Mary, il se met en t&ecirc;te que tout les habitans de Storybrooke sont des personnages de 
	contes. Il ne parvient &agrave; leur rendre leur m&eacute;moire qu\'en mangeant une part de g&acirc;teau empoisonn&eacute; &agrave; la place d\'Emma. Le sortil&egrave;ge d\'amn&eacute;sie prend fin lorsque qu\'il est 
	sauv&eacute; par un v&eacute;ritable bais&eacute; d\'amour de sa m&egrave;re biologique.',1,4,1,true)";																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(42,'Regina Mills', 'La M&eacute;chante Reine et maire de Storybrooke.',1,4,0,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(43,'Zelena', 'La M&eacute;chante Sorci&egrave;re de l\'Ouest, elle est la demi-soeur de Regina.',1,4,3,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(44,'Teal\'c', 'Teal\'c est un jaffa qui sert les faux dieux goa\'uld. Il est \'primat\' de l\'un d\'eux : Apophis.',1,5,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(45,'Teal\'c', 'Il se rebelle contre son ma&icirc;tre et rejoint l\'&eacute;quipe SG-1 qui l\'accueille avec joie.',1,5,1,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(46,'Jack O\'Neill', 'Jack est un colonel de l\'US Air Force. Il int&egrave;gre l\'&eacute;quipe SG-1 dont il devient le chef. Il aime bien faire des blagues m&ecirc;me dans 
	les situations critiques',1,5,0,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(47,'Ba\'al', 'Ba\'al est un grand ma&icirc;tre Goa\'uld. Il captura et tortura O'Neill pendant un long moment',1,5,5,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(48,Samantha Carter', 'Samantha est une officier scientifique qui travaille pour le pentagone. Elle est recrut&eacute; pour le projet SG.',1,5,0,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(49,'Jack O\'Neill', 'Il se retrouve temporairement avec toutes les connaissances des anciens apr&egrave;s s\'&ecirc;tre approch&eacute; d\'un appareil inconnu. Il se retrouve 
	donc &agrave; parler en ancien jusqu\'&agrave; rencontr&eacute; les Asgard sur leur monde natal.',1,5,1,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(50,'Adria', 'Quand ils retrouv&egrave;rent la trace des Anciens, r&eacute;fugi&eacute;s dans la Voie Lact&eacute;e, les Oris mirent enceinte Vala Mal Doran avec  leurs pouvoirs,
	afin que son enfant : Adria, aussi appel&eacute; L'Oricy, puisse diriger la guerre contre eux.',1,5,10,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(51,'Daniel Jackson', 'Daniel est &eacute;gyptologue. Il a d&eacute;couvert le fonctionnement de la porte des &eacute;toiles. Il aide SG-1 gr&acirc;ce &agrave; ses connaissances des langues 
	et cultures &eacute;trang&egrave;re.',1,5,0,true)";																																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(52,'Vala Mal Doran', 'Vala est une arnaqueuse qui dupe les gens sur diff&eacute;rentes plan&egrave;tes. Elle rencontre Daniel lorsqu\'elle tente de vol&eacute; le 
	Prom&eacute;th&eacute;.',1,5,8,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(53,'Dean Winchester', 'Dean est le fr&egrave;re de Sam Winchester. Il l\'aide a vaincre des d&eacute;mons depuis la mort de leur m&egrave;re et la disparition de 
	leur p&egrave;re.',1,6,0,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(54,'Sam Winchester', 'Sam est le petit fr&egrave;re de Dean Winchester. C\'est son grand fr&egrave;re qui s\'occupe de lui depuis la mort de leur m&egrave;re et la 
	disparition de leur p&egrave;re.',1,6,0,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(55,'Castiel', 'Castiel est un ange dans le corp d\'un humain ayant accept&eacute; de servire de receptacle sur terre. Il aidera Sam et Dean &agrave; combattre les forces 
	d&eacute;moniaque.',1,6,5,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(56,'Bobby Singer', 'Bobby est un chasseur de cr&eacute;atures surnaturelles et un tr&egrave;s bon ami du p&egrave;re de Sam et Dean.',1,6,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(57,'Alex Vause', 'Alex est une ancienne trafiquante de drogue. Après une p&eacute;riode de d&eacute;pendance &agrave; la drogue, elle s\'arr&ecirc;te pendant son s&eacute;jour en 
	prison.',1,7,0,true)";																																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(58,'Piper Chapman', 'Piper est une femme bisexuelle condamn&eacute;e pour trafic de drogue 10 ans plus t&ocirc;t.',1,7,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(59,'Piper Chapman', 'Elle se retrouve dans la m&ecirc;me chambre que Claudette, avec  qui elle s\'entend mal au d&eacute;but mais elles finissent par &ecirc;tre amis.',1,7,1,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(60,'Sam Healy', 'Sam est un ancien gardien de prison. Il sert d&eacute;sormais de conseiller dans la prison de la s&eacute;rie.',1,7,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(61,'Galina (Red) Reznikov', 'Galina est une co-d&eacute;tenue de Piper. Elle dirige la cuisine et la communaut&eacute; blanche de la prison.',1,7,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(62,'Suzanne (Crazy Eyes) Warren', 'Suzanne prend Piper pour sa m&egrave;re adoptive et la frappe au visage.',1,7,2,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(63,'Batman', 'Batman est le nom donn&eacute; &agrave Bruce Wayne lorsqu\'il porte son costume de chauve-souris. Il combat les criminels de la ville de Gotham',1,8,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(64,'Bruce Wayne', 'Bruce est un homme d\'affaire &agrave; la t&ecirc;te d\'une grande entreprise. La nuit il porte un masque et combat les criminels et est appel&eacute; Batman.',1,8,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(65,'Commissaire James Gordon', 'James Gordon est un polici&eacute; incorruptible contrairement au reste des flics de Gotham. Il est &eacute;galement le p&egrave;re de Barbara',1,8,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(66,'Le Joker', 'Le Joker est un criminel psychopate avec un sourire &eacute;norme. Il adore faire des pi&egrave;ge &agrave; Batman.',1,8,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(67,'Alfred', 'Alfred est le majordome de la famille Wayne. Il s\'occupa de Bruce apr&egrave;s la mort de ses parents. Alfred sais que Bruce est Batman et l\'aide lors de ses 
	enqu&ecirc;tes.',1,8,0,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(68,'Eric Cartman', 'Eric Cartman est un petit gar&ccedil;on grassouillet d\'une m&eacute;chancet&eacute; sans limites.',1,9,0,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(69,'Kyle Broflovski', 'Kyle est l\'un des 4 personnages principaux. Il fait partie d\'une famille juive, se dont Cartman en profite pour utilis&eacute; les 
	st&eacute;r&eacute;otypes contre lui.',1,9,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(70,'Kyle Broflovski', 'Il est le meilleur joueur de basket de South Park et souhaite rejoindre une grande &eacute; mais il n\'est ni grand, ni noir et est donc recal&eacute;. 
	Il subit donc une opp&eacute;ration esth&eacute;tique pour chang&eacute; &ccedil;&agrave;. Il fait une nouvelle op&eacute;ration pour annul&eacute; lorsqu\'il d&eacute;couvre que cela ne lui donne que l\'apparence 
	mais pas le fonctionnement normal d\'un athl&egrave;te.',1,9,9,true)";																																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(71,'Kenny McCormick', 'Kenny est le fils d\'une famille extremenent pauvre. Ces paroles sont imcompr&eacute;hensible (sauf par les autres personnages) &agrave; cause de la capuche de son 
	menteau qu\'il ne retire jamais',1,9,0,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(72,'Butters Stotch', 'Butters est un enfant na&Iuml;f de l\'&eacut;cole. Il reste cependant optimiste la majorit&eacute; du temps',1,9,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(73,'M. Mackey', 'M. Mackey est le conseiller d\'orientation de l\'&eacute; de South Park. Il ponctue souvent ses phrases du terme \"M\'Voyez...\"',1,9,0,true)";					$bdd->prepare($req)->execute();
	
	/* infos lieux */
	$req = "INSERT INTO information VALUES(74,'Winterfell', 'Capitale du nord, elle est dirig&eacute;e par la famille Stark depuis plusieurs milliers d\'ann&eacute;es.',2,1,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(75,'Winterfell', 'Apr&egrave;s la chute de Robb Stark, Winterfell appartient d&eacute;sormais &agrave; la famille Bolton.',2,1,5,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(76,'Dorne', 'Dorne est au Sud de Westeros et est dirig&eacute; par la famille Martell.',2,1,4,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(77,'Atlanta', 'Atlanta est la ville dans laquelle se rend Rick à cheval, il y rencontre Glenn et beaucoup d\'autres.',2,2,4,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(78,'Ferme familiale des Greene', 'Cette exploitation fermi&egrave;re est le refuge du groupe de Rick apr&egrave;s que Carl soit bless&eacute;.',2,2,2,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(79,'Storybrooke', 'Ville dans le Maine. Tous les personnages de contes y ont &eacute;t&eacute; transport&eacute;s.',2,4,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(80,'Le Pays Imaginaire', 'Monde où vivent Peter Pan et les Enfants Perdus.',2,4,3,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(81,'P&eacute;nitentier de Litchfield', 'Prison dans laquelle se d&eacute;roule l\'histoire. Elle est dirig&eacute; par le D&eacute;partement F&eacute;d&eacute;ral de 
	Correction.',2,7,0,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(82,'Stargate Command (SGC)', 'Base militaire sous une montagne. C\'est l&agrave; qu\'est la porte des &eacute;toiles et que les &eacute;quipes SG partent en exploration 
	de mondes aliens.',2,5,0,true)"; 																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(83,'Chateaunoir', 'Ch&acirc;teaunoir est le plus grand fort que poss&egrave;de la Garde de Nuit. Il est coll&eacute; au \"Mur\" qui prot&egrave;ge le royaume des hommes 
	de celui des sauvageons.',2,1,0,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(84,'Maison familiale des White', 'Cette maison est celle de la famille de Walter White. La famille y passe beaucoup de leur temps libre.',2,3,0,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(85,'Maison familiale des White', 'Apr&egrave;s la d&eacute;couverte du trafic de Walter White, et la d&eacute;sertion de la maison par la famille, la maison reste abandonn&eacute;e.
	 Walter White y retourne pour r&eacute;cup&eacute;rer le puissant poison qu\'il y avait cach&eacute;.',2,3,5,true)";																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(86,'Car Wash', 'Station de lavage dans lequel Walter White travaille pour compl&eacute;ter ses revenus en tant que caissier.',2,3,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(87,'Base d\'Anubis', 'Cette base d\'Anubis poss&egrave;de une arme des anciens utilis&eacute;e pour d&eacute;truire la porte des &eacute;toiles sur la Terre.',2,5,4,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(88,'Tartarus', 'Anubis utilisa cette plan&egrave;te pour y construire un laboratoire servant &agrave; la cr&eacute;ation d\'une arm&eacute;e de super soldat.',2,5,8,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(89,'Vivesaigues', 'Maison ancestral de la famille Tully. Robb et Catelyn Stark s\'y rende pour rendre hommage &agrave; la mort d\un parent Tully.',2,1,3,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(90,'Port-Real', 'Port-R&eacute;al est la capital des 7 couronnes de Westeros. C\'est l&agrave; que ce trouve le tr&ocirc;ne de fer. Cette grande ville est domin&eacute 
	par le donjon rouge, qui est le si&egrave;ge de la royaut&eacute;.',2,1,0,true)";																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(91,'Qarth', 'Qarth est une ancienne ville portuaire situ&eacute;e sur la c&ocirc;te sud d\'Essos. Deaneris parvient &agrave; cette ville mais ne semble pas y &ecirc;tre 
	appr&eacute;ci&eacute;. La puissante corporation des Treize g&egrave;re le gouvernement et la protection avec d\'autres ordres. C\'est l&agrave;-bas que se trouve l\'autel des non-mourants.',2,1,2,true)";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(92,'Prison de The Walking Dead', 'Cette prison est d&eacute;couverte par Rick. Apr&egrave;s un nettoyage des r&ocirc;deurs present, le groupe de survivants s\'y installe',2,2,3,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(93,'Terminus', 'Le Terminus est un lieu indiqu&eacute; par de nombreux panneaux comme un lieu de survit. Il s\'av&egrave;re que les gens qui y vivent ne sont pas si acceuillant 
	que les indications le disent.',2,2,4,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(94,'Terminus', 'Le Terminus est en ruine apr&egrave;s l\'attaque de Carol pour sauver ses amis aux mains des cannibales de la prison',2,2,5,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(95,'Los Pollos Hermanos', 'Los Pollos Hermanos est un fast-food dans lequel se rend Walter White pour conclure affaire avec Gustavo Fring : de l\'argent contre une grande 
	quantit&eacute; de meth.',2,3,3,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(96,'L\'asile d\'Arkham', 'L\'asile d\'Arkham est un lieu o&ugrave; sont intern&eacute;s les psycopathe de Gotham',2,8,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(97,'Ecole de South Park', 'L\'eacute;cole &eacute;l&eacute;mentaire de South Park est un lieu imporant dans les aventures des personnages car c\'est l&agrave; que vont en cours 
	les 4 amis Cartman, Kyle, Stan et Kenny.',2,9,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(98,'Cinema de South Park', 'Ce cinema est celui o&eacute; se retrouve les enfants de South Park pour voir les films du moment. En g&eacute;n&eacute;ral, les films 
	pr&eacute;sent&eacute;s sont des parodies de films r&eacute;els',2,9,0,true)";																																			$bdd->prepare($req)->execute();
	
	/* infos evenements */
	$req = "INSERT INTO information VALUES(99,'Les noces pourpres','https://www.youtube.com/watch?v=OuD8tjcggjI',3,1,3,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(100,'La mort de Joffrey','https://www.youtube.com/watch?v=V5K7motTFf8',3,1,4,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(101,'Duel judiciaire Oberyn contre La Montagne','https://www.youtube.com/watch?v=Pr9Do6blB4c',3,1,4,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(102,'La mort de John Snow','https://www.youtube.com/watch?v=HVkHpeW8zJo',3,1,5,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(103,'La mort de Ned Stark','https://www.youtube.com/watch?v=PW6wfXPeJTw',3,1,1,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(104,'La mort de Shane','https://www.youtube.com/watch?v=9L510ov05NI',3,2,2,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(105,'La mort de Gustavo Fring','https://www.youtube.com/watch?v=R6CjCEyAJ2s',3,3,4,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(106,'Say my name (Dit mon nom)','https://www.youtube.com/watch?v=C9MGU7krXnQ',3,3,5,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(107,'La mort de Neal','https://www.youtube.com/watch?v=lMXXCDe7n1U',3,4,3,true)";																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(108,'Le mariage de Belle et Rumplestiltskin','https://www.youtube.com/watch?v=UPV90t8afB0',3,4,3,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(109,'La r&eacute;surrection de Mal&eacute;fique','https://www.youtube.com/watch?v=EW9vdjYJBcc',3,4,4,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(110,'Bataille de la super porte','https://www.youtube.com/watch?v=FRIvaO3i5EM',3,5,9,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(111,'D&eacute;collage du Prom&eacute;th&eacute;e','https://www.youtube.com/watch?v=-Xdlr30G6PM',3,5,6,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(112,'Castiel regarde un film','http://www.dailymotion.com/video/xmolzy_supernatural-scene-en-francais-avec-castiel_tv',3,6,4,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(113,'PUDDING !','https://www.youtube.com/watch?v=gzi7To5ZkSA',3,6,5,true)";																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(114,'Le plus gros caca du monde', 'https://www.youtube.com/watch?v=8WmOFZIMDm0',3,9,11,true)";																					$bdd->prepare($req)->execute();
	
	/* infos interviews */
	$req = "INSERT INTO information VALUES(115,'Interview des acteurs et r&eacute;alisateurs avant la saison 2','https://www.youtube.com/watch?v=--jx-ZKmHkE',4,1,2,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(116,'Interview des acteurs avant le lancement de la saison 6','https://www.youtube.com/watch?v=hX-btYt5caY',4,1,6,true)";															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(117,'Supernatural Comic Con 2015','https://www.youtube.com/watch?v=nvMTCXOWEkU',4,6,10,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(118,'Interview de Laura Prepon et Laverne Cox','https://www.youtube.com/watch?v=ZZupBPrGefw',4,7,3,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(119,'Reportage sur les voix françaises de South Park', 'https://www.youtube.com/watch?v=y7g1Kp2RY_0',4,9,10,true)";																$bdd->prepare($req)->execute();
	
	/* comptes */
	$req = "INSERT INTO user VALUES(1,'user','user','user@users.fr',0)";																																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO user VALUES(2,'modo','modo','modo@modos.fr',1)";																																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO user VALUES(3,'admin','admin','admin@admins.fr',2)";																																				$bdd->prepare($req)->execute();

																																														
	

	
		
	
	
	
?>