<?php
class VueDonnees {

	static function afficherDonnees($stats) {	
		
		foreach ($stats as $value) {
			$categorie = $value['id_categorie_information'];
		}
		switch ($_GET['action']) {
			case 1:  $categorie = "personnages"; $taille = "230px"; break;
			case 2:  $categorie = "lieux"; $taille = "100px"; break;		
		}
		$nom = $_GET['nom'];
		?>
		<h1 id="labelAccueil"> <?php echo $nom;?></h1>
		<div class="container">
			<div class="form-group2">
				<input type="button" value="retour &agrave; la liste d'informations" onClick="document.location.href = document.referrer" />
			</div>
			</br>
				<div>
				<img src="./images/<?php echo $categorie;?>/<?php echo $value['nom_information'];?>.jpg"  alt="Image de <?php echo $value['nom_information'];?>" width=160px height=<?php echo $taille;?>>
				</div>
			<?php
			foreach ($stats as $value) {
				if ($value['info_valide'] == 1) {
					$saison = $value['saison_information'];
			?>	
				<div class="col-md-4" style="text-align:justify">
			<?php
					echo '<strong><br/>saison : '.$saison .'</strong></br>'. $value['texte_information'].'<br/>';
			?>
				</div>
		</div>
			<?php
			}
		}
	}
}
?>
