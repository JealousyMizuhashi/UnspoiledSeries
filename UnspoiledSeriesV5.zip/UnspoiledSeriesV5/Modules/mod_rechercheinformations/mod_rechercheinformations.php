<?php
class Modulerechercheinformations extends ModuleGenerique {
	public function __construct() {
		$idCategorie = $_GET['idCategorie'];
		$idSerie = $_GET['idSerie'];
		$idSaison = $_GET['idSaison'];
		if(isset($_POST['requete'])){
		$module = "rechercheinformations";
		require_once ("Modules/mod_$module/controleur_$module/controleur_$module.php");
		$this->controleur = new ControleurRechercheInformations ();
		$this->controleur->afficherResultatsRechercheInformations ( $_POST ['requete']);
		}
		else{
			
				header('Location: http://localhost/UnspoiledSeriesV5/index.php?module=informations&action='.$idCategorie.'&idSerie='.$idSerie.'&idSaison='.$idSaison.'');
				exit();
			
		}
	}
}

?>


