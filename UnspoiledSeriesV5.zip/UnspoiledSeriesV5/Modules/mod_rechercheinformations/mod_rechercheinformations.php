<?php
class Modulerechercheinformations extends ModuleGenerique {
	public function __construct() {
		$module = "rechercheinformations";
		require_once ("Modules/mod_$module/controleur_$module/controleur_$module.php");
		$this->controleur = new ControleurRechercheInformations ();
		$this->controleur->afficherResultatsRechercheInformations ( $_POST ['requete']);
	}
}

?>


