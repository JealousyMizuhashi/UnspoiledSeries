<?php

	//include_once("./connexion.php");
	$host = 'mysql:host=localhost'; /* L'adresse du serveur */
	$login = 'root'; /* Votre nom d'utilisateur */
	$password = ''; /* Votre mot de passe */
	try
	{
		if($bdd = new PDO($host, $login, $password)) {
			echo 'BDD Ok !
				<div  id="moduleConnexion">
					<li>
						<a href="./index.php"> 
							 <button type="button" class="btn btn-danger btn-lg" id="butConnexion" >Index</button>
						</a>
					</li>
				</div>
				';
		}
	}
	catch (Exception $e)
	{
		   die('Erreur : ' . $e->getMessage());
	}
	
	$req = "DROP DATABASE `unspoiledseries`";
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE DATABASE IF NOT EXISTS `unspoiledseries`";
	$bdd->prepare($req)->execute();
	
	$req = "USE unspoiledseries";
	$bdd->prepare($req)->execute();
	
	$req = "CREATE TABLE categorie(
    id_categorie INT NOT NULL AUTO_INCREMENT,
    nom_categorie VARCHAR(64) NOT NULL,
    PRIMARY KEY (id_categorie),
    UNIQUE (nom_categorie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE serie(
    id_serie INT NOT NULL AUTO_INCREMENT,
    nb_saison_serie INT UNSIGNED NOT NULL,
	nom_serie VARCHAR(128) NOT NULL,
    PRIMARY KEY (id_serie),
    UNIQUE (nom_serie)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE information(
    id_information INT NOT NULL AUTO_INCREMENT,
    nom_information VARCHAR(128) NOT NULL,
	texte_information VARCHAR(1024) NOT NULL,
	id_categorie_information INT NOT NULL,
	id_serie_information INT NOT NULL,
	saison_information INT NOT NULL,
	info_valide BOOLEAN NOT NULL,						
    PRIMARY KEY (id_information)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";	
	$bdd->prepare($req)->execute(); 
	
	$req = "CREATE TABLE user(
    idUser BIGINT(20) NOT NULL AUTO_INCREMENT,
    login VARCHAR(256) NOT NULL,
	password VARCHAR(256) NOT NULL,
	email VARCHAR(32) NOT NULL,
	typeCompte TINYINT(1) NOT NULL,
	serieCompte INT,
    PRIMARY KEY (idUser)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8";
	$bdd->prepare($req)->execute(); 
	
	/* catégories */
	$req = "INSERT INTO categorie VALUES(1,'personnages')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(2,'lieux')";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(3,'evenements')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO categorie VALUES(4,'interviews')";	$bdd->prepare($req)->execute();
	
	/* séries */
	$req = "INSERT INTO serie VALUES(1,6,'Game Of Thrones')";			$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(2,6,'The Walking Dead')";			$bdd->prepare($req)->execute();	
	$req = "INSERT INTO serie VALUES(3,5,'Breaking Bad')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(4,5,'Once Upon A Time')";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(5,10,'Stargate SG-1')";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(6,11,'Supernatural')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(7,4,'Orange Is The New Black')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(8,4,'Batman (serie televisee d\'animation, 1992)')";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(9,19,'South Park')";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO serie VALUES(10,9,'The Big Bang Theorie')";		$bdd->prepare($req)->execute();
	
	$robertbaratheon="Robert Barathéon";
	$robertbaratheon=utf8_decode($robertbaratheon);
	$penitentierdelitchfield="Pénitentier de Litchfield";
	$penitentierdelitchfield=utf8_decode($penitentierdelitchfield);
	$chateaunoir="Châteaunoir";
	$chateaunoir=utf8_decode($chateaunoir);
	$portreal="Port-Réal";
	$portreal=utf8_decode($portreal);
	$cinemadesouthpark="Cinéma de South Park";
	$cinemadesouthpark=utf8_decode($cinemadesouthpark);
	$laresurrectiondemalefique="La résurrection de Maléfique";
	$laresurrectiondemalefique=utf8_decode($laresurrectiondemalefique);
	$decollagedupromethee="Décollage du Prométhée";
	$decollagedupromethee=utf8_decode($decollagedupromethee);
	$interviewdesacteursetrealisateursavantlasaison2="Interview des acteurs et réalisateur avant la saison 2";
	$interviewdesacteursetrealisateursavantlasaison2=utf8_decode($interviewdesacteursetrealisateursavantlasaison2);
	$laforetenchantee="La forêt enchantée";
	$laforetenchantee=utf8_decode($laforetenchantee);
	$leseyrie="Les Eyrié";
	$leseyrie=utf8_decode($leseyrie);
	$lesilesdefer="Les Îles de fer";
	$lesilesdefer=utf8_decode($lesilesdefer);
	$decapitationdunchevalparlamontagne="La décapitation d\'un cheval par La Montagne";
	$decapitationdunchevalparlamontagne=utf8_decode($decapitationdunchevalparlamontagne);
	$debutdelepisode1="Breaking Bad - Saison 1 - Début de l\'épisode 1";
	$debutdelepisode1=utf8_decode($debutdelepisode1);
	$sheldondrogue="The Big Bang theory - Sheldon drogué";
	$sheldondrogue=utf8_decode($sheldondrogue);
	
	
	
	/* infos personnage */ //résoudre pb dans les noms avec caractères spéciaux
	$req = "INSERT INTO information VALUES(1,'Tyrion Lannister', 'Tyrion est un nain. Il est le dernier fils de la famille Lannister. C\'est quelqu\'un d\'intelligent, mais &eacute;galement 
	friant de prostitu&eacute;.',1,1,0,true)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(2,'Tyrion Lannister', 'Lors des noces de son neuveu Joffrey, il du servir une coupe de vin &agrave; celui-ci qui mouru empoisonn&eacute;. Tyrion fut accus&eacute; &agrave; tortura
	de l\'assassinat. Lors de son proc&ecirc;t, il demenda un duel judiciaire. Oberyne Martell se battit donc contre La Montagne et mourru, scellant ainsi le sort de Tyrion. Il tua Shae en l\'&eacute;tranglant puis son 
	p&egrave;re avec une arbal&egrave;te lors de son &eacute;vasion des prisons du donjon rouge.',1,1,4,true)";																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(3,'Tyrion Lannister', 'Avec l\'aide de Varis, il parvient &agrave; quitt&eacute; Westeros. Celui-ci lui propose de conseiller Daenerys pour l\'aider &agrave; gouvern&eacute; 
	les 7 couronnes. Il se fit enlev&eacute; par Jeor Mormont qui esp&eacute;rais le donn&eacute; comme ran&ccedil;on. D&eacute;sormais &agrave; Merren, il sert Daenerys en lui offrant ses conseils.',1,1,5,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(4,'Tyrion Lannister', 'Tyrion est avec le reste du convoi royal &agrave; Winterfell. Il rejoint le Mur avec John Snow pour pouvoir piss&eacute; d\'en haut. Lors de son retour il 
	est captur&eacute; par Catelyn Stark et ses hommes et emmen&eacute; aux Eyri&eacute;. Ne pouvant prouver son innocense dans la chute de Brann et sa tentative d\'assasina, il demande un duel judiciaire et Bronn lui sert 
	de champion. Bronn gagne le combat et Tyrion est donc lib&eacute;r&eacute;.',1,1,1,true)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(5,'Tyrion Lannister', 'Il rencontre Shae pendant la campagne des Lannister contre les Stark. Pendant une bataille il se fait assom&eacute; de par sa petite taille et ne participe 
	pas au combat. De retour &agrave; Port-R&eacute;al, il devient main du roi &agrave; la place de son p&egrave;re qui est occup&eacute; par la guerre. Tyrion fait de son mieux pour aid&eacute; malgr&eacute; la tyranie 
	de Joeffrey qui le desteste grandement. Ne sachant &agrave; qui se fi&eacute; dans le conseil restreint puisque les main du roi pr&eacute;c&eacute;dente son morte, il met en place un stratag&egrave;me pour savoir qui 
	de Varys, Littlefinger, ou Pycelle racontra une information secr&egrave;te &agrave; Cersei. Le grand mestre Pycelle est alors remarqu&eacute; et Tyrion lui fait coup&eacute; la barbe avant de le jet&eacute; aux cachots. 
	Pycelle sera rapidement lib&eacute;r&eacute; sous la demande de Cersei. Pendant la bataille de la N&eacute;ra, Tyrion supervise la contre offensive et fait un discour pour remont&eacute; le moral des soldats. Il est 
	gri&egrave;vement bl&eacute;ss&eacute; 	par un garde royal sous les ordres de Cersei mais survit gr&acirc;ce &agrave; l\'intervention de Podrick.',1,1,2,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(6,'Cersei Lannister', 'Cersei est la soeur de Tyrion et James Lannister. Elle est mari&eacute; au roi Robert Barath&eacute;on.',1,1,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(7,'Cersei Lannister', 'Elle arrive &agrave; Winterfell avec le Robert, venu pour demend&eacute; &agrave; Ned Stark de devenir main du roi. Elle fut surprit par Bran en train de 
	couch&eacute; avec son propre fr&ecirc; Jaime Lannister. Jaime fit alors tomb&eacute; Bran de la tour pour qu\'il ne d&eacute;voile pas leur amour secret et incestueu. Ce secret avait &eacute;t&eacute; d&eacute;couverte 
	par John Arryn, puis par Ned Stark lorsqu\'il devint main du roi. Lorsque Robert mourru, Ned apporta une lettre &agrave; Cersei donnant la r&eacute;gence &agrave; Ned jusqu\'&agrave; la maturit&eacute; de Joeffrey. 
	Cersei prit &ccedil;&agrave; comme un outrage et d&eacute;chira la feuille et fit emprisonn&eacute; Ned Stark. Celui-ci fut d&eacute;capit&eacute; sous l\'ordre de Joeffrey malgr&eacute; la demande de Cersei de le 
	gard&eacute; prisonni&eacute;.',1,1,1,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(8,'Cersei Lannister', 'Elle demende &agrave; son fils, le roi, de r&eacute;armer la foi militante pour pi&eacute;ger Loras et Margaery Tyrell. Ce plan se retourne contre elle 
	lorsque le grand moineau la fait prisonni&egrave;re pour sa faute de fornication avec Lancel Lannister. Elle arrive finalement au donjon rouge apr&egrave;s sa marche d\'expiation dans la capitale.',1,1,5,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(9,'Eddard Stark', 'Surnommer Ned Stark, il est le gouverneur du Nord de Westeros et p&egrave;re d\'une grande famille. Il est le fr&ecirc;re de Benjen Stark, mari&eacute; &agrave; Catelyn Stark
	 et p&egrave;re de John Snow, Robb, Sansa, Bran, Arya et Rickon Stark. Il a particip&eacute; &agrave; la rebellion avec Robert Barath&eacute;on contre les Targaryen il y a 15 ans.',1,1,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(10,'John Snow', 'John est le fils batard de Ned Stark, il n\'a pas de droits d\'h&eacute;ritage sur Winterfell de par son droit de naissance.',1,1,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(11,'John Snow', 'Apr&eacute; l\'execution d\'un deserteur de la Garde de Nuit, La famille Stark trouve une louve g&eacute;ante morte et des louvetaux. John propose de les donn&eacute; 
	au fils Stark. Il trouve un dernier louveteau albinos qui devient le sien. Il demende par la suite de devenir membre de la Garde de Nuit &agrave; Ned. Avant de partir, il donne une &eacute;p&eacute;e &agrave; Arya. 
	Il rejoint quelque temps apr&egrave;s la Garde de Nuit et fait ses voeux.',1,1,1,true)";																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(12,'John Snow', 'Lors d\'une patrouille au nord du Mur, il arrive avec les autres membres de la Garde de Nuit &agrave; la maison de Craster. Il espionne celui-ci transportant un 
	enfant et l\'offrant &agrave; un Marcheur Blanc. Craster le voit et ordonne &agrave; toute la patrouille de partir. Il rejoint le groupe de Qhorin Mimain une fois arriv&eacute; au Point des Premiers Hommes. Pendant 
	le voyage il est s&eacute;par&eacute; du groupe lorsqu\'il &eacute;choue dans l\'execution d\'une sauvageonne : Ygritte. Celle-ci le fait tomb&eacute; dans un pi&egrave;ge et il se retrouve alors prisonnier des 
	sauvageons.',1,1,2,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(13,'John Snow', 'Il arrive finalement au camp du Peuple Libre o&ugrave; il voit un g&eacute;ant. John fait alors la rencontre de Mance Rayder qu\'il parvient &agrave; convaincre 
	qu\'il veut les rejoindre. Il accompagne alors un groupe de sauvageons dirig&eacute; par Tormund en direction du Mur. Les sentiments de John pour Ygritte grandisse et ils finissent par coucher ensemble dans une source 
	d\'eau chaude souterraine. Il escalade le Mur avec le groupe, non sans difficult&eacute;. Lorsque John doit tu&eacute; un &eacute;leveur de chevaux, il refuse et s\'enfui apr&egrave;s avoir tu&eacute; Orell. Ygritte 
	le rattrape et lui tire 3 fl&ecirc;ches pour l\'avoir trahis, mais non mortel car elle &agrave; toujours des sentiments pour lui. John parvient &agrave; Ch&acirc;teaunoir tr&egrave;s bless&eacute;',1,1,3,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(14,'Arya Stark', 'Arya est la plus jeune fille des Stark. Contrairement &agrave; sa soeur Sansa, est un gra&ccedil;on manqu&eacute;.',1,1,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(15,'Arya Stark', 'Lors de la d&eacute;couverte des louveteau, elle re&ccedil;ois le sien qu\'elle nomme Nim&eacute;ria. Elle re&ccedil;ois une &eacute;p&eacute;e adapt&eacute; &agrave 
	sa taille de la part de John Snow, avec qui elle s\'entend bien. Lorsqu\'elle va &agrave; Port-R&eacute;al avec son p&egrave;re et sa soeur, Ned lui permet d\'avoir des cours d\'escrime avec Syrio Forel. Elle assiste 
	&agrave; la mort de son p&egrave;re et s\'enfui avec un recruteur de la Garde de Nuit amis de Ned.',1,1,1,true)";																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(16,'Arya Stark', 'Yoren, le recruteur de la Garde de Nuit qui l\'aide &agrave; partir de Port-R&eacute;al lui coupe les cheveux pour qu\'elle passe pour un simple gar&ccedil;on 
	et ne se fasse pas arr&ecirc;ter par les garde de Cersei. Dans le groupe de Yoren il y a les futurs recrus pour la Garde de nuit et des prisonniers dont un homme qui se nomme Jaqen H'Ghar. Lorsque le groupe de recru 
	de la Garde de Nuit se fait attaquer par des gardes &agrave; la recherche du b&acirc;tard de Robert, Arya est fait capturer et emmener &agrave; Harrenhal. Elle parvient &agrave; s\'enfuir avec Gendry le b&acirc;tard 
	de Robert et Tourte-Chaude, un enfant grassouillet gr&acirc;ce &agrave; Jaqen qui semble pouvoir tu&eacute; n\'importe qui pour remerci&eacute; Arya de l\'avoir lib&eacute;r&eacute;. Ce derni&eacute; la retrouve un 
	peu plus loin et lui donne une pi&egrave;ce lui permettant de le rejoindre &agrave; Braavos avec la phrase \"Valar Morghulis\"',1,1,2,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(17,'Arya Stark', 'Accompagn&eacute; de Gendry et Tourte-Chaude, Arya se fait de nouveau captur&eacute; par des hommes, de la \"fraternit&eacute; sans banni&egrave;\" cette fois. 
	Lorsque Sandor Clegan est &eacute;galement ammen&eacute; dans le rep&egrave;re de la fraternit&eacute;, Arya veut qu\'il soit tu&eacute; pour avoir tu&eacute; un ami &grave; Winterfell. Le duel judiciaire entre donne 
	raison &agrave; Sandor qui peut alors partir, se qui d&eacute;sole Arya. Plus tard, lorsqu\'elle s\'enfuit du rep&egrave; de la fraternit&eacute;, elle se fait captur&eacute; par Clegane qui veut la revendre &agrave; 
	sa tante au Eyri&eacute;. Arriv&eacute; au Jummeaux, Arya voit avec stup&eacute;faction le massacre de l\'arm&eacute;e et le loup de Robb Stark. Le cadravre de son fr&egrave;re &eacute;tant montr&eacute; comme un 
	troph&eacute; par les gardes des Frey.',1,1,3,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(18,'Arya Stark', 'Arya r&eacute;cup&egrave;re son &eacute;p&eacute;e sur un homme des Lannister que le Limier tue dans une auberge. Lorsqu\'ils arrivent finalement aux Eyri&eacute;, 
	ils apprennent la mort de la tante d\'Arya. Le plan de ran&ccedil;on tombant &agrave; l\'eau, ils vagabondent dans le Conflant lorsqu\'ils tombent sur Brienne de Torth. Un combat s\en suit entre Brienne et le Limier pour 
	la garde d\'Aria. Le Limier gravement blesser, Arya le laisse agonis&eacute; et part pour Braavos &agrave; bord d\'un b&acirc;teau.',1,1,4,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(19,'Arya Stark', 'Elle arrive finalement &agrave; Braavos. Devant le temple du Dieu Multiface, elle s\'attend &agrave; rencontr&eacute; Jaqen mais ne voit qu\'un homme noir. 
	apr&egrave;s un long moment l\'homme noir revient vers elle et change alors de visage pour qu\'Arya puisse le reconna&icirc;tre comme Jaqen. Elle entre enfin dans le temple o&ugrave; elle sert &agrave; nettoyer le sol, 
	puis les corps des morts. Jaqen lui apprend montre la salle des visages et lui demande de d\'espionn&eacute; puis tu&eacute; avec du poison un homme. Arya voit l\'arriv&eacute; de Meryn Trant, un capitaine de la garde 
	royal ayant particip&eacute; &agrave; la d&eacute;capitation de son p&egrave;re. Elle d&eacute;cide donc d\'utiliser un des visages pour pouvoir l\'assasiner. Malheuresement, ce nom n\'&eacute;tait pas \"demend&eacute;\" 
	par le Dieu Multiface, et devient alors aveugle.',1,1,5,true)";																																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(20, '$robertbaratheon', 'Robert Barth&eacute;non est le roi des 7 couronnes de Westeros depuis la rebellion contre le roi fou Targaryen il y a 15 ans. Il est mari&eacute; &agrave; 
	Cersei par alliance, mais aurais d&ugrave; se marier avec la soeur de Ned Stark qui est morte pendant la rebellion',1,1,0,true)";																						$bdd->prepare($req)->execute();	
	$req = "INSERT INTO information VALUES(21,'Eddard Stark', 'Il se fit d&eacute;capit&eacute; pour trahison et conspiration arp&egrave;s avoir apport&eacute; un message du roi Robert r&eacute;cament d&eacute;c&eacute;d&eacute; 
	lui donnant la r&eacute;gence de Westeros jusqu\'&agrave; la majorit&eacute; de l\'h&eacute;riti&eacute;.',1,1,1,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(22,'Melisandre', 'Melisandre est une pr&eacute;tresse de R\'hllor, une religion qui v&eacute;n&egrave;re le feu. Elle est au c&ocirc;t&eacute; de Stannis 
	Barath&eacute;on &agrave; qui elle offre ses pr&eacute;monitions sur les guerres &agrave; venir',1,1,2,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(23,'Vers Gris', 'Vers Gris est le commandant des immacul&eacute;s et l\'un des conseill&eacute;s de Daenerys Targaryen.',1,1,3,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(24,'Lord Varys', 'Lord Varys est le ma&icirc;tre espion du conseil restreint. C\'est un eunuque tr&egrave;s intelligent. Il est aussi surnomm&eacute; l\'araign&eacute;e.',1,1,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(25,'Lord Varys', 'Lorsque Ned Stark deviendra main du roi, il lui demendera de faire attention et de ne faire confiance &grave; personne car son enqu&ecirc;te sur la mort 
	de John Arryn pourrai le mettre en dang&eacute;.Arya le verra discut&eacute; avec Illiryo discutant du retour des Targaryen. Apr&egrave;s l\'arrestation de Ned, Varys ira le voir en lui demandant de jur&eacute; 
	loyaut&eacute; &agrave; Jeoffrey pour rest&eacute; en vie. M&ecirc;me si Ned suivit finalement se conseil, il finit tout de m&ecirc;me d&eacute;capit&eacute;.',1,1,0,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(26,'Daenerys Targaryen', 'Daenerys est la fille du Roi fou Aerys II Targaryen, vaicu il y a 15 ans par la rebellion de Robert Barath&eacute;on. Elle est son fr&ecirc; ont d&ugrave; 
	se cacher pendant des ann&eacute;es et sont finalement acceuilli depuis 1 an par Illirio, &agrave; Pentos.',1,1,0,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(27,'Daenerys Targaryen', 'Elle est mari&eacute; contre son gr&eacute; au chef Dothraki : Khal Drogo. Lors des noces, elle re&ccedils des oeufs de Dragon de la par d\'Illirio. 
	Elle &eacute;chappe &agrave; des tentatives d\'assassina de Robert Barath&eacute;on qui souhaite toujours la mort des Targaryen. Elle fini par aim&eacute; Drogo qui fit fondre de l\'or sur la t&ecirc;te de son Viserys, 
	son fr&ecirc;re, de plus en plus violent et incontr&ocirc;lable. Malhereusement Drogo mourru peu apr&ecircs; malgr&ecirc; le sortil&egrave;ge d\'une sorci&egrave;re sacrifiant le foetus de Daenerys pour le soign&eacute;. 
	Daenerys fait br&ucirc;ler la sorci&egrave;re sur le b&ucirc;ch&eacute; fun&eacute;raire de Khal Drogo et va dans les flammes avec les oeufs de dragon. Elle en ressort indemne avec 3 petit dragons.',1,1,1,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(28,'Daenerys Targaryen', 'Quelque Dothrakis et Jorah Mormont suivent Daenerys dans le d&eacute;sert depuis la mort de Drogo. Ils atteignent finalement Quarth. L\'entr&eacute;e leur 
	est interdite mais Xaro Xhoan Daxos se porte garant pour eux et leur permet d\'entr&eacute;. Pyat Pree, le Maître des Conjurateurs, et Xaro Xhoan Daxos volent alors les jeunes dragons de Daenerys, tue les autres membres 
	des Treize et invite Daenerys &agrave; all&eacute; &agrave; l\'H&ocirc;tel des Nonmourants pour y retrouv&eacute; ses dragons. Elle rentre dans la tour qui semble magique, puisqu\'elle n\'a pas d\'entr&eacute; physique 
	et qu\'une fois dedans certaines portes mennent &agrave; des illusions de lieux de Westeros o&ugrave; &agrave; une tente avec Khal Drogo. Daenerys trouve finalement la salle avec ses dragons. Elle est alors encha&icirc;n&eacute; 
	par Pyat Pree, dont les pouvoirs de d&eacute;doublement ne se manifeste que gr&acirc;ce &agrave; la pr&eacute;sence de Daenerys et ses dragons. Mais elle ne se laisse pas faire et ordonne &agrave; ses dragons de cracher 
	du feu en Valyrien, tuant ainsi Pyat Pree et lib&eacute;rant Daenerys et ses dragons. Elle va ensuite cherch&eacute; Xaro Xhoan Daxos qu\'elle fait enferm&eacute; dans le coffre fort de celui-ci, qui est vide. Daenerys 
	et les autres r&eacute;cup&egrave;re des objets dans la demeure de Xaro Xhoan Daxos pour s\'achet&eacute; un bateau.',1,1,2,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(29,'Oberyn Martell', 'Oberyn est un Prince de Dornevet cadet de Doran Martell, il est surnommé \"la Vipère Rouge\".Cet un homme bisexuel et libertin. Il arrive &grave; 
	Port-R&eacute;al pour les noces de Joeffrey. Il cherche surtout &agrave; prouv&eacute; que Tywin Lannister &agrave; donn&eacute; l\'ordre &grave; La Montagne de tu&eacute; la soeur d\'Oberyn et ses enfants. Il est l\un 
	des 3 juges lors le proc&egrave;s de Tyrion pour le meurtre de Joeffrey. Lorsque Tyrion demande un duel judiciare, seul Oberyne se propose d\'&ecirc;tre son champion pour combattre La Montagne, et ainsi avoir sa vengance. 
	Le duel est impressionnant et Oberyn r&eacute;ussi &agrave; vaincre La Montagne, mais avant de l\'achev&eacute; il veut qu\'il dise qui lui &agrave; donn&eacute; l\'ordre de tu&eacute; sa soeur et ses enfants. Dans ses 
	derni&egrave;re forces, La Montagne attrape Oberyn et lui explose le cr&acirc;ne &agrave; avec ses mains sous le regard horrifi&eacute; de la concubine d\'Oberyn, Ellaria Sand.',1,1,4,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(30,'Ellaria Sand', 'Ellaria est la concubine d\'Oberyn. Tout comme lui elle est bisexuel et libertine. Elle est avec lui &agrave; Port-R&eacute;al et assiste impuissante &agrave; 
	la mort sanglante d\'Oberyn par Gregor Clegane.',1,1,4,true)";																																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(31,'Ellaria Sand', 'De retour &agrave; Dorne, elle souhaite une vengance contre les Lannister et envoi une lettre de menace &agrave; Cersei avec le collier de Myrcella, actuellement 
	&agrave; Dorne pour &eacute;pous&eacute; Trystane Martell. Avec l\'aide des b&acirc;tardes d\'Oberyn : Tyene, Nymeria, Obara Sand (les deux premi&egrave;res sont &eacute;galement les filles d\'Ellaria), elle tente de 
	faire assassin&eacute; Jaime et Bronn arriv&eacute; &agrave; Dorne pour r&eacute;cup&eacute;r&eacute; Myrcella. Elles &eacute;chouent, mais Doran Martell leur offre une seconde chance. Elle empoisonne Myrcella d\'un 
	bais&eacute; empoisonn&eacute; juste avant son d&eacute;part pour Port-R&eacute;al.',1,1,5,true)";																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(32,'Ellaria Sand', 'Lorsque le message de la mort de Myrcella parvient &agrave; Doran Martell, Ellaria et les b&acirc;tardes d\'Oberyn tu&egrave;rent Doran et le capitaine de la 
	garde Areo Hotah. Apr&egrave;s la destruction du Septuaire &agrave; Port-R&eacute;al, Ellaria discute d\'une alliance avec Olenna Tyrell pour se veng&eacute; des Lannister.',1,1,6,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(33,'Catelyn Stark', 'Catelyn vient de la famille Tully et est mari&eacute; avec Eddard Stark. Elle est la m&egrave; de Robb, Sansa, Arya, Bran et Rickon. Elle n\'aime pas beacoup 
	John Snow, le b&acirc;tard de Ned.',1,1,0,true)";																																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(34,'Catelyn Stark', 'Apr&egrave;s avoir d&eacute;couvert que les Lannister ont provoqu&eacute;s la tentative de meurtre de son fils Bran, elle va jusqu'&agrave; Port-R&eacue;al 
	pr&eacute;venir Ned, et &agrave; son retour, capture Tyrion Lannister dans une auberge. Elle l\'am&egrave; au Ery&eacute; pour qu\'il y soit jug&eacute;. Mais Tyrion demende un duel judiciaire que Bronn gagne pour 
	lui.',1,1,1,true)";																																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(35,'Sansa Stark', 'Sansa est la plus grande fille de la famille Stark.',1,1,0,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(36,'Sansa Stark', 'Elle se marie &agrave; Ramsey Bolton sous la demande de LittleFinger. Sansa se fait alors viol&eacute; par son nouveau mari.',1,1,4,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(37,'Rick Grimes', 'Rick &eacute;tait sh&eacute;rif et apr&egrave;s avoir re&ccirc;u une balle dans une fusillade, il se r&eacute;veille dans un h&ocirc;pital en ruine.',1,2,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(38,'Rick Grimes', 'Apr&egrave;s son r&eacute;veil, il cherche &agrave; retrouv&eacute; sa femme. Il fait la rencontre d\'un p&egrave;re : Morgan, et de son fils Duane. Il les 
	aide &agrave; r&eacute;cup&eacute;rer des armes dans les ses anciens locaux de sh&eacute;rif. Rick par ensuite, seul, vers Atlanta pour y cherch&eacute; sa femme suivant les indications de Morgan. C\'est l&agrave;-bas 
	qu\'il rencontre Glenn et les autres qui &eacute;tait all&eacute; chercher des vivres et du mat&eacute;riel en ville. Il les aide &agrave; &grave; fuir les morts qui sont &agrave; Atlanta en se couvrant de chair en 
	d&eacute;composition pour r&eacute;cup&eacute;rer un v&eacute;hicule. Il parvient finalement &agrave; rejoindre le campement de survivant o&ugrave; il retrouve finalement sa femme et son fils.',1,2,1,true)";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(39,'Rick Grimes', 'Le convoi de survivant qu\'accompagne Rick s\'arr&ecirc;te &agrave; cause de v&eacute;hicule qui bloquent la route. Le passage d\'une horde fait fuir la fille 
	de Carol dans la for&ecirc;t. Rick par &agrave; sa recherche et la sauve en lui demendant de se cach&eacute; pendant qu\'il &eacute;loigne les marcheurs. Lorsqu\'il revient elle n\'est plus l&agrave;. Tous le groupe 
	se met alors &agrave; sa recherche. Lorsque Carl se fait tirer dessus par erreur par un chasseur. Rick l\'emmene dans la ferme des Greene. Il donne son sang pour soign&eacute; son fils. Par la suite, sa rivalit&eacute; 
	avec Shane pour Lori et Carl empire et fini par la mort de Shane.',1,2,2,true)";																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(40,'Shane Walsh', 'Shane &eacute;tait l\'adjoint et l\'ami de Rick. Apr&egrave;s les &eacute;v&egrave;nements r&eacute;cent, Shane est partie avec Lori et Carl en leur disant que 
	Rick est mort(alors qu\'il est juste dans le coma, mais bien vivant).',1,2,0,true)";																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(41,'Michonne', 'Michonne se d&eacute;place avec deux mort-vivants sans bras ni bouche et rencontre Andrea.',1,2,3,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(42,'Glenn', 'Glenn est un ancien livreur de pizza qui aide les gens dans le besoin autant que possible contre les marcheurs.',1,2,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(43,'Glenn', 'Il devient le petit ami de Maggie qu\'il rencontre avec le groupe de Rick apr&egrave;s la blessure de Carl.',1,2,2,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(44,'Daryl Dixon', 'Daryl est le fr&ecirc;re de Merle. C\est une t&ecirc;te br&ucirc;l&eacute; mais un bon chasseur.',1,2,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(45,'Dale Horvath', 'Dale est un homme ag&eacute; plein de sagesse. Il surveille les alentours du campement pr&egrave;s d\'Atlanta du haut de son Camping-car. Il est &eacute;galement 
	assez dou&eacute; en m&eacute;canique.',1,2,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(46,'Hershel Greene', 'Hershel est le p&egrave;re de la famille Grenne. Il est v&eacute;t&eacute;rinaire mais ses capacit&eacute;s en m&eacute;decine permette de sauv&eacute; Carl.',1,2,2,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(47,'Merle Dixon', 'Merle est le fr&ecirc;re de Daryl. Il est violent et raciste se qui lui vaut peut de sympathie des autres membres du groupe de survivant.',1,2,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(48,'Merle Dixon', 'Apr&egrave;s avoir p&eacute;t&eacute; un boulon, il se retrouve menott&eacute; et abandonn&eacute; sur un toit. lorsque Rick et les autres retournes sur le 
	toit pour le lib&eacute;r&eacute;, ils d&eacute;couvre que Merle c\'est coup&eacute; la main pour se lib&eacute;r&eacute;.',1,2,1,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(49,'Gustavo Fring', 'Gustavo Fring est &agrave; la t&ecirc;te de Los Pollos Hermanos, une companie de fast food. Il est &eacute;galement &agrave; la t&ecirc;te d\'un 
	r&eacute;seau de vente de meth',1,3,3,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(50,'Walter White', 'Professeur de chimie dans un lyc&eacute;e, il apprend qu\'il est atteint d\'un cancer.',1,3,0,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(51,'Walter White', 'Il produit de la meth (drogue synth&eacute;tique) en grande quantit&eacute; pour Gustavo Fring avec l\'aide de Jesse.',1,3,3,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(52,'Jesse Pinkman', 'Jesse produit de la drogue ill&eacute;galement avant de rencontrer Walter White.',1,3,0,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(53,'Mike Ehrmantraut', 'Mike est &agrave; la fois d&eacute;tective priv&eacute; et chef de la s&eacute;curit&eacute; de \"Los Pollos Hermanas\".',1,3,3,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(54,'Saul Goodman', 'Avocat avide d\'argent, il fera affaire avec Walter White et Jesse.',1,3,0,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(55,'Hank Schrader', 'Hank est agent des stup. Il est &eacute;galement le beau-fr&egrave;re de Walter White.',1,3,0,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(56,'Skyler White', 'Skyler est femme au foyer. Elle est mari&eacute;e &agrave; Walter White.',1,3,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(57,'Marie Schrader', 'Marie est l\'&eacute;pouse de Hank Schrader et la soeur de Skyler White.',1,3,0,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(58,'Baelfire', 'Il est le fils de Rumplestiltskin.',1,4,1,true)";																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(59,'Emma Swan', 'Emma est la m&eacute;re naturelle de Henry Mills, qu\'elle a fait adopt&eacute; car elle ne pouvait pas s\'en occup&eacute;.',1,4,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(60,'Mary Margaret Blanchard', 'Mary est une institutrice &agrave; Storybrooke. Elle est tr&egrave;s g&eacute;n&eacute;reuse et s\'occupe de donn&eacute; des cours &agrave; Henry',1,4,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(61,'Henry Mills', 'Henry est le fils naturel d\'Emma et adoptif de Regina Mills dont il porte le nom de famille.',1,4,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(62,'Henry Mills', 'Lorsqu\'il re&ccedil;ois le livre de contes \"Once Upon a Tima\" de Mary, il se met en t&ecirc;te que tout les habitans de Storybrooke sont des personnages de 
	contes. Il ne parvient &agrave; leur rendre leur m&eacute;moire qu\'en mangeant une part de g&acirc;teau empoisonn&eacute; &agrave; la place d\'Emma. Le sortil&egrave;ge d\'amn&eacute;sie prend fin lorsque qu\'il est 
	sauv&eacute; par un v&eacute;ritable bais&eacute; d\'amour de sa m&egrave;re biologique.',1,4,1,true)";																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(63,'Regina Mills', 'La M&eacute;chante Reine et maire de Storybrooke.',1,4,0,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(64,'Zelena', 'La M&eacute;chante Sorci&egrave;re de l\'Ouest, elle est la demi-soeur de Regina.',1,4,3,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(65,'Teal\'c', 'Teal\'c est un jaffa qui sert les faux dieux goa\'uld. Il est \'primat\' de l\'un d\'eux : Apophis.',1,5,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(66,'Teal\'c', 'Il se rebelle contre son ma&icirc;tre et rejoint l\'&eacute;quipe SG-1 qui l\'accueille avec joie.',1,5,1,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(67,'Ba\'al', 'Ba\'al est un grand ma&icirc;tre Goa\'uld. Il captura et tortura O\'Neill pendant un long moment pour obtenir des informations.',1,5,5,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(68,'Samantha Carter', 'Samantha est une officier scientifique qui travaille pour le Pentagone. Elle est recrut&eacute;e pour le projet SG.',1,5,0,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(69,'Jack O\'Neill', 'Jack est un colonel de l\'US Air Force. Il int&egrave;gre l\'&eacute;quipe SG-1 dont il devient le chef. Il aime bien faire des blagues m&ecirc;me dans 
	les situations critiques',1,5,0,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(70,'Jack O\'Neill', 'Il se retrouve temporairement avec toutes les connaissances des anciens apr&egrave;s s\'&ecirc;tre approch&eacute; d\'un appareil inconnu. Il se retrouve 
	donc &agrave; parler en ancien jusqu\'&agrave; rencontr&eacute; les Asgard sur leur monde natal.',1,5,1,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(71,'Adria', 'Quand ils retrouv&egrave;rent la trace des Anciens, r&eacute;fugi&eacute;s dans la Voie Lact&eacute;e, les Oris mirent enceinte Vala Mal Doran avec  leurs pouvoirs,
	afin que son enfant : Adria, aussi appel&eacute; L\'Oricy, puisse diriger la guerre contre eux.',1,5,10,true)";																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(72,'Daniel Jackson', 'Daniel est &eacute;gyptologue. Il a d&eacute;couvert le fonctionnement de la porte des &eacute;toiles. Il aide SG-1 gr&acirc;ce &agrave; ses connaissances des langues 
	et cultures &eacute;trang&egrave;re.',1,5,0,true)";																																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(73,'Vala Mal Doran', 'Vala est une arnaqueuse qui dupe les gens sur diff&eacute;rentes plan&egrave;tes. Elle rencontre Daniel lorsqu\'elle tente de vol&eacute; le 
	Prom&eacute;th&eacute;.',1,5,8,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(74,'Dean Winchester', 'Dean est le fr&egrave;re de Sam Winchester. Il l\'aide a vaincre des d&eacute;mons depuis la mort de leur m&egrave;re et la disparition de 
	leur p&egrave;re.',1,6,0,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(75,'Dean Winchester', 'Il apprend qu\'il doit servir d\'h&ocirc;te &agrave; l\'archange Gabriel pour combattre Lucifer. Dean refuse de donn&eacute; son corp et tente de trouv&eacute; 
	un autre moyen de sauv&eacute; le monde de l\'apocalypse. Avec son fr&ecirc;re Sam, il va cherch&eacute; les anneaux des cavali&eacute;s de l\'apocalypse. Lorsque Sam finira par accept&eacute; de servir d\'h&ocirc;te 
	&agrave; Lucifer, Dean se servira des anneaux pour l\'emprisonn&eacute; de nouveau.',1,6,5,true)";																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(76,'Sam Winchester', 'Sam est le petit fr&egrave;re de Dean Winchester. C\'est son grand fr&egrave;re qui s\'occupe de lui depuis la mort de leur m&egrave;re et la 
	disparition de leur p&egrave;re.',1,6,0,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(77,'Sam Winchester', 'La lib&eacuteration de Lucifer ayant &eacute;t&eacute; produite. Sam doit lui servir de corp sur Terre. Il refuse, jusqu\'&agrave; que Lucifer menace Dean si il ne 
	lui laissait pas utilis&eacute; son corp. Sam accepte, et est donc contr&ocirc;l&eacute; par Lucifer. Dean parvient en l\'enferm&eacute; dans son ancienne prison avec les anneaux des 4 cavaliers de 
	l\apocalypse.',1,6,5,true)";																																															$bdd->prepare($req)->execute();	
	$req = "INSERT INTO information VALUES(78,'Castiel', 'Castiel est un ange dans le corp d\'un humain ayant accept&eacute; de servire de receptacle sur terre. Il aidera Sam et Dean &agrave; combattre les forces 
	d&eacute;moniaque.',1,6,5,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(79,'Bobby Singer', 'Bobby est un chasseur de cr&eacute;atures surnaturelles et un tr&egrave;s bon ami du p&egrave;re de Sam et Dean.',1,6,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(80,'Ruby', 'Ruby est une jeune femme blonde qui aide les fr&ecirc;res Winchester &agrave; combattre les d&eacute;mons',1,6,3,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(81,'Lucifer', 'Lucifer est le diable incarn&eacute;. Il fut lib&eacute;r&eacute; lorsque Sam tua Lilith, brisant ainsi le dernier sceau de sa prison.',1,6,4,true)";				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(82,'Lucifer', 'Il parvient &agrave; avoir un h&ocirc;te temporaire, ne pouvant avoir Sam. Grace &agrave; ses grands pouvoirs, il tue les dieux impis. Sous la contraite, Sam fini 
	par accept&eacute; de servir d\'h&ocirc;te pour Lucifer. Dean r&eacute;ussi finalement &agrave; l\'envoyer de nouveau dans la cage avec les 4 anneaux des cavaliers de l\'apocalypse : La Mort, La Famine, La maladie, 
	et La Guerre',1,6,5,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(83,'Alex Vause', 'Alex est une ancienne trafiquante de drogue. Après une p&eacute;riode de d&eacute;pendance &agrave; la drogue, elle s\'arr&ecirc;te pendant son s&eacute;jour en 
	prison.',1,7,0,true)";																																																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(84,'Piper Chapman', 'Piper est une femme bisexuelle condamn&eacute;e pour trafic de drogue 10 ans plus t&ocirc;t.',1,7,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(85,'Piper Chapman', 'Elle se retrouve dans la m&ecirc;me chambre que Claudette, avec  qui elle s\'entend mal au d&eacute;but mais elles finissent par &ecirc;tre amis.',1,7,1,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(86,'Sam Healy', 'Sam est un ancien gardien de prison. Il sert d&eacute;sormais de conseiller dans la prison de la s&eacute;rie.',1,7,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(87,'Galina (Red) Reznikov', 'Galina est une co-d&eacute;tenue de Piper. Elle dirige la cuisine et la communaut&eacute; blanche de la prison.',1,7,0,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(88,'Suzanne (Crazy Eyes) Warren', 'Suzanne prend Piper pour sa m&egrave;re adoptive et la frappe au visage.',1,7,2,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(89,'Batman', 'Batman est le nom donn&eacute; &agrave Bruce Wayne lorsqu\'il porte son costume de chauve-souris. Il combat les criminels de la ville de Gotham',1,8,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(90,'Bruce Wayne', 'Bruce est un homme d\'affaire &agrave; la t&ecirc;te d\'une grande entreprise. La nuit il porte un masque et combat les criminels et est appel&eacute; Batman.',1,8,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(91,'Commissaire James Gordon', 'James Gordon est un polici&eacute; incorruptible contrairement au reste des flics de Gotham. Il est &eacute;galement le p&egrave;re de Barbara',1,8,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(92,'Le Joker', 'Le Joker est un criminel psychopate avec un sourire &eacute;norme. Il adore faire des pi&egrave;ge &agrave; Batman.',1,8,0,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(93,'Alfred', 'Alfred est le majordome de la famille Wayne. Il s\'occupa de Bruce apr&egrave;s la mort de ses parents. Alfred sais que Bruce est Batman et l\'aide lors de ses 
	enqu&ecirc;tes.',1,8,0,true)";																																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(94,'Robin', 'Robin est un jeune gar&ccedil;on de cirque, qui apr&egrave; la mort de son p&egrave;re, rejoint Batman pour combattre le crime.',1,8,2,true)";						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(95,'Eric Cartman', 'Eric Cartman est un petit gar&ccedil;on grassouillet d\'une m&eacute;chancet&eacute; sans limites.',1,9,0,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(96,'Kyle Broflovski', 'Kyle est l\'un des 4 personnages principaux. Il fait partie d\'une famille juive, se dont Cartman en profite pour utilis&eacute; les 
	st&eacute;r&eacute;otypes contre lui.',1,9,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(97,'Kyle Broflovski', 'Il est le meilleur joueur de basket de South Park et souhaite rejoindre une grande &eacute; mais il n\'est ni grand, ni noir et est donc recal&eacute;. 
	Il subit donc une opp&eacute;ration esth&eacute;tique pour chang&eacute; &ccedil;&agrave;. Il fait une nouvelle op&eacute;ration pour annul&eacute; lorsqu\'il d&eacute;couvre que cela ne lui donne que l\'apparence 
	mais pas le fonctionnement normal d\'un athl&egrave;te.',1,9,9,true)";																																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(98,'Kenny McCormick', 'Kenny est le fils d\'une famille extremenent pauvre. Ces paroles sont imcompr&eacute;hensible (sauf par les autres personnages) &agrave; cause de la capuche de son 
	menteau qu\'il ne retire jamais',1,9,0,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(99,'Butters Stotch', 'Butters est un enfant na&Iuml;f de l\'&eacut;cole. Il reste cependant optimiste la majorit&eacute; du temps',1,9,0,true)";									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(100,'M. Mackey', 'M. Mackey est le conseiller d\'orientation de l\'&eacute; de South Park. Il ponctue souvent ses phrases du terme \"M\'Voyez...\"',1,9,0,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(101,'Servietsky', 'Servietsky est une serviette vivante grace &agrave; la puce qui lui est int&eacute;gr&eacute;e. Il est le plus souvent dans les nuages car il a trop fum&eacute;.',1,9,5,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(102,'Randy Marsh', 'Randy est le p&egrave; de Stan. Il est g&eacute;ologue et l\'un des seul scientifique de South Park. Il a un probl&egrave;me avec l\'alcool se qui peut le 
	mettre en mauvaise posture.',1,9,0,true)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(103,'Randy Marsh', 'Apr&egrave;s avoir mang&eacute; chinoi, il est constip&eacute; pendant plusieurs jours lui permettant de faire un gros &eacute;tron. Ses amis au bar, lui 
	propose alors d\'essayer de battre le record du monde du plus gros caca. Il fini finalement a gagn&eacute; avec un &eacute;tron plus gros que lui.',1,9,11,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(104,'Leonard Hofstadter', 'Leonard vit en colocation avec Sheldon Cooper &agrave Pasadena. C\'est un physicien geek comme lui. Il est ami avec Howard Wolowitz et Rajesh Koothrappali',1,10,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(105,'Sheldon Cooper', 'Sheldon vit en colocation avec Sheldon Cooper &agrave; Pasadena. C\'est un physicien geek comme lui. Il est ami avec  Howard Wolowitz et Rajesh Koothrappali',1,10,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(106,'Penny', 'Penny est une jeune fille blonde qui s\'installe dans l\'appartement en face de celui de Sheldon et Leonard. Elle fait des petits boulo pour pay&eacute; son loy&eacute.',1,10,0,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(107,'Howard Wolowitz', 'Howard est un homme petit ami de Sheldon, Leonard et Rajesh. Il est ing&eacute;nieur et travail dans le m&ecirc;me institut que ses amis. Malheuresement pour lui, 
	il vit toujours chez sa m&egrave;re qui &agrave; de nombreux d&eacute;faults.',1,10,0,true)";																															$bdd->prepare($req)->execute();
	
	/* infos lieux */
	$req = "INSERT INTO information VALUES(108,'$leseyrie', 'Forteresse imprenable de la maison Arryn. Ce ch&acirc;teau est b&acirc;tit dans les montagne et poss&egrave;de un trou dans la salle du tr&ocirc;ne qui donne 
	sur la vall&eacute; des centaines de m&egrave;tres plus bas. Les ennemies et criminels sont jet&eacute; par ce trou.',2,1,0,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(109,'$lesilesdefer', 'Les &Icirc;les de fer constituent un archipel de sept &icirc;les de tailles tr&egrave;s diff&eacute;rentes qui se trouvent à l\'ouest du territoire du Conflans. 
	Cet Archipel est gouvern&eacute; par la maison Greyjoy. Les gens qui y vivent sont principalement des marins qui gagne leur vie gr&acirc;ce au pillage. La capital de cette r&eacute;gion est Pyke.',2,1,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(110,'$lesilesdefer', 'Theon Greyjoy d&eacute;barque sur les &icirc;les de fer pour cherch&eacute; du renfort de la part de son p&egrave;re. Il y rencontre &eacute;galement sa 
	soeur Asha Greyjoy.',2,1,2,true)";																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(111,'Le Mur', 'Le Mur est une gigantesque muraille de glace, de pierre et de magie qui s&eacute;pare le royaume des Sept Couronnes des terres glac&eacute;es et sauvages. Il mesure 
	pr&egrave;s de sept cents pieds de haut et de cent lieues de long d\'est en ouest. Il a &eacute;t&eacute; cr&eacute;e il y a 8000 ans pour emp&ecirc;ch&eacute; que les marcheurs blanc reviennent.',2,1,0,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(112,'$chateaunoir', 'Ch&acirc;teaunoir est le plus grand fort que poss&egrave;de la Garde de Nuit. Il est coll&eacute; au \"Mur\" qui prot&egrave;ge le royaume des hommes 
	de celui des sauvageons.',2,1,0,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(113,'Vivesaigues', 'Maison ancestral de la famille Tully. Robb et Catelyn Stark s\'y rende pour rendre hommage &agrave; la mort d\un parent Tully.',2,1,3,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(114,'$portreal', 'Port-R&eacute;al est la capital des 7 couronnes de Westeros. C\'est l&agrave; que ce trouve le tr&ocirc;ne de fer. Cette grande ville est domin&eacute 
	par le donjon rouge, qui est le si&egrave;ge de la royaut&eacute;.',2,1,0,true)";																																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(115,'Qarth', 'Qarth est une ancienne ville portuaire situ&eacute;e sur la c&ocirc;te sud d\'Essos. Deaneris parvient &agrave; cette ville mais ne semble pas y &ecirc;tre 
	appr&eacute;ci&eacute;. La puissante corporation des Treize g&egrave;re le gouvernement et la protection avec d\'autres ordres. C\'est l&agrave;-bas que se trouve l\'autel des non-mourants.',2,1,2,true)";			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(116,'Winterfell', 'Capitale du nord, elle est dirig&eacute;e par la famille Stark depuis plusieurs milliers d\'ann&eacute;es.',2,1,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(117,'Winterfell', 'Apr&egrave;s la chute de Robb Stark, Winterfell appartient d&eacute;sormais &agrave; la famille Bolton.',2,1,5,true)";											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(118,'Dorne', 'Dorne est au Sud de Westeros et est dirig&eacute; par la famille Martell.',2,1,4,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(119,'Atlanta', 'Atlanta est la ville dans laquelle se rend Rick à cheval, il y rencontre Glenn et beaucoup d\'autres.',2,2,4,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(120,'Ferme familiale des Greene', 'Cette exploitation fermi&egrave;re est le refuge du groupe de Rick apr&egrave;s que Carl soit bless&eacute;.',2,2,2,true)";					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(121,'Prison de The Walking Dead', 'Cette prison est d&eacute;couverte par Rick. Apr&egrave;s un nettoyage des r&ocirc;deurs present, le groupe de survivants s\'y installe',2,2,3,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(122,'Terminus', 'Le Terminus est un lieu indiqu&eacute; par de nombreux panneaux comme un lieu de survit. Il s\'av&egrave;re que les gens qui y vivent ne sont pas si acceuillant 
	que les indications le disent.',2,2,4,true)";																																											$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(123,'Terminus', 'Le Terminus est en ruine apr&egrave;s l\'attaque de Carol pour sauver ses amis aux mains des cannibales de la prison',2,2,5,true)";								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(124,'Superlab', 'Walter White produira de la meth en grande quantit&eacute; pour Gustavo Fring dans se grand laboratoire cach&eacute; sous une blanchisserie &agrave; Albuquerque.',2,3,3,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(125,'Superlab', 'Walter White et Jesse Pinkman font br&ucirc;l&eacute; le Superlab pour &eacute;vit&eacute; de laiss&eacute; des traces apr&egrave;s la mort de Fring.',2,3,4,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(126,'Maison familiale des White', 'Cette maison est celle de la famille de Walter White. La famille y passe beaucoup de leur temps libre.',2,3,0,true)";							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(127,'Maison familiale des White', 'Apr&egrave;s la d&eacute;couverte du trafic de Walter White, et la d&eacute;sertion de la maison par la famille, la maison reste abandonn&eacute;e.
	 Walter White y retourne pour r&eacute;cup&eacute;rer le puissant poison qu\'il y avait cach&eacute;.',2,3,5,true)";																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(128,'Car Wash', 'Station de lavage dans lequel Walter White travaille pour compl&eacute;ter ses revenus en tant que caissier.',2,3,0,true)";										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(129,'Los Pollos Hermanos', 'Los Pollos Hermanos est un fast-food dans lequel se rend Walter White pour conclure affaire avec Gustavo Fring : de l\'argent contre une grande 
	quantit&eacute; de meth.',2,3,3,true)";																																													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(130,'Storybrooke', 'Ville dans le Maine. Tous les personnages de contes y ont &eacute;t&eacute; transport&eacute;s.',2,4,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(131,'Le Pays Imaginaire', 'Monde où vivent Peter Pan et les Enfants Perdus.',2,4,3,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(132,'Agrabah', 'Agrabah est un lieu au climat d&eacute;sertique du Royaume enchant&eacute;. On y trouve les personnages des contes des Milles et une nuits, mais principalement 
	ceux d\'Aladin.',2,4,4,true)";																																															$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(133,'$laforetenchantee', 'Cette immense for&ecirc;t recouvre une grande partie des royaume enchant&eacute;e. Il y a de nombreux animaux et cr&eacute;atures qui y vivent.',2,4,2,true)";	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(134,'Stargate Command (SGC)', 'Base militaire sous une montagne. C\'est l&agrave; qu\'est la porte des &eacute;toiles et que les &eacute;quipes SG partent en exploration 
	de mondes aliens.',2,5,0,true)"; 																																														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(135,'Base d\'Anubis', 'Cette base d\'Anubis poss&egrave;de une arme des anciens utilis&eacute;e pour d&eacute;truire la porte des &eacute;toiles sur la Terre.',2,5,4,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(136,'Tartarus', 'Anubis utilisa cette plan&egrave;te pour y construire un laboratoire servant &agrave; la cr&eacute;ation d\'une arm&eacute;e de super soldat.',2,5,8,true)";		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(137,'$penitentierdelitchfield', 'Prison dans laquelle se d&eacute;roule l\'histoire. Elle est dirig&eacute; par le D&eacute;partement F&eacute;d&eacute;ral de 
	Correction.',2,7,0,true)";																																																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(138,'L\'asile d\'Arkham', 'L\'asile d\'Arkham est un lieu o&ugrave; sont intern&eacute;s les psycopathe de Gotham',2,8,0,true)";													$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(139,'Gotham City', 'Gotham est une grande ville dans laquel Batman combat les criminels.',2,8,0,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(140,'Ecole de South Park', 'L\'eacute;cole &eacute;l&eacute;mentaire de South Park est un lieu imporant dans les aventures des personnages car c\'est l&agrave; que vont en cours 
	les 4 amis Cartman, Kyle, Stan et Kenny.',2,9,0,true)";																																									$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(141,'$cinemadesouthpark', 'Ce cinema est celui o&eacute; se retrouve les enfants de South Park pour voir les films du moment. En g&eacute;n&eacute;ral, les films 
	pr&eacute;sent&eacute;s sont des parodies de films r&eacute;els',2,9,0,true)";																																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(142,'City Wok', 'Le City Wok est un restaurant chinoi dirig&eacute; par Tuong Lu Kim. C\'est &eacute;galement un petit a&eacute;roport : City Airlines, avec 1 seul avion.',2,9,6,true)";$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(143,'Appartement de Sheldon et Leonard', 'Cet appartement &eacute;tait habit&eacute; par Sheldon et un colocataire qui n\'en pouvait plus de ses habitudes &eacute;tranges. Leonard 
	arrivant dans la ville et ayant besoin d\'un logement pas trop ch&egrave;re, accepte de passer un contrat avec Sheldon pour habiter dans l\'appartement..',2,10,0,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(144,'Appartement de Penny', 'Cet appartement est lou&eacute; par Penny et est souvent en d&eacute;sordre, car elle est plut&ocirc;t bordelique.',2,10,0,true)";					$bdd->prepare($req)->execute();
	
	
	/* infos evenements */
	$req = "INSERT INTO information VALUES(145,'Game of Thrones - La chute de Bran','https://www.youtube.com/watch?v=VUXBxLlgpa8',3,1,1,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(146,'$decapitationdunchevalparlamontagne','https://www.youtube.com/watch?v=UpQ-tOGXZiU',3,1,1,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(147,'Les noces pourpres','https://www.youtube.com/watch?v=OuD8tjcggjI',3,1,3,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(148,'La mort de Joffrey','https://www.youtube.com/watch?v=V5K7motTFf8',3,1,4,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(149,'Duel judiciaire Oberyn contre La Montagne','https://www.youtube.com/watch?v=Pr9Do6blB4c',3,1,4,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(150,'La mort de John Snow','https://www.youtube.com/watch?v=HVkHpeW8zJo',3,1,5,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(151,'La mort de Ned Stark','https://www.youtube.com/watch?v=PW6wfXPeJTw',3,1,1,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(152,'La mort de Shane','https://www.youtube.com/watch?v=9L510ov05NI',3,2,2,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(153,'La mort de Gustavo Fring','https://www.youtube.com/watch?v=R6CjCEyAJ2s',3,3,4,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(154,'Say my name (Dit mon nom)','https://www.youtube.com/watch?v=C9MGU7krXnQ',3,3,5,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(155,'$debutdelepisode1','https://www.youtube.com/watch?v=Gz0ExmgMGIk',3,2,1,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(156,'La mort de Neal','https://www.youtube.com/watch?v=lMXXCDe7n1U',3,4,3,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(157,'Le mariage de Belle et Rumplestiltskin','https://www.youtube.com/watch?v=UPV90t8afB0',3,4,3,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(158,'$laresurrectiondemalefique','https://www.youtube.com/watch?v=EW9vdjYJBcc',3,4,4,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(159,'Bataille de la super porte','https://www.youtube.com/watch?v=FRIvaO3i5EM',3,5,9,true)";																						$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(160,'$decollagedupromethee','https://www.youtube.com/watch?v=-Xdlr30G6PM',3,5,6,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(161,'Stargate SG1 O\'Neill et l\'ascenceur','https://www.youtube.com/watch?v=BljU3P63MSw',3,5,6,true)";																			$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(162,'Stargate SG1 L\'histoire sans fin','https://www.youtube.com/watch?v=3rJqJDhgHiQ',3,5,4,true)";																				$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(163,'Castiel regarde un film','http://www.dailymotion.com/video/xmolzy_supernatural-scene-en-francais-avec-castiel_tv',3,6,4,true)";												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(164,'PUDDING !','https://www.youtube.com/watch?v=gzi7To5ZkSA',3,6,5,true)";																										$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(165,'Batman contre Le Joker','https://www.youtube.com/watch?v=0l4rukfbwIU',3,8,2,true)";																							$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(166,'Le plus gros caca du monde', 'https://www.youtube.com/watch?v=8WmOFZIMDm0',3,9,11,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(167,'South Park - L\'évolution selon Mme Garrison','https://www.youtube.com/watch?v=F9NPnKZkF-Y',3,9,10,true)";																	$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(168,'Les rouquins!!!','https://www.youtube.com/watch?v=Mpr3n9tkid8',3,9,9,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(169,'$sheldondrogue','https://www.youtube.com/watch?v=peyUmtgAfZU',3,10,2,true)";																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(170,'The Big Bang Theory - Belles poutres','https://www.youtube.com/watch?v=rYi6jM21S0Y',3,10,3,true)";																			$bdd->prepare($req)->execute();

	/* infos interviews */
	$req = "INSERT INTO information VALUES(171,'$interviewdesacteursetrealisateursavantlasaison2','https://www.youtube.com/watch?v=--jx-ZKmHkE',4,1,2,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(172,'Interview des acteurs avant le lancement de la saison 6','https://www.youtube.com/watch?v=hX-btYt5caY',4,1,6,true)";														$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(173,'Supernatural Comic Con 2015','https://www.youtube.com/watch?v=nvMTCXOWEkU',4,6,10,true)";																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(174,'Interview de Laura Prepon et Laverne Cox','https://www.youtube.com/watch?v=ZZupBPrGefw',4,7,3,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(175,'Reportage sur les voix françaises de South Park', 'https://www.youtube.com/watch?v=y7g1Kp2RY_0',4,9,10,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(176,'Saison 5 Featurette Behind the scenes ChicksNGuns', 'https://www.youtube.com/watch?v=1-Heb9RBiOA',4,3,5,true)";																$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(177,'Once Upon A Time - Panel Comic Con 2015', 'https://www.youtube.com/watch?v=ABcObT0a6Xo',4,4,5,true)";																		$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(178,'Once Upon A Time - Panel Comic Con 2014', 'https://www.youtube.com/watch?v=52HXMQPJvhI',4,4,4,true)";																		$bdd->prepare($req)->execute();
	
	$req = "INSERT INTO information VALUES(179,'Tyrion Lannister', 'texte 1.',1,1,0,false)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(180,'Tyrion Lannister', 'texte 2.',1,1,0,false)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(181,'Tyrion Lannister', 'texte 3.',1,1,0,false)";																																												$bdd->prepare($req)->execute();
	$req = "INSERT INTO information VALUES(182,'Tyrion Lannister', 'texte 4.',1,1,0,false)";																																												$bdd->prepare($req)->execute();
	
	
	/* comptes */
	$req = "INSERT INTO user VALUES(1,'user','user','',0,0)";																																								$bdd->prepare($req)->execute();
	$req = "INSERT INTO user VALUES(2,'modo','modo','modo@modos.fr',1,1)";																																					$bdd->prepare($req)->execute();
	$req = "INSERT INTO user VALUES(3,'admin','admin','admin@admins.fr',2,0)";																																				$bdd->prepare($req)->execute();

	
	
?>