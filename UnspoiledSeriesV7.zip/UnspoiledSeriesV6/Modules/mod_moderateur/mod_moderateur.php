<?php
class ModuleModerateur extends ModuleGenerique {
	public function __construct() {
		if (isset ( $_SESSION ['estModerateur'] ) && $_SESSION ['estModerateur'] == true) {
			$module = "moderateur";
			if (isset ( $_GET ['action'] ))
				$action = $_GET ['action'];
			else
				$action = 'ajoutInformations';
			require_once ("Modules/mod_$module/controleur_$module/c_moderateur.php");
			$this->controleur = new ControleurModerateur ();
			switch ($action) {
				case 'ajoutInformations' :
					$this->controleur->ajout ();
					break;
				case 'voirPropositions' :
					$this->controleur->voir ();//permet de voir les propositions
					break;
				case 'ajoutPropositions' :
					$this->controleur->ajoutproposition ();
					break;
				case 'supprimePropositions' :
					$this->controleur->supprimeproposition ();
					break;
				case 'voirInformations' :
					$this->controleur->voirinformations ();//permet de voir les info d�j� valide dans la bdd
					break;
				case 'modifieInformations' :
					$this->controleur->ajoutproposition ();
					break;
				case 'garderProposition' :
					$this->controleur->garderproposition ();
					break;
				case 'garderInformations' :
					$this->controleur->supprimeproposition ();
					break;
			}
		} else
			exit ( 'Vous devez �tre administrateur pour acc�der � cette partie du site.' );
	}
}
?>
