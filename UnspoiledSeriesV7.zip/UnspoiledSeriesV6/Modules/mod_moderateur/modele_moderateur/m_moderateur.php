<?php

class ModeleModerateur extends DBMapper {
	
	public static function ajouterInfo($serie, $categorie, $nomInfo, $texteInfo, $saison) {
		$req = self::$database->prepare ( "INSERT INTO information(nom_information, texte_information, id_categorie_information, id_serie_information, saison_information, info_valide) VALUES (?, ?, ?, ?, ?, true)" );
		$count = $req->execute ( array($nomInfo, $texteInfo, $categorie, $serie, $saison));

		if ($count === false)
			return false;
		if ($count === 0)
			return false;
		if ($count != 0 && $count != false) {
			return true;
		}
	}
	
	public static function modifierInfo($serie, $categorie, $nomInfo, $texteInfo, $saison) {
		$req = self::$database->prepare('UPDATE information SET nom_information = :nv_nom_information, texte_information = :nv_texte_information, id_categorie_information = :nv_id_categorie_information, id_serie_information = :nv_id_serie_information, saison_information = :nv_saison_information, info_valide = :nv_info_valide WHERE id_information = :nv_id_information');
		$count = $req->execute(array(
		'nv_nom_information' => $nomInfo,
		'nv_texte_information' => $texteInfo,
		'nv_id_categorie_information' => $categorie,
		'nv_id_serie_information' => $serie,
		'nv_saison_information' => $saison,
		'nv_info_valide' => true,
		'nv_id_information' => $_SESSION['idinfoproposition']
		));
		
		if ($count === false)
			return false;
		if ($count === 0)
			return false;
		if ($count != 0 && $count != false) {
			return true;
		}
	}
	
	public static function validerProposition($id_info) {
		$req = self::$database->prepare('UPDATE information SET info_valide = :nv_info_valide WHERE id_information = :nv_id_information');
		$count = $req->execute(array(
		'nv_info_valide' => true,
		'nv_id_information' => $id_info
		));
		
		if ($count === false)
			return false;
		if ($count === 0)
			return false;
		if ($count != 0 && $count != false) {
			return true;
		}
	}
	
	public static function supprimerInfo($id_info) {
		$req = self::$database->prepare('DELETE FROM information WHERE id_information = :nv_id_information');
		$count = $req->execute(array(
		'nv_id_information' => $id_info
		));
		
		if ($count === false)
			return false;
		if ($count === 0)
			return false;
		if ($count != 0 && $count != false) {
			return true;
		}
	}
	
	public static function getSeries() {
		$req = self::$database->prepare("SELECT id_serie, nom_serie from serie ORDER BY nom_serie");
		$req->execute();
		$series = $req->fetchAll(PDO::FETCH_ASSOC);
		return $series;
	}
	
	public static function getSerieCompte() {
		$req = self::$database->prepare("SELECT login, serieCompte from user WHERE login='".$_SESSION ["nomModerateur"]."'");
		$req->execute();
		$resultcompte = $req->fetchAll(PDO::FETCH_ASSOC);
		return $resultcompte;
	}
	
	public static function getPropositions() {	//récupère les propositions en fonction de la série associé au modérateur
		$req = self::$database->prepare("SELECT id_information, nom_information, texte_information, saison_information, info_valide from information WHERE id_serie_information=".$_SESSION ["seriecompte"]."");
		$req->execute();
		$proposition = $req->fetchAll(PDO::FETCH_ASSOC);
		return $proposition;
	}
	
	public static function getInfoPropositions() {	//récupère les info de la propositions en fonction de son id
		$req = self::$database->prepare("SELECT id_information, nom_information, texte_information, saison_information, info_valide from information WHERE id_information=".$_SESSION ["idinfoproposition"]."");
		$req->execute();
		$infoproposition = $req->fetchAll(PDO::FETCH_ASSOC);
		return $infoproposition;
	}
	
	public static function getInfoExistante() {	//récupère les info de la propositions en fonction de son id
		$req = self::$database->prepare("SELECT id_information, nom_information, texte_information, saison_information, info_valide from information WHERE id_information=".$_SESSION ["idinfoexistante"]."");
		$req->execute();
		$infoexistante = $req->fetchAll(PDO::FETCH_ASSOC);
		return $infoexistante;
	}

	public static function informationExistante($serie, $categorie, $nomInfo, $saison) {	
		$req = self::$database->prepare ( "SELECT * from information WHERE id_serie_information=? AND id_categorie_information=? AND nom_information=? AND saison_information=? AND info_valide=1" );
		$req->execute ( array($serie, $categorie, $nomInfo, $saison));
		$infoexistante = $req->fetchAll(PDO::FETCH_ASSOC);
		foreach($infoexistante as $value){
			$_SESSION ['idinfoexistante']=$value['id_information'];
		}
		$count = $req->rowCount ();
		return $count+1;
	}
}

?>
