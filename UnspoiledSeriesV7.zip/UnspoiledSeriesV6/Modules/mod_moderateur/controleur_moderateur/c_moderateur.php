<?php
require_once ("Modules/mod_moderateur/modele_moderateur/m_moderateur.php");
require_once ("Modules/mod_moderateur/vue_moderateur/v_moderateur.php");
class ControleurModerateur extends ControleurGenerique {
	
	public function ajouter() {
		$existeDansLaBase = ModeleModerateur::informationExistante ($_POST['serie'], $_POST['categorie'], $_POST ['nomInfo'], $_POST['saison']);
		if ($existeDansLaBase == 1) {
			$ajoutReussie = ModeleModerateur::ajouterInfo ($_POST['serie'], $_POST['categorie'], $_POST['nomInfo'], $_POST['texteInfo'], $_POST['saison']);
			if ($ajoutReussie) {
				$this->constructView ( 'VueModerateur', 'afficherAjoutReussie', array () );
			} else
				$this->constructView ( 'VueModerateur', 'afficherAjoutRatee', array () );
		} else {
			$info = ModeleModerateur::getInfoExistante();
			$this->constructView ( 'VueModerateur', 'afficherInfoDejaExistante', array ($info) );
		}
	}
	public function modifier() {
		$existeDansLaBase = ModeleModerateur::informationExistante ($_POST['serie'], $_POST['categorie'], $_POST ['nomInfo'], $_POST['saison']);
		echo $existeDansLaBase;
		if ($existeDansLaBase == 1) {
			$ajoutReussie = ModeleModerateur::modifierInfo ($_POST['serie'], $_POST['categorie'], $_POST['nomInfo'], $_POST['texteInfo'], $_POST['saison']);
			if ($ajoutReussie) {
				$this->constructView ( 'VueModerateur', 'afficherAjoutReussie', array () );
			} else
				$this->constructView ( 'VueModerateur', 'afficherAjoutRatee', array () );
		} else {
			$infoexistante = ModeleModerateur::getInfoExistante();
			$infoproposition = ModeleModerateur::getInfoPropositions();
			$this->constructView ( 'VueModerateur', 'afficherInfoDejaExistante', array ($infoexistante, $infoproposition) );
		}
	}
	public function modifierproposition() {	//valide l'information de la proposition que l'on veut garder
			$ajoutReussie = ModeleModerateur::validerProposition ($_SESSION['idinfoproposition']);
			if ($ajoutReussie) {
				$this->constructView ( 'VueModerateur', 'afficherAjoutReussie', array () );
			} else
				$this->constructView ( 'VueModerateur', 'afficherAjoutRatee', array () );
	}
	public function supprimer() {
			$supprReussie = ModeleModerateur::supprimerInfo ($_SESSION['idinfoproposition']);
			if ($supprReussie) {
				$this->constructView ( 'VueModerateur', 'afficherSuppressionReussie', array () );
			} else
				$this->constructView ( 'VueModerateur', 'afficherSuppressionRatee', array () );
		}
	public function supprimerexistant() {	//supprime l'info exitante lorsque l'on souhaite garder l'information de la proposition
			$supprReussie = ModeleModerateur::supprimerInfo ($_SESSION ['idinfoexistante']);
			if ($supprReussie) {
				$this->constructView ( 'VueModerateur', 'afficherSuppressionReussie', array () );
			} else
				$this->constructView ( 'VueModerateur', 'afficherSuppressionRatee', array () );
		}
	public function afficherFormulaireAjout() {//pour afficher la page de formulaire d'ajout du moderateur
		$series = ModeleModerateur::getSeries();
		$seriecompte = ModeleModerateur::getSerieCompte();
		$_SESSION['seriecompte'] = $seriecompte;
		$this->constructView ( 'VueModerateur', 'afficherFormulaireAjout', array ($series, $seriecompte) );
	}
	public function afficherFormulaireVoir() {//pour afficher la page de vue des informations proposer par les utilisateurs aux modérateurs
		$series = ModeleModerateur::getSeries();
		$resultcompte = ModeleModerateur::getSerieCompte();
		foreach ($resultcompte as $value3) {
			$_SESSION['seriecompte'] = $value3['serieCompte'];
		}
		$propositions = ModeleModerateur::getPropositions();
		$this->constructView ( 'VueModerateur', 'afficherFormulaireVoir', array ($series, $propositions) );
	}
	public function afficherFormulaireAjoutProposition() {//pour afficher la page de formulaire d'ajout du moderateur prérempli avec les informations d'une proposition choisi
		$series = ModeleModerateur::getSeries();
		$seriecompte = ModeleModerateur::getSerieCompte();
		$_SESSION['seriecompte'] = $seriecompte;
		$_SESSION['idinfoproposition'] = $_POST['id_info'];
		$infoproposition = ModeleModerateur::getInfoPropositions();
		$this->constructView ( 'VueModerateur', 'afficherFormulaireAjoutProposition', array ($series, $seriecompte, $infoproposition) );
	}
	public function afficherFormulaireVoirInfo() {//pour afficher la page de vue des informations valide de la bdd aux modérateurs
		$series = ModeleModerateur::getSeries();
		$resultcompte = ModeleModerateur::getSerieCompte();
		foreach ($resultcompte as $value3) {
			$_SESSION['seriecompte'] = $value3['serieCompte'];
		}
		$propositions = ModeleModerateur::getPropositions();
		$this->constructView ( 'VueModerateur', 'afficherFormulaireVoirInfo', array ($series, $propositions) );
	}
	public function ajout() {
		if (isset($_POST['serie']) && isset($_POST['categorie']) &&  isset($_POST['nomInfo']) && isset($_POST['texteInfo']) && isset($_POST['saison'])) {
			$this->ajouter ();
		} else {
			$this->afficherFormulaireAjout ();
		}
	}
	public function voir() {//permet de voir les propositions
			$this->afficherFormulaireVoir ();
	}
	public function ajoutproposition() {
		if (isset($_POST['serie']) && isset($_POST['categorie']) &&  isset($_POST['nomInfo']) && isset($_POST['texteInfo']) && isset($_POST['saison'])) {
			$this->modifier ();
		} else {
			$this->afficherFormulaireAjoutProposition ();
		}
	}
	public function supprimeproposition() {
		$_SESSION['idinfoproposition'] = $_POST['id_info'];
		$this->supprimer();
	}
	public function voirinformations() {//permet de voir les info déjà valide dans la bdd
			$this->afficherFormulaireVoirInfo ();
	}
	public function garderproposition() {
		$this->supprimerexistant();
		$this->modifierproposition();
	}
}
?>
