<?php
class VueModerateur {
	
	public static function afficherFormulaireAjout($series, $seriecompte) {
	?>
		<h1 id="labelAccueil">Ajouter une information</h1>

		<div id="formulaire" class="container">
			<div class="form-group4">
				<form  action="index.php?module=moderateur&action=ajoutInformations" method="POST">
					<?php
					foreach ($seriecompte as $value) {
						foreach ($series as $value2) {
							if($value2['id_serie']==$value['serieCompte']){
								?><h3 class="texteblanc"><?php echo $value2['nom_serie']; ?></h3><?php
							}
						}
						?>
						
						<input type="hidden" id="serie" name="serie" value=<?php echo $value['serieCompte'];?> />
					<?php
					}
					?>
					<input name="nomInfo" type="text" placeholder="NOM" id="nomInfo" required>
					<input name="saison" type="text" placeholder="SAISON" id="saison" required>
					
					<select name="categorie">
						<option value="1"> Personnages </option>
						<option value="2"> Lieux </option>
						<option value="3"> Ev&eacute;nements </option>
						<option value="4"> Interviews </option>					
					</select>
					
					</br>
					<textarea name="texteInfo" type="text" placeholder="TEXTE / LIEN" id="texteInfo" rows="5" cols="50" required></textarea>
				
					<input type="submit" value="AJOUT" id="bouton">
				</form>
			</div>       
		</div>
	<?php
	}
	public static function afficherAjoutReussie() {
		echo ("Ajout r&eacute;ussie. <br>");
	}
	public static function afficherAjoutRatee() {
		echo ("Echec de l'ajout. <br>");
	}
	public static function afficherSuppressionReussie() {
		echo ("Suppression reussie. <br>");
	}
	public static function afficherSuppressionRatee() {
		echo ("Echec de la suppression. <br>");
	}/////////////////////FORMULAIRE INFO DEJA EXISTANTE////////////////////////////////
	public static function afficherInfoDejaExistante($infoexistante, $infoproposition) {
		?><h1 id="labelAccueil">Informations d&eacute;j&agrave; existantes, choisir laquelle garder</h1></br><?php
		foreach ($infoproposition as $value) {	//nouvelle info
				echo ("Information de la proposition");
				?>
		<div id="formulaire" class="container">
				<form action="index.php?module=moderateur&action=garderProposition" method="POST">
					<div class="form-group5"><?php echo $value['nom_information'];?></br>Saison : <?php echo $value['saison_information'];?></br><?php echo $value['texte_information'];?>
					<input type="hidden" id="id_info" name="id_info" value=<?php echo $value['id_information'];?> />
					</br><input type="submit" value="GARDER" id="bouton2">
				</form>
					</div>
		</div>
				</br>
				<?php
				$_SESSION['infoasupprimer']=$value['id_information'];	//on r�cup�re la valeur id de la proposition pour pouvoir la supprim� lorsqu'on clic sur garder l'existant
		}
		foreach ($infoexistante as $value) {	//ancienne info
				echo ("Information d�j� existante");
				?>
		<div id="formulaire" class="container">
				<form action="index.php?module=moderateur&action=supprimePropositions" method="POST">
					<div class="form-group5"><?php echo $value['nom_information'];?></br>Saison : <?php echo $value['saison_information'];?></br><?php echo $value['texte_information'];?>
					<input type="hidden" id="id_info" name="id_info" value=<?php echo $_SESSION['infoasupprimer'];?> />
					</br><input type="submit" value="GARDER" id="bouton2">
				</form>
					</div>
		</div>
				</br>
				<?php
		}
	}/////////////////////FORMULAIRE VOIR LES PROPOSITION///////////////////////////////
	public static function afficherFormulaireVoir($series, $propositions){
		?><h1 id="labelAccueil">Liste des propositions</h1><?php
		foreach ($propositions as $value) {
			if($value['info_valide']==0){
				?>
		<div id="formulaire" class="container">
				<form action="index.php?module=moderateur&action=ajoutPropositions" method="POST">
					<div class="form-group5"><?php echo $value['nom_information'];?></br>Saison : <?php echo $value['saison_information'];?></br><?php echo $value['texte_information'];?>
					<input type="hidden" id="id_info" name="id_info" value=<?php echo $value['id_information'];?> />
					</br><input type="submit" value="AJOUT" id="bouton2">
				</form>
				<form action="index.php?module=moderateur&action=supprimePropositions" method="POST">
					<input type="hidden" id="id_info" name="id_info" value=<?php echo $value['id_information'];?> />
					<input type="submit" value="SUPPRESSION" id="bouton2">
				</form>
					</div>
		</div>
				</br>
				<?php
			}
		}
	}///////////////////FORMULAIRE AJOUT PROPOSITION///////////////////////////
	public static function afficherFormulaireAjoutProposition($series, $seriecompte, $infoproposition) {
	?>
		<h1 id="labelAccueil">Ajouter une information depuis une proposition</h1>
		<div id="formulaire" class="container">
			<div class="form-group4">
				<form  action="index.php?module=moderateur&action=ajoutPropositions" method="POST">
					<?php
					foreach ($seriecompte as $value) {
						foreach ($series as $value2) {
							if($value2['id_serie']==$value['serieCompte']){
								?><h3 class="texteblanc"><?php echo $value2['nom_serie']; ?></h3><?php
							}
						}
						?>
						
						<input type="hidden" id="serie" name="serie" value=<?php echo $value['serieCompte'];?> />
					<?php
					}
					foreach ($infoproposition as $value3){
					?>
						<input name="nomInfo" type="text" placeholder="NOM" id="nomInfo" value="<?php echo $value3['nom_information'];?>" required>
						<input name="saison" type="text" placeholder="SAISON" id="saison" value="<?php echo $value3['saison_information'];?>" required>
					
						<select name="categorie" value=<?php echo $value3['id_categorie_information'];?>>
							<option value="1"> Personnages </option>
							<option value="2"> Lieux </option>
							<option value="3"> Ev&eacute;nements </option>
							<option value="4"> Interviews </option>					
						</select>
					
						</br>
						<textarea name="texteInfo" type="text" placeholder="TEXTE / LIEN" id="texteInfo" rows="5" cols="50" required><?php echo $value3['texte_information'];?></textarea>
					<?php
					}
					?>
					<input type="submit" value="VALIDER" id="bouton">
				</form>
			</div>       
		</div>
	<?php
	}/////////////////////FORMULAIRE VOIR LES INFORMATIONS VALIDE///////////////////////////////
	public static function afficherFormulaireVoirInfo($series, $propositions){
		?><h1 id="labelAccueil">Liste des propositions</h1><?php
		foreach ($propositions as $value) {
			if($value['info_valide']==1){
				?>
		<div id="formulaire" class="container">
				<form action="index.php?module=moderateur&action=modifieInformations" method="POST">
					<div class="form-group5"><?php echo $value['nom_information'];?></br>Saison : <?php echo $value['saison_information'];?></br><?php echo $value['texte_information'];?>
					<input type="hidden" id="id_info" name="id_info" value=<?php echo $value['id_information'];?> />
					</br><input type="submit" value="MODIFICATION" id="bouton2">
				</form>
				<form action="index.php?module=moderateur&action=supprimePropositions" method="POST">	<!-- On r�utilise "supprime proposition pour les infos valide car elle fonctionnera pareil -->
					<input type="hidden" id="id_info" name="id_info" value=<?php echo $value['id_information'];?> />
					<input type="submit" value="SUPPRESSION" id="bouton2">
				</form>
					</div>
		</div>
				</br>
				<?php
			}
		}
	}
}
?>
