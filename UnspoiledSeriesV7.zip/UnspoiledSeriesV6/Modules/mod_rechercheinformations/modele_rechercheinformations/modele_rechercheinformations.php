<?php
class ModeleRechercheInformations extends DBMapper {
	
	public static function getResultatsRechercheInformations($requete) {
		$idCategorie = $_GET['idCategorie'];
		$idSerie = $_GET['idSerie'];
		$idSaison = $_GET['idSaison'];
		$req = self::$database->prepare("SELECT * FROM information WHERE nom_information LIKE \"%$requete%\" AND id_serie_information=$idSerie AND id_categorie_information=$idCategorie AND saison_information<=$idSaison GROUP BY nom_information"); 
		$query= $req->execute(array($requete)); 		
		$resultats = $req->fetchAll();
		$count = $req->rowCount();
		if ($count === 0){ 
			return null;
		}
		else{
			return $resultats;
		}
	}
}
?>





